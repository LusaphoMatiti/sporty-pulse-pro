
/**
 * Client
**/

import * as runtime from './runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Account
 * 
 */
export type Account = $Result.DefaultSelection<Prisma.$AccountPayload>
/**
 * Model NextAuthSession
 * 
 */
export type NextAuthSession = $Result.DefaultSelection<Prisma.$NextAuthSessionPayload>
/**
 * Model VerificationToken
 * 
 */
export type VerificationToken = $Result.DefaultSelection<Prisma.$VerificationTokenPayload>
/**
 * Model Equipment
 * 
 */
export type Equipment = $Result.DefaultSelection<Prisma.$EquipmentPayload>
/**
 * Model Exercise
 * 
 */
export type Exercise = $Result.DefaultSelection<Prisma.$ExercisePayload>
/**
 * Model WorkoutPlan
 * 
 */
export type WorkoutPlan = $Result.DefaultSelection<Prisma.$WorkoutPlanPayload>
/**
 * Model PlannedSession
 * 
 */
export type PlannedSession = $Result.DefaultSelection<Prisma.$PlannedSessionPayload>
/**
 * Model PlannedExercise
 * 
 */
export type PlannedExercise = $Result.DefaultSelection<Prisma.$PlannedExercisePayload>
/**
 * Model PlanInstance
 * 
 */
export type PlanInstance = $Result.DefaultSelection<Prisma.$PlanInstancePayload>
/**
 * Model WorkoutLog
 * 
 */
export type WorkoutLog = $Result.DefaultSelection<Prisma.$WorkoutLogPayload>
/**
 * Model Subscription
 * 
 */
export type Subscription = $Result.DefaultSelection<Prisma.$SubscriptionPayload>
/**
 * Model UserEquipment
 * 
 */
export type UserEquipment = $Result.DefaultSelection<Prisma.$UserEquipmentPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Role: {
  ATHLETE: 'ATHLETE',
  COACH: 'COACH',
  ADMIN: 'ADMIN'
};

export type Role = (typeof Role)[keyof typeof Role]


export const PrimaryGoal: {
  LOSE_WEIGHT: 'LOSE_WEIGHT',
  BUILD_MUSCLE: 'BUILD_MUSCLE',
  GET_FIT: 'GET_FIT'
};

export type PrimaryGoal = (typeof PrimaryGoal)[keyof typeof PrimaryGoal]


export const TrainingLocation: {
  HOME: 'HOME',
  GYM: 'GYM'
};

export type TrainingLocation = (typeof TrainingLocation)[keyof typeof TrainingLocation]


export const BiologicalSex: {
  MALE: 'MALE',
  FEMALE: 'FEMALE',
  NOT_SPECIFIED: 'NOT_SPECIFIED'
};

export type BiologicalSex = (typeof BiologicalSex)[keyof typeof BiologicalSex]


export const Plan: {
  FREE: 'FREE',
  EQUIPMENT: 'EQUIPMENT',
  PRO: 'PRO'
};

export type Plan = (typeof Plan)[keyof typeof Plan]


export const EquipmentSource: {
  PURCHASED: 'PURCHASED',
  DECLARED: 'DECLARED',
  BODYWEIGHT: 'BODYWEIGHT'
};

export type EquipmentSource = (typeof EquipmentSource)[keyof typeof EquipmentSource]


export const MuscleGroup: {
  UPPER: 'UPPER',
  LOWER: 'LOWER',
  CORE: 'CORE',
  FULLBODY: 'FULLBODY'
};

export type MuscleGroup = (typeof MuscleGroup)[keyof typeof MuscleGroup]


export const PlanTier: {
  FREE: 'FREE',
  EQUIPMENT: 'EQUIPMENT',
  PRO: 'PRO'
};

export type PlanTier = (typeof PlanTier)[keyof typeof PlanTier]


export const UserLevel: {
  BEGINNER: 'BEGINNER',
  INTERMEDIATE: 'INTERMEDIATE',
  ADVANCED: 'ADVANCED'
};

export type UserLevel = (typeof UserLevel)[keyof typeof UserLevel]


export const InstanceStatus: {
  ACTIVE: 'ACTIVE',
  COMPLETED: 'COMPLETED',
  ABANDONED: 'ABANDONED'
};

export type InstanceStatus = (typeof InstanceStatus)[keyof typeof InstanceStatus]

}

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

export type PrimaryGoal = $Enums.PrimaryGoal

export const PrimaryGoal: typeof $Enums.PrimaryGoal

export type TrainingLocation = $Enums.TrainingLocation

export const TrainingLocation: typeof $Enums.TrainingLocation

export type BiologicalSex = $Enums.BiologicalSex

export const BiologicalSex: typeof $Enums.BiologicalSex

export type Plan = $Enums.Plan

export const Plan: typeof $Enums.Plan

export type EquipmentSource = $Enums.EquipmentSource

export const EquipmentSource: typeof $Enums.EquipmentSource

export type MuscleGroup = $Enums.MuscleGroup

export const MuscleGroup: typeof $Enums.MuscleGroup

export type PlanTier = $Enums.PlanTier

export const PlanTier: typeof $Enums.PlanTier

export type UserLevel = $Enums.UserLevel

export const UserLevel: typeof $Enums.UserLevel

export type InstanceStatus = $Enums.InstanceStatus

export const InstanceStatus: typeof $Enums.InstanceStatus

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient({
 *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
 * })
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient({
   *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
   * })
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.account`: Exposes CRUD operations for the **Account** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Accounts
    * const accounts = await prisma.account.findMany()
    * ```
    */
  get account(): Prisma.AccountDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.nextAuthSession`: Exposes CRUD operations for the **NextAuthSession** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more NextAuthSessions
    * const nextAuthSessions = await prisma.nextAuthSession.findMany()
    * ```
    */
  get nextAuthSession(): Prisma.NextAuthSessionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.verificationToken`: Exposes CRUD operations for the **VerificationToken** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VerificationTokens
    * const verificationTokens = await prisma.verificationToken.findMany()
    * ```
    */
  get verificationToken(): Prisma.VerificationTokenDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.equipment`: Exposes CRUD operations for the **Equipment** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Equipment
    * const equipment = await prisma.equipment.findMany()
    * ```
    */
  get equipment(): Prisma.EquipmentDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.exercise`: Exposes CRUD operations for the **Exercise** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Exercises
    * const exercises = await prisma.exercise.findMany()
    * ```
    */
  get exercise(): Prisma.ExerciseDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.workoutPlan`: Exposes CRUD operations for the **WorkoutPlan** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more WorkoutPlans
    * const workoutPlans = await prisma.workoutPlan.findMany()
    * ```
    */
  get workoutPlan(): Prisma.WorkoutPlanDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.plannedSession`: Exposes CRUD operations for the **PlannedSession** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PlannedSessions
    * const plannedSessions = await prisma.plannedSession.findMany()
    * ```
    */
  get plannedSession(): Prisma.PlannedSessionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.plannedExercise`: Exposes CRUD operations for the **PlannedExercise** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PlannedExercises
    * const plannedExercises = await prisma.plannedExercise.findMany()
    * ```
    */
  get plannedExercise(): Prisma.PlannedExerciseDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.planInstance`: Exposes CRUD operations for the **PlanInstance** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PlanInstances
    * const planInstances = await prisma.planInstance.findMany()
    * ```
    */
  get planInstance(): Prisma.PlanInstanceDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.workoutLog`: Exposes CRUD operations for the **WorkoutLog** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more WorkoutLogs
    * const workoutLogs = await prisma.workoutLog.findMany()
    * ```
    */
  get workoutLog(): Prisma.WorkoutLogDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.subscription`: Exposes CRUD operations for the **Subscription** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Subscriptions
    * const subscriptions = await prisma.subscription.findMany()
    * ```
    */
  get subscription(): Prisma.SubscriptionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.userEquipment`: Exposes CRUD operations for the **UserEquipment** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UserEquipments
    * const userEquipments = await prisma.userEquipment.findMany()
    * ```
    */
  get userEquipment(): Prisma.UserEquipmentDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.6.0
   * Query Engine version: 75cbdc1eb7150937890ad5465d861175c6624711
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Account: 'Account',
    NextAuthSession: 'NextAuthSession',
    VerificationToken: 'VerificationToken',
    Equipment: 'Equipment',
    Exercise: 'Exercise',
    WorkoutPlan: 'WorkoutPlan',
    PlannedSession: 'PlannedSession',
    PlannedExercise: 'PlannedExercise',
    PlanInstance: 'PlanInstance',
    WorkoutLog: 'WorkoutLog',
    Subscription: 'Subscription',
    UserEquipment: 'UserEquipment'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "account" | "nextAuthSession" | "verificationToken" | "equipment" | "exercise" | "workoutPlan" | "plannedSession" | "plannedExercise" | "planInstance" | "workoutLog" | "subscription" | "userEquipment"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Account: {
        payload: Prisma.$AccountPayload<ExtArgs>
        fields: Prisma.AccountFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AccountFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AccountFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>
          }
          findFirst: {
            args: Prisma.AccountFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AccountFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>
          }
          findMany: {
            args: Prisma.AccountFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>[]
          }
          create: {
            args: Prisma.AccountCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>
          }
          createMany: {
            args: Prisma.AccountCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AccountCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>[]
          }
          delete: {
            args: Prisma.AccountDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>
          }
          update: {
            args: Prisma.AccountUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>
          }
          deleteMany: {
            args: Prisma.AccountDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AccountUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AccountUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>[]
          }
          upsert: {
            args: Prisma.AccountUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AccountPayload>
          }
          aggregate: {
            args: Prisma.AccountAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAccount>
          }
          groupBy: {
            args: Prisma.AccountGroupByArgs<ExtArgs>
            result: $Utils.Optional<AccountGroupByOutputType>[]
          }
          count: {
            args: Prisma.AccountCountArgs<ExtArgs>
            result: $Utils.Optional<AccountCountAggregateOutputType> | number
          }
        }
      }
      NextAuthSession: {
        payload: Prisma.$NextAuthSessionPayload<ExtArgs>
        fields: Prisma.NextAuthSessionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.NextAuthSessionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.NextAuthSessionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>
          }
          findFirst: {
            args: Prisma.NextAuthSessionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.NextAuthSessionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>
          }
          findMany: {
            args: Prisma.NextAuthSessionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>[]
          }
          create: {
            args: Prisma.NextAuthSessionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>
          }
          createMany: {
            args: Prisma.NextAuthSessionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.NextAuthSessionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>[]
          }
          delete: {
            args: Prisma.NextAuthSessionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>
          }
          update: {
            args: Prisma.NextAuthSessionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>
          }
          deleteMany: {
            args: Prisma.NextAuthSessionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.NextAuthSessionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.NextAuthSessionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>[]
          }
          upsert: {
            args: Prisma.NextAuthSessionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$NextAuthSessionPayload>
          }
          aggregate: {
            args: Prisma.NextAuthSessionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateNextAuthSession>
          }
          groupBy: {
            args: Prisma.NextAuthSessionGroupByArgs<ExtArgs>
            result: $Utils.Optional<NextAuthSessionGroupByOutputType>[]
          }
          count: {
            args: Prisma.NextAuthSessionCountArgs<ExtArgs>
            result: $Utils.Optional<NextAuthSessionCountAggregateOutputType> | number
          }
        }
      }
      VerificationToken: {
        payload: Prisma.$VerificationTokenPayload<ExtArgs>
        fields: Prisma.VerificationTokenFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VerificationTokenFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VerificationTokenFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>
          }
          findFirst: {
            args: Prisma.VerificationTokenFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VerificationTokenFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>
          }
          findMany: {
            args: Prisma.VerificationTokenFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>[]
          }
          create: {
            args: Prisma.VerificationTokenCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>
          }
          createMany: {
            args: Prisma.VerificationTokenCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.VerificationTokenCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>[]
          }
          delete: {
            args: Prisma.VerificationTokenDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>
          }
          update: {
            args: Prisma.VerificationTokenUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>
          }
          deleteMany: {
            args: Prisma.VerificationTokenDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VerificationTokenUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.VerificationTokenUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>[]
          }
          upsert: {
            args: Prisma.VerificationTokenUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VerificationTokenPayload>
          }
          aggregate: {
            args: Prisma.VerificationTokenAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVerificationToken>
          }
          groupBy: {
            args: Prisma.VerificationTokenGroupByArgs<ExtArgs>
            result: $Utils.Optional<VerificationTokenGroupByOutputType>[]
          }
          count: {
            args: Prisma.VerificationTokenCountArgs<ExtArgs>
            result: $Utils.Optional<VerificationTokenCountAggregateOutputType> | number
          }
        }
      }
      Equipment: {
        payload: Prisma.$EquipmentPayload<ExtArgs>
        fields: Prisma.EquipmentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EquipmentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EquipmentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>
          }
          findFirst: {
            args: Prisma.EquipmentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EquipmentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>
          }
          findMany: {
            args: Prisma.EquipmentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>[]
          }
          create: {
            args: Prisma.EquipmentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>
          }
          createMany: {
            args: Prisma.EquipmentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.EquipmentCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>[]
          }
          delete: {
            args: Prisma.EquipmentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>
          }
          update: {
            args: Prisma.EquipmentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>
          }
          deleteMany: {
            args: Prisma.EquipmentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EquipmentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.EquipmentUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>[]
          }
          upsert: {
            args: Prisma.EquipmentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EquipmentPayload>
          }
          aggregate: {
            args: Prisma.EquipmentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEquipment>
          }
          groupBy: {
            args: Prisma.EquipmentGroupByArgs<ExtArgs>
            result: $Utils.Optional<EquipmentGroupByOutputType>[]
          }
          count: {
            args: Prisma.EquipmentCountArgs<ExtArgs>
            result: $Utils.Optional<EquipmentCountAggregateOutputType> | number
          }
        }
      }
      Exercise: {
        payload: Prisma.$ExercisePayload<ExtArgs>
        fields: Prisma.ExerciseFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ExerciseFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ExerciseFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>
          }
          findFirst: {
            args: Prisma.ExerciseFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ExerciseFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>
          }
          findMany: {
            args: Prisma.ExerciseFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>[]
          }
          create: {
            args: Prisma.ExerciseCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>
          }
          createMany: {
            args: Prisma.ExerciseCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ExerciseCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>[]
          }
          delete: {
            args: Prisma.ExerciseDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>
          }
          update: {
            args: Prisma.ExerciseUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>
          }
          deleteMany: {
            args: Prisma.ExerciseDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ExerciseUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ExerciseUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>[]
          }
          upsert: {
            args: Prisma.ExerciseUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExercisePayload>
          }
          aggregate: {
            args: Prisma.ExerciseAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateExercise>
          }
          groupBy: {
            args: Prisma.ExerciseGroupByArgs<ExtArgs>
            result: $Utils.Optional<ExerciseGroupByOutputType>[]
          }
          count: {
            args: Prisma.ExerciseCountArgs<ExtArgs>
            result: $Utils.Optional<ExerciseCountAggregateOutputType> | number
          }
        }
      }
      WorkoutPlan: {
        payload: Prisma.$WorkoutPlanPayload<ExtArgs>
        fields: Prisma.WorkoutPlanFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WorkoutPlanFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WorkoutPlanFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          findFirst: {
            args: Prisma.WorkoutPlanFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WorkoutPlanFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          findMany: {
            args: Prisma.WorkoutPlanFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>[]
          }
          create: {
            args: Prisma.WorkoutPlanCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          createMany: {
            args: Prisma.WorkoutPlanCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.WorkoutPlanCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>[]
          }
          delete: {
            args: Prisma.WorkoutPlanDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          update: {
            args: Prisma.WorkoutPlanUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          deleteMany: {
            args: Prisma.WorkoutPlanDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WorkoutPlanUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.WorkoutPlanUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>[]
          }
          upsert: {
            args: Prisma.WorkoutPlanUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutPlanPayload>
          }
          aggregate: {
            args: Prisma.WorkoutPlanAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWorkoutPlan>
          }
          groupBy: {
            args: Prisma.WorkoutPlanGroupByArgs<ExtArgs>
            result: $Utils.Optional<WorkoutPlanGroupByOutputType>[]
          }
          count: {
            args: Prisma.WorkoutPlanCountArgs<ExtArgs>
            result: $Utils.Optional<WorkoutPlanCountAggregateOutputType> | number
          }
        }
      }
      PlannedSession: {
        payload: Prisma.$PlannedSessionPayload<ExtArgs>
        fields: Prisma.PlannedSessionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PlannedSessionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PlannedSessionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>
          }
          findFirst: {
            args: Prisma.PlannedSessionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PlannedSessionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>
          }
          findMany: {
            args: Prisma.PlannedSessionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>[]
          }
          create: {
            args: Prisma.PlannedSessionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>
          }
          createMany: {
            args: Prisma.PlannedSessionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PlannedSessionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>[]
          }
          delete: {
            args: Prisma.PlannedSessionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>
          }
          update: {
            args: Prisma.PlannedSessionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>
          }
          deleteMany: {
            args: Prisma.PlannedSessionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PlannedSessionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PlannedSessionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>[]
          }
          upsert: {
            args: Prisma.PlannedSessionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedSessionPayload>
          }
          aggregate: {
            args: Prisma.PlannedSessionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePlannedSession>
          }
          groupBy: {
            args: Prisma.PlannedSessionGroupByArgs<ExtArgs>
            result: $Utils.Optional<PlannedSessionGroupByOutputType>[]
          }
          count: {
            args: Prisma.PlannedSessionCountArgs<ExtArgs>
            result: $Utils.Optional<PlannedSessionCountAggregateOutputType> | number
          }
        }
      }
      PlannedExercise: {
        payload: Prisma.$PlannedExercisePayload<ExtArgs>
        fields: Prisma.PlannedExerciseFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PlannedExerciseFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PlannedExerciseFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>
          }
          findFirst: {
            args: Prisma.PlannedExerciseFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PlannedExerciseFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>
          }
          findMany: {
            args: Prisma.PlannedExerciseFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>[]
          }
          create: {
            args: Prisma.PlannedExerciseCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>
          }
          createMany: {
            args: Prisma.PlannedExerciseCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PlannedExerciseCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>[]
          }
          delete: {
            args: Prisma.PlannedExerciseDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>
          }
          update: {
            args: Prisma.PlannedExerciseUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>
          }
          deleteMany: {
            args: Prisma.PlannedExerciseDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PlannedExerciseUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PlannedExerciseUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>[]
          }
          upsert: {
            args: Prisma.PlannedExerciseUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlannedExercisePayload>
          }
          aggregate: {
            args: Prisma.PlannedExerciseAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePlannedExercise>
          }
          groupBy: {
            args: Prisma.PlannedExerciseGroupByArgs<ExtArgs>
            result: $Utils.Optional<PlannedExerciseGroupByOutputType>[]
          }
          count: {
            args: Prisma.PlannedExerciseCountArgs<ExtArgs>
            result: $Utils.Optional<PlannedExerciseCountAggregateOutputType> | number
          }
        }
      }
      PlanInstance: {
        payload: Prisma.$PlanInstancePayload<ExtArgs>
        fields: Prisma.PlanInstanceFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PlanInstanceFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PlanInstanceFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>
          }
          findFirst: {
            args: Prisma.PlanInstanceFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PlanInstanceFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>
          }
          findMany: {
            args: Prisma.PlanInstanceFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>[]
          }
          create: {
            args: Prisma.PlanInstanceCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>
          }
          createMany: {
            args: Prisma.PlanInstanceCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PlanInstanceCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>[]
          }
          delete: {
            args: Prisma.PlanInstanceDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>
          }
          update: {
            args: Prisma.PlanInstanceUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>
          }
          deleteMany: {
            args: Prisma.PlanInstanceDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PlanInstanceUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PlanInstanceUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>[]
          }
          upsert: {
            args: Prisma.PlanInstanceUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlanInstancePayload>
          }
          aggregate: {
            args: Prisma.PlanInstanceAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePlanInstance>
          }
          groupBy: {
            args: Prisma.PlanInstanceGroupByArgs<ExtArgs>
            result: $Utils.Optional<PlanInstanceGroupByOutputType>[]
          }
          count: {
            args: Prisma.PlanInstanceCountArgs<ExtArgs>
            result: $Utils.Optional<PlanInstanceCountAggregateOutputType> | number
          }
        }
      }
      WorkoutLog: {
        payload: Prisma.$WorkoutLogPayload<ExtArgs>
        fields: Prisma.WorkoutLogFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WorkoutLogFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WorkoutLogFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>
          }
          findFirst: {
            args: Prisma.WorkoutLogFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WorkoutLogFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>
          }
          findMany: {
            args: Prisma.WorkoutLogFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>[]
          }
          create: {
            args: Prisma.WorkoutLogCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>
          }
          createMany: {
            args: Prisma.WorkoutLogCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.WorkoutLogCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>[]
          }
          delete: {
            args: Prisma.WorkoutLogDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>
          }
          update: {
            args: Prisma.WorkoutLogUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>
          }
          deleteMany: {
            args: Prisma.WorkoutLogDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WorkoutLogUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.WorkoutLogUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>[]
          }
          upsert: {
            args: Prisma.WorkoutLogUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WorkoutLogPayload>
          }
          aggregate: {
            args: Prisma.WorkoutLogAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWorkoutLog>
          }
          groupBy: {
            args: Prisma.WorkoutLogGroupByArgs<ExtArgs>
            result: $Utils.Optional<WorkoutLogGroupByOutputType>[]
          }
          count: {
            args: Prisma.WorkoutLogCountArgs<ExtArgs>
            result: $Utils.Optional<WorkoutLogCountAggregateOutputType> | number
          }
        }
      }
      Subscription: {
        payload: Prisma.$SubscriptionPayload<ExtArgs>
        fields: Prisma.SubscriptionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SubscriptionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SubscriptionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>
          }
          findFirst: {
            args: Prisma.SubscriptionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SubscriptionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>
          }
          findMany: {
            args: Prisma.SubscriptionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>[]
          }
          create: {
            args: Prisma.SubscriptionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>
          }
          createMany: {
            args: Prisma.SubscriptionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SubscriptionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>[]
          }
          delete: {
            args: Prisma.SubscriptionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>
          }
          update: {
            args: Prisma.SubscriptionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>
          }
          deleteMany: {
            args: Prisma.SubscriptionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SubscriptionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SubscriptionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>[]
          }
          upsert: {
            args: Prisma.SubscriptionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubscriptionPayload>
          }
          aggregate: {
            args: Prisma.SubscriptionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSubscription>
          }
          groupBy: {
            args: Prisma.SubscriptionGroupByArgs<ExtArgs>
            result: $Utils.Optional<SubscriptionGroupByOutputType>[]
          }
          count: {
            args: Prisma.SubscriptionCountArgs<ExtArgs>
            result: $Utils.Optional<SubscriptionCountAggregateOutputType> | number
          }
        }
      }
      UserEquipment: {
        payload: Prisma.$UserEquipmentPayload<ExtArgs>
        fields: Prisma.UserEquipmentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserEquipmentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserEquipmentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>
          }
          findFirst: {
            args: Prisma.UserEquipmentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserEquipmentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>
          }
          findMany: {
            args: Prisma.UserEquipmentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>[]
          }
          create: {
            args: Prisma.UserEquipmentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>
          }
          createMany: {
            args: Prisma.UserEquipmentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserEquipmentCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>[]
          }
          delete: {
            args: Prisma.UserEquipmentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>
          }
          update: {
            args: Prisma.UserEquipmentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>
          }
          deleteMany: {
            args: Prisma.UserEquipmentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserEquipmentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserEquipmentUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>[]
          }
          upsert: {
            args: Prisma.UserEquipmentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserEquipmentPayload>
          }
          aggregate: {
            args: Prisma.UserEquipmentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUserEquipment>
          }
          groupBy: {
            args: Prisma.UserEquipmentGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserEquipmentGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserEquipmentCountArgs<ExtArgs>
            result: $Utils.Optional<UserEquipmentCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    account?: AccountOmit
    nextAuthSession?: NextAuthSessionOmit
    verificationToken?: VerificationTokenOmit
    equipment?: EquipmentOmit
    exercise?: ExerciseOmit
    workoutPlan?: WorkoutPlanOmit
    plannedSession?: PlannedSessionOmit
    plannedExercise?: PlannedExerciseOmit
    planInstance?: PlanInstanceOmit
    workoutLog?: WorkoutLogOmit
    subscription?: SubscriptionOmit
    userEquipment?: UserEquipmentOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    accounts: number
    sessions: number
    userEquipment: number
    instances: number
    workoutLogs: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    accounts?: boolean | UserCountOutputTypeCountAccountsArgs
    sessions?: boolean | UserCountOutputTypeCountSessionsArgs
    userEquipment?: boolean | UserCountOutputTypeCountUserEquipmentArgs
    instances?: boolean | UserCountOutputTypeCountInstancesArgs
    workoutLogs?: boolean | UserCountOutputTypeCountWorkoutLogsArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountAccountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AccountWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountSessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: NextAuthSessionWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountUserEquipmentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserEquipmentWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountInstancesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlanInstanceWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountWorkoutLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutLogWhereInput
  }


  /**
   * Count Type EquipmentCountOutputType
   */

  export type EquipmentCountOutputType = {
    userEquipment: number
    exercises: number
    workoutPlans: number
  }

  export type EquipmentCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    userEquipment?: boolean | EquipmentCountOutputTypeCountUserEquipmentArgs
    exercises?: boolean | EquipmentCountOutputTypeCountExercisesArgs
    workoutPlans?: boolean | EquipmentCountOutputTypeCountWorkoutPlansArgs
  }

  // Custom InputTypes
  /**
   * EquipmentCountOutputType without action
   */
  export type EquipmentCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EquipmentCountOutputType
     */
    select?: EquipmentCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * EquipmentCountOutputType without action
   */
  export type EquipmentCountOutputTypeCountUserEquipmentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserEquipmentWhereInput
  }

  /**
   * EquipmentCountOutputType without action
   */
  export type EquipmentCountOutputTypeCountExercisesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExerciseWhereInput
  }

  /**
   * EquipmentCountOutputType without action
   */
  export type EquipmentCountOutputTypeCountWorkoutPlansArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutPlanWhereInput
  }


  /**
   * Count Type ExerciseCountOutputType
   */

  export type ExerciseCountOutputType = {
    plannedExercises: number
  }

  export type ExerciseCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plannedExercises?: boolean | ExerciseCountOutputTypeCountPlannedExercisesArgs
  }

  // Custom InputTypes
  /**
   * ExerciseCountOutputType without action
   */
  export type ExerciseCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExerciseCountOutputType
     */
    select?: ExerciseCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ExerciseCountOutputType without action
   */
  export type ExerciseCountOutputTypeCountPlannedExercisesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlannedExerciseWhereInput
  }


  /**
   * Count Type WorkoutPlanCountOutputType
   */

  export type WorkoutPlanCountOutputType = {
    plannedSessions: number
    instances: number
  }

  export type WorkoutPlanCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plannedSessions?: boolean | WorkoutPlanCountOutputTypeCountPlannedSessionsArgs
    instances?: boolean | WorkoutPlanCountOutputTypeCountInstancesArgs
  }

  // Custom InputTypes
  /**
   * WorkoutPlanCountOutputType without action
   */
  export type WorkoutPlanCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlanCountOutputType
     */
    select?: WorkoutPlanCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * WorkoutPlanCountOutputType without action
   */
  export type WorkoutPlanCountOutputTypeCountPlannedSessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlannedSessionWhereInput
  }

  /**
   * WorkoutPlanCountOutputType without action
   */
  export type WorkoutPlanCountOutputTypeCountInstancesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlanInstanceWhereInput
  }


  /**
   * Count Type PlannedSessionCountOutputType
   */

  export type PlannedSessionCountOutputType = {
    plannedExercises: number
  }

  export type PlannedSessionCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plannedExercises?: boolean | PlannedSessionCountOutputTypeCountPlannedExercisesArgs
  }

  // Custom InputTypes
  /**
   * PlannedSessionCountOutputType without action
   */
  export type PlannedSessionCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSessionCountOutputType
     */
    select?: PlannedSessionCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PlannedSessionCountOutputType without action
   */
  export type PlannedSessionCountOutputTypeCountPlannedExercisesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlannedExerciseWhereInput
  }


  /**
   * Count Type PlannedExerciseCountOutputType
   */

  export type PlannedExerciseCountOutputType = {
    loggedSets: number
  }

  export type PlannedExerciseCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    loggedSets?: boolean | PlannedExerciseCountOutputTypeCountLoggedSetsArgs
  }

  // Custom InputTypes
  /**
   * PlannedExerciseCountOutputType without action
   */
  export type PlannedExerciseCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExerciseCountOutputType
     */
    select?: PlannedExerciseCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PlannedExerciseCountOutputType without action
   */
  export type PlannedExerciseCountOutputTypeCountLoggedSetsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutLogWhereInput
  }


  /**
   * Count Type PlanInstanceCountOutputType
   */

  export type PlanInstanceCountOutputType = {
    workoutLogs: number
  }

  export type PlanInstanceCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    workoutLogs?: boolean | PlanInstanceCountOutputTypeCountWorkoutLogsArgs
  }

  // Custom InputTypes
  /**
   * PlanInstanceCountOutputType without action
   */
  export type PlanInstanceCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstanceCountOutputType
     */
    select?: PlanInstanceCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PlanInstanceCountOutputType without action
   */
  export type PlanInstanceCountOutputTypeCountWorkoutLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutLogWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    email: string | null
    name: string | null
    password: string | null
    emailVerified: Date | null
    image: string | null
    role: $Enums.Role | null
    lastLoginAt: Date | null
    onboardingComplete: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
    isNewUser: boolean | null
    primaryGoal: $Enums.PrimaryGoal | null
    trainingLocation: $Enums.TrainingLocation | null
    biologicalSex: $Enums.BiologicalSex | null
    experienceLevel: $Enums.UserLevel | null
    onboardingCompletedAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    email: string | null
    name: string | null
    password: string | null
    emailVerified: Date | null
    image: string | null
    role: $Enums.Role | null
    lastLoginAt: Date | null
    onboardingComplete: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
    isNewUser: boolean | null
    primaryGoal: $Enums.PrimaryGoal | null
    trainingLocation: $Enums.TrainingLocation | null
    biologicalSex: $Enums.BiologicalSex | null
    experienceLevel: $Enums.UserLevel | null
    onboardingCompletedAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    email: number
    name: number
    password: number
    emailVerified: number
    image: number
    role: number
    lastLoginAt: number
    onboardingComplete: number
    createdAt: number
    updatedAt: number
    isNewUser: number
    primaryGoal: number
    trainingLocation: number
    biologicalSex: number
    experienceLevel: number
    onboardingCompletedAt: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    email?: true
    name?: true
    password?: true
    emailVerified?: true
    image?: true
    role?: true
    lastLoginAt?: true
    onboardingComplete?: true
    createdAt?: true
    updatedAt?: true
    isNewUser?: true
    primaryGoal?: true
    trainingLocation?: true
    biologicalSex?: true
    experienceLevel?: true
    onboardingCompletedAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    email?: true
    name?: true
    password?: true
    emailVerified?: true
    image?: true
    role?: true
    lastLoginAt?: true
    onboardingComplete?: true
    createdAt?: true
    updatedAt?: true
    isNewUser?: true
    primaryGoal?: true
    trainingLocation?: true
    biologicalSex?: true
    experienceLevel?: true
    onboardingCompletedAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    email?: true
    name?: true
    password?: true
    emailVerified?: true
    image?: true
    role?: true
    lastLoginAt?: true
    onboardingComplete?: true
    createdAt?: true
    updatedAt?: true
    isNewUser?: true
    primaryGoal?: true
    trainingLocation?: true
    biologicalSex?: true
    experienceLevel?: true
    onboardingCompletedAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    email: string
    name: string | null
    password: string | null
    emailVerified: Date | null
    image: string | null
    role: $Enums.Role
    lastLoginAt: Date | null
    onboardingComplete: boolean
    createdAt: Date
    updatedAt: Date
    isNewUser: boolean
    primaryGoal: $Enums.PrimaryGoal | null
    trainingLocation: $Enums.TrainingLocation | null
    biologicalSex: $Enums.BiologicalSex | null
    experienceLevel: $Enums.UserLevel | null
    onboardingCompletedAt: Date | null
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
    emailVerified?: boolean
    image?: boolean
    role?: boolean
    lastLoginAt?: boolean
    onboardingComplete?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isNewUser?: boolean
    primaryGoal?: boolean
    trainingLocation?: boolean
    biologicalSex?: boolean
    experienceLevel?: boolean
    onboardingCompletedAt?: boolean
    accounts?: boolean | User$accountsArgs<ExtArgs>
    sessions?: boolean | User$sessionsArgs<ExtArgs>
    subscription?: boolean | User$subscriptionArgs<ExtArgs>
    userEquipment?: boolean | User$userEquipmentArgs<ExtArgs>
    instances?: boolean | User$instancesArgs<ExtArgs>
    workoutLogs?: boolean | User$workoutLogsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
    emailVerified?: boolean
    image?: boolean
    role?: boolean
    lastLoginAt?: boolean
    onboardingComplete?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isNewUser?: boolean
    primaryGoal?: boolean
    trainingLocation?: boolean
    biologicalSex?: boolean
    experienceLevel?: boolean
    onboardingCompletedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
    emailVerified?: boolean
    image?: boolean
    role?: boolean
    lastLoginAt?: boolean
    onboardingComplete?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isNewUser?: boolean
    primaryGoal?: boolean
    trainingLocation?: boolean
    biologicalSex?: boolean
    experienceLevel?: boolean
    onboardingCompletedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    email?: boolean
    name?: boolean
    password?: boolean
    emailVerified?: boolean
    image?: boolean
    role?: boolean
    lastLoginAt?: boolean
    onboardingComplete?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isNewUser?: boolean
    primaryGoal?: boolean
    trainingLocation?: boolean
    biologicalSex?: boolean
    experienceLevel?: boolean
    onboardingCompletedAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "email" | "name" | "password" | "emailVerified" | "image" | "role" | "lastLoginAt" | "onboardingComplete" | "createdAt" | "updatedAt" | "isNewUser" | "primaryGoal" | "trainingLocation" | "biologicalSex" | "experienceLevel" | "onboardingCompletedAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    accounts?: boolean | User$accountsArgs<ExtArgs>
    sessions?: boolean | User$sessionsArgs<ExtArgs>
    subscription?: boolean | User$subscriptionArgs<ExtArgs>
    userEquipment?: boolean | User$userEquipmentArgs<ExtArgs>
    instances?: boolean | User$instancesArgs<ExtArgs>
    workoutLogs?: boolean | User$workoutLogsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type UserIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type UserIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      accounts: Prisma.$AccountPayload<ExtArgs>[]
      sessions: Prisma.$NextAuthSessionPayload<ExtArgs>[]
      subscription: Prisma.$SubscriptionPayload<ExtArgs> | null
      userEquipment: Prisma.$UserEquipmentPayload<ExtArgs>[]
      instances: Prisma.$PlanInstancePayload<ExtArgs>[]
      workoutLogs: Prisma.$WorkoutLogPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      email: string
      name: string | null
      password: string | null
      emailVerified: Date | null
      image: string | null
      role: $Enums.Role
      lastLoginAt: Date | null
      onboardingComplete: boolean
      createdAt: Date
      updatedAt: Date
      isNewUser: boolean
      primaryGoal: $Enums.PrimaryGoal | null
      trainingLocation: $Enums.TrainingLocation | null
      biologicalSex: $Enums.BiologicalSex | null
      experienceLevel: $Enums.UserLevel | null
      onboardingCompletedAt: Date | null
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    accounts<T extends User$accountsArgs<ExtArgs> = {}>(args?: Subset<T, User$accountsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    sessions<T extends User$sessionsArgs<ExtArgs> = {}>(args?: Subset<T, User$sessionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    subscription<T extends User$subscriptionArgs<ExtArgs> = {}>(args?: Subset<T, User$subscriptionArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    userEquipment<T extends User$userEquipmentArgs<ExtArgs> = {}>(args?: Subset<T, User$userEquipmentArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    instances<T extends User$instancesArgs<ExtArgs> = {}>(args?: Subset<T, User$instancesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    workoutLogs<T extends User$workoutLogsArgs<ExtArgs> = {}>(args?: Subset<T, User$workoutLogsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly password: FieldRef<"User", 'String'>
    readonly emailVerified: FieldRef<"User", 'DateTime'>
    readonly image: FieldRef<"User", 'String'>
    readonly role: FieldRef<"User", 'Role'>
    readonly lastLoginAt: FieldRef<"User", 'DateTime'>
    readonly onboardingComplete: FieldRef<"User", 'Boolean'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly updatedAt: FieldRef<"User", 'DateTime'>
    readonly isNewUser: FieldRef<"User", 'Boolean'>
    readonly primaryGoal: FieldRef<"User", 'PrimaryGoal'>
    readonly trainingLocation: FieldRef<"User", 'TrainingLocation'>
    readonly biologicalSex: FieldRef<"User", 'BiologicalSex'>
    readonly experienceLevel: FieldRef<"User", 'UserLevel'>
    readonly onboardingCompletedAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.accounts
   */
  export type User$accountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    where?: AccountWhereInput
    orderBy?: AccountOrderByWithRelationInput | AccountOrderByWithRelationInput[]
    cursor?: AccountWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AccountScalarFieldEnum | AccountScalarFieldEnum[]
  }

  /**
   * User.sessions
   */
  export type User$sessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    where?: NextAuthSessionWhereInput
    orderBy?: NextAuthSessionOrderByWithRelationInput | NextAuthSessionOrderByWithRelationInput[]
    cursor?: NextAuthSessionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: NextAuthSessionScalarFieldEnum | NextAuthSessionScalarFieldEnum[]
  }

  /**
   * User.subscription
   */
  export type User$subscriptionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    where?: SubscriptionWhereInput
  }

  /**
   * User.userEquipment
   */
  export type User$userEquipmentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    where?: UserEquipmentWhereInput
    orderBy?: UserEquipmentOrderByWithRelationInput | UserEquipmentOrderByWithRelationInput[]
    cursor?: UserEquipmentWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserEquipmentScalarFieldEnum | UserEquipmentScalarFieldEnum[]
  }

  /**
   * User.instances
   */
  export type User$instancesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    where?: PlanInstanceWhereInput
    orderBy?: PlanInstanceOrderByWithRelationInput | PlanInstanceOrderByWithRelationInput[]
    cursor?: PlanInstanceWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PlanInstanceScalarFieldEnum | PlanInstanceScalarFieldEnum[]
  }

  /**
   * User.workoutLogs
   */
  export type User$workoutLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    where?: WorkoutLogWhereInput
    orderBy?: WorkoutLogOrderByWithRelationInput | WorkoutLogOrderByWithRelationInput[]
    cursor?: WorkoutLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WorkoutLogScalarFieldEnum | WorkoutLogScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Account
   */

  export type AggregateAccount = {
    _count: AccountCountAggregateOutputType | null
    _avg: AccountAvgAggregateOutputType | null
    _sum: AccountSumAggregateOutputType | null
    _min: AccountMinAggregateOutputType | null
    _max: AccountMaxAggregateOutputType | null
  }

  export type AccountAvgAggregateOutputType = {
    expires_at: number | null
  }

  export type AccountSumAggregateOutputType = {
    expires_at: number | null
  }

  export type AccountMinAggregateOutputType = {
    id: string | null
    userId: string | null
    type: string | null
    provider: string | null
    providerAccountId: string | null
    refresh_token: string | null
    access_token: string | null
    expires_at: number | null
    token_type: string | null
    scope: string | null
    id_token: string | null
    session_state: string | null
  }

  export type AccountMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    type: string | null
    provider: string | null
    providerAccountId: string | null
    refresh_token: string | null
    access_token: string | null
    expires_at: number | null
    token_type: string | null
    scope: string | null
    id_token: string | null
    session_state: string | null
  }

  export type AccountCountAggregateOutputType = {
    id: number
    userId: number
    type: number
    provider: number
    providerAccountId: number
    refresh_token: number
    access_token: number
    expires_at: number
    token_type: number
    scope: number
    id_token: number
    session_state: number
    _all: number
  }


  export type AccountAvgAggregateInputType = {
    expires_at?: true
  }

  export type AccountSumAggregateInputType = {
    expires_at?: true
  }

  export type AccountMinAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    provider?: true
    providerAccountId?: true
    refresh_token?: true
    access_token?: true
    expires_at?: true
    token_type?: true
    scope?: true
    id_token?: true
    session_state?: true
  }

  export type AccountMaxAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    provider?: true
    providerAccountId?: true
    refresh_token?: true
    access_token?: true
    expires_at?: true
    token_type?: true
    scope?: true
    id_token?: true
    session_state?: true
  }

  export type AccountCountAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    provider?: true
    providerAccountId?: true
    refresh_token?: true
    access_token?: true
    expires_at?: true
    token_type?: true
    scope?: true
    id_token?: true
    session_state?: true
    _all?: true
  }

  export type AccountAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Account to aggregate.
     */
    where?: AccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Accounts to fetch.
     */
    orderBy?: AccountOrderByWithRelationInput | AccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Accounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Accounts
    **/
    _count?: true | AccountCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AccountAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AccountSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AccountMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AccountMaxAggregateInputType
  }

  export type GetAccountAggregateType<T extends AccountAggregateArgs> = {
        [P in keyof T & keyof AggregateAccount]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAccount[P]>
      : GetScalarType<T[P], AggregateAccount[P]>
  }




  export type AccountGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AccountWhereInput
    orderBy?: AccountOrderByWithAggregationInput | AccountOrderByWithAggregationInput[]
    by: AccountScalarFieldEnum[] | AccountScalarFieldEnum
    having?: AccountScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AccountCountAggregateInputType | true
    _avg?: AccountAvgAggregateInputType
    _sum?: AccountSumAggregateInputType
    _min?: AccountMinAggregateInputType
    _max?: AccountMaxAggregateInputType
  }

  export type AccountGroupByOutputType = {
    id: string
    userId: string
    type: string
    provider: string
    providerAccountId: string
    refresh_token: string | null
    access_token: string | null
    expires_at: number | null
    token_type: string | null
    scope: string | null
    id_token: string | null
    session_state: string | null
    _count: AccountCountAggregateOutputType | null
    _avg: AccountAvgAggregateOutputType | null
    _sum: AccountSumAggregateOutputType | null
    _min: AccountMinAggregateOutputType | null
    _max: AccountMaxAggregateOutputType | null
  }

  type GetAccountGroupByPayload<T extends AccountGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AccountGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AccountGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AccountGroupByOutputType[P]>
            : GetScalarType<T[P], AccountGroupByOutputType[P]>
        }
      >
    >


  export type AccountSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    provider?: boolean
    providerAccountId?: boolean
    refresh_token?: boolean
    access_token?: boolean
    expires_at?: boolean
    token_type?: boolean
    scope?: boolean
    id_token?: boolean
    session_state?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["account"]>

  export type AccountSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    provider?: boolean
    providerAccountId?: boolean
    refresh_token?: boolean
    access_token?: boolean
    expires_at?: boolean
    token_type?: boolean
    scope?: boolean
    id_token?: boolean
    session_state?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["account"]>

  export type AccountSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    provider?: boolean
    providerAccountId?: boolean
    refresh_token?: boolean
    access_token?: boolean
    expires_at?: boolean
    token_type?: boolean
    scope?: boolean
    id_token?: boolean
    session_state?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["account"]>

  export type AccountSelectScalar = {
    id?: boolean
    userId?: boolean
    type?: boolean
    provider?: boolean
    providerAccountId?: boolean
    refresh_token?: boolean
    access_token?: boolean
    expires_at?: boolean
    token_type?: boolean
    scope?: boolean
    id_token?: boolean
    session_state?: boolean
  }

  export type AccountOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "type" | "provider" | "providerAccountId" | "refresh_token" | "access_token" | "expires_at" | "token_type" | "scope" | "id_token" | "session_state", ExtArgs["result"]["account"]>
  export type AccountInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type AccountIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type AccountIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $AccountPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Account"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      type: string
      provider: string
      providerAccountId: string
      refresh_token: string | null
      access_token: string | null
      expires_at: number | null
      token_type: string | null
      scope: string | null
      id_token: string | null
      session_state: string | null
    }, ExtArgs["result"]["account"]>
    composites: {}
  }

  type AccountGetPayload<S extends boolean | null | undefined | AccountDefaultArgs> = $Result.GetResult<Prisma.$AccountPayload, S>

  type AccountCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AccountFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AccountCountAggregateInputType | true
    }

  export interface AccountDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Account'], meta: { name: 'Account' } }
    /**
     * Find zero or one Account that matches the filter.
     * @param {AccountFindUniqueArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AccountFindUniqueArgs>(args: SelectSubset<T, AccountFindUniqueArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Account that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AccountFindUniqueOrThrowArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AccountFindUniqueOrThrowArgs>(args: SelectSubset<T, AccountFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Account that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountFindFirstArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AccountFindFirstArgs>(args?: SelectSubset<T, AccountFindFirstArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Account that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountFindFirstOrThrowArgs} args - Arguments to find a Account
     * @example
     * // Get one Account
     * const account = await prisma.account.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AccountFindFirstOrThrowArgs>(args?: SelectSubset<T, AccountFindFirstOrThrowArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Accounts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Accounts
     * const accounts = await prisma.account.findMany()
     * 
     * // Get first 10 Accounts
     * const accounts = await prisma.account.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const accountWithIdOnly = await prisma.account.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AccountFindManyArgs>(args?: SelectSubset<T, AccountFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Account.
     * @param {AccountCreateArgs} args - Arguments to create a Account.
     * @example
     * // Create one Account
     * const Account = await prisma.account.create({
     *   data: {
     *     // ... data to create a Account
     *   }
     * })
     * 
     */
    create<T extends AccountCreateArgs>(args: SelectSubset<T, AccountCreateArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Accounts.
     * @param {AccountCreateManyArgs} args - Arguments to create many Accounts.
     * @example
     * // Create many Accounts
     * const account = await prisma.account.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AccountCreateManyArgs>(args?: SelectSubset<T, AccountCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Accounts and returns the data saved in the database.
     * @param {AccountCreateManyAndReturnArgs} args - Arguments to create many Accounts.
     * @example
     * // Create many Accounts
     * const account = await prisma.account.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Accounts and only return the `id`
     * const accountWithIdOnly = await prisma.account.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AccountCreateManyAndReturnArgs>(args?: SelectSubset<T, AccountCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Account.
     * @param {AccountDeleteArgs} args - Arguments to delete one Account.
     * @example
     * // Delete one Account
     * const Account = await prisma.account.delete({
     *   where: {
     *     // ... filter to delete one Account
     *   }
     * })
     * 
     */
    delete<T extends AccountDeleteArgs>(args: SelectSubset<T, AccountDeleteArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Account.
     * @param {AccountUpdateArgs} args - Arguments to update one Account.
     * @example
     * // Update one Account
     * const account = await prisma.account.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AccountUpdateArgs>(args: SelectSubset<T, AccountUpdateArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Accounts.
     * @param {AccountDeleteManyArgs} args - Arguments to filter Accounts to delete.
     * @example
     * // Delete a few Accounts
     * const { count } = await prisma.account.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AccountDeleteManyArgs>(args?: SelectSubset<T, AccountDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Accounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Accounts
     * const account = await prisma.account.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AccountUpdateManyArgs>(args: SelectSubset<T, AccountUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Accounts and returns the data updated in the database.
     * @param {AccountUpdateManyAndReturnArgs} args - Arguments to update many Accounts.
     * @example
     * // Update many Accounts
     * const account = await prisma.account.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Accounts and only return the `id`
     * const accountWithIdOnly = await prisma.account.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AccountUpdateManyAndReturnArgs>(args: SelectSubset<T, AccountUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Account.
     * @param {AccountUpsertArgs} args - Arguments to update or create a Account.
     * @example
     * // Update or create a Account
     * const account = await prisma.account.upsert({
     *   create: {
     *     // ... data to create a Account
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Account we want to update
     *   }
     * })
     */
    upsert<T extends AccountUpsertArgs>(args: SelectSubset<T, AccountUpsertArgs<ExtArgs>>): Prisma__AccountClient<$Result.GetResult<Prisma.$AccountPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Accounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountCountArgs} args - Arguments to filter Accounts to count.
     * @example
     * // Count the number of Accounts
     * const count = await prisma.account.count({
     *   where: {
     *     // ... the filter for the Accounts we want to count
     *   }
     * })
    **/
    count<T extends AccountCountArgs>(
      args?: Subset<T, AccountCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AccountCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Account.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AccountAggregateArgs>(args: Subset<T, AccountAggregateArgs>): Prisma.PrismaPromise<GetAccountAggregateType<T>>

    /**
     * Group by Account.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AccountGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AccountGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AccountGroupByArgs['orderBy'] }
        : { orderBy?: AccountGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AccountGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAccountGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Account model
   */
  readonly fields: AccountFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Account.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AccountClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Account model
   */
  interface AccountFieldRefs {
    readonly id: FieldRef<"Account", 'String'>
    readonly userId: FieldRef<"Account", 'String'>
    readonly type: FieldRef<"Account", 'String'>
    readonly provider: FieldRef<"Account", 'String'>
    readonly providerAccountId: FieldRef<"Account", 'String'>
    readonly refresh_token: FieldRef<"Account", 'String'>
    readonly access_token: FieldRef<"Account", 'String'>
    readonly expires_at: FieldRef<"Account", 'Int'>
    readonly token_type: FieldRef<"Account", 'String'>
    readonly scope: FieldRef<"Account", 'String'>
    readonly id_token: FieldRef<"Account", 'String'>
    readonly session_state: FieldRef<"Account", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Account findUnique
   */
  export type AccountFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * Filter, which Account to fetch.
     */
    where: AccountWhereUniqueInput
  }

  /**
   * Account findUniqueOrThrow
   */
  export type AccountFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * Filter, which Account to fetch.
     */
    where: AccountWhereUniqueInput
  }

  /**
   * Account findFirst
   */
  export type AccountFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * Filter, which Account to fetch.
     */
    where?: AccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Accounts to fetch.
     */
    orderBy?: AccountOrderByWithRelationInput | AccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Accounts.
     */
    cursor?: AccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Accounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Accounts.
     */
    distinct?: AccountScalarFieldEnum | AccountScalarFieldEnum[]
  }

  /**
   * Account findFirstOrThrow
   */
  export type AccountFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * Filter, which Account to fetch.
     */
    where?: AccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Accounts to fetch.
     */
    orderBy?: AccountOrderByWithRelationInput | AccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Accounts.
     */
    cursor?: AccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Accounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Accounts.
     */
    distinct?: AccountScalarFieldEnum | AccountScalarFieldEnum[]
  }

  /**
   * Account findMany
   */
  export type AccountFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * Filter, which Accounts to fetch.
     */
    where?: AccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Accounts to fetch.
     */
    orderBy?: AccountOrderByWithRelationInput | AccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Accounts.
     */
    cursor?: AccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Accounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Accounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Accounts.
     */
    distinct?: AccountScalarFieldEnum | AccountScalarFieldEnum[]
  }

  /**
   * Account create
   */
  export type AccountCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * The data needed to create a Account.
     */
    data: XOR<AccountCreateInput, AccountUncheckedCreateInput>
  }

  /**
   * Account createMany
   */
  export type AccountCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Accounts.
     */
    data: AccountCreateManyInput | AccountCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Account createManyAndReturn
   */
  export type AccountCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * The data used to create many Accounts.
     */
    data: AccountCreateManyInput | AccountCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Account update
   */
  export type AccountUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * The data needed to update a Account.
     */
    data: XOR<AccountUpdateInput, AccountUncheckedUpdateInput>
    /**
     * Choose, which Account to update.
     */
    where: AccountWhereUniqueInput
  }

  /**
   * Account updateMany
   */
  export type AccountUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Accounts.
     */
    data: XOR<AccountUpdateManyMutationInput, AccountUncheckedUpdateManyInput>
    /**
     * Filter which Accounts to update
     */
    where?: AccountWhereInput
    /**
     * Limit how many Accounts to update.
     */
    limit?: number
  }

  /**
   * Account updateManyAndReturn
   */
  export type AccountUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * The data used to update Accounts.
     */
    data: XOR<AccountUpdateManyMutationInput, AccountUncheckedUpdateManyInput>
    /**
     * Filter which Accounts to update
     */
    where?: AccountWhereInput
    /**
     * Limit how many Accounts to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Account upsert
   */
  export type AccountUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * The filter to search for the Account to update in case it exists.
     */
    where: AccountWhereUniqueInput
    /**
     * In case the Account found by the `where` argument doesn't exist, create a new Account with this data.
     */
    create: XOR<AccountCreateInput, AccountUncheckedCreateInput>
    /**
     * In case the Account was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AccountUpdateInput, AccountUncheckedUpdateInput>
  }

  /**
   * Account delete
   */
  export type AccountDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
    /**
     * Filter which Account to delete.
     */
    where: AccountWhereUniqueInput
  }

  /**
   * Account deleteMany
   */
  export type AccountDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Accounts to delete
     */
    where?: AccountWhereInput
    /**
     * Limit how many Accounts to delete.
     */
    limit?: number
  }

  /**
   * Account without action
   */
  export type AccountDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Account
     */
    select?: AccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Account
     */
    omit?: AccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AccountInclude<ExtArgs> | null
  }


  /**
   * Model NextAuthSession
   */

  export type AggregateNextAuthSession = {
    _count: NextAuthSessionCountAggregateOutputType | null
    _min: NextAuthSessionMinAggregateOutputType | null
    _max: NextAuthSessionMaxAggregateOutputType | null
  }

  export type NextAuthSessionMinAggregateOutputType = {
    id: string | null
    sessionToken: string | null
    userId: string | null
    expires: Date | null
  }

  export type NextAuthSessionMaxAggregateOutputType = {
    id: string | null
    sessionToken: string | null
    userId: string | null
    expires: Date | null
  }

  export type NextAuthSessionCountAggregateOutputType = {
    id: number
    sessionToken: number
    userId: number
    expires: number
    _all: number
  }


  export type NextAuthSessionMinAggregateInputType = {
    id?: true
    sessionToken?: true
    userId?: true
    expires?: true
  }

  export type NextAuthSessionMaxAggregateInputType = {
    id?: true
    sessionToken?: true
    userId?: true
    expires?: true
  }

  export type NextAuthSessionCountAggregateInputType = {
    id?: true
    sessionToken?: true
    userId?: true
    expires?: true
    _all?: true
  }

  export type NextAuthSessionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which NextAuthSession to aggregate.
     */
    where?: NextAuthSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NextAuthSessions to fetch.
     */
    orderBy?: NextAuthSessionOrderByWithRelationInput | NextAuthSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: NextAuthSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NextAuthSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NextAuthSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned NextAuthSessions
    **/
    _count?: true | NextAuthSessionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: NextAuthSessionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: NextAuthSessionMaxAggregateInputType
  }

  export type GetNextAuthSessionAggregateType<T extends NextAuthSessionAggregateArgs> = {
        [P in keyof T & keyof AggregateNextAuthSession]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateNextAuthSession[P]>
      : GetScalarType<T[P], AggregateNextAuthSession[P]>
  }




  export type NextAuthSessionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: NextAuthSessionWhereInput
    orderBy?: NextAuthSessionOrderByWithAggregationInput | NextAuthSessionOrderByWithAggregationInput[]
    by: NextAuthSessionScalarFieldEnum[] | NextAuthSessionScalarFieldEnum
    having?: NextAuthSessionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: NextAuthSessionCountAggregateInputType | true
    _min?: NextAuthSessionMinAggregateInputType
    _max?: NextAuthSessionMaxAggregateInputType
  }

  export type NextAuthSessionGroupByOutputType = {
    id: string
    sessionToken: string
    userId: string
    expires: Date
    _count: NextAuthSessionCountAggregateOutputType | null
    _min: NextAuthSessionMinAggregateOutputType | null
    _max: NextAuthSessionMaxAggregateOutputType | null
  }

  type GetNextAuthSessionGroupByPayload<T extends NextAuthSessionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<NextAuthSessionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof NextAuthSessionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], NextAuthSessionGroupByOutputType[P]>
            : GetScalarType<T[P], NextAuthSessionGroupByOutputType[P]>
        }
      >
    >


  export type NextAuthSessionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionToken?: boolean
    userId?: boolean
    expires?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["nextAuthSession"]>

  export type NextAuthSessionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionToken?: boolean
    userId?: boolean
    expires?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["nextAuthSession"]>

  export type NextAuthSessionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionToken?: boolean
    userId?: boolean
    expires?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["nextAuthSession"]>

  export type NextAuthSessionSelectScalar = {
    id?: boolean
    sessionToken?: boolean
    userId?: boolean
    expires?: boolean
  }

  export type NextAuthSessionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "sessionToken" | "userId" | "expires", ExtArgs["result"]["nextAuthSession"]>
  export type NextAuthSessionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type NextAuthSessionIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type NextAuthSessionIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $NextAuthSessionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "NextAuthSession"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      sessionToken: string
      userId: string
      expires: Date
    }, ExtArgs["result"]["nextAuthSession"]>
    composites: {}
  }

  type NextAuthSessionGetPayload<S extends boolean | null | undefined | NextAuthSessionDefaultArgs> = $Result.GetResult<Prisma.$NextAuthSessionPayload, S>

  type NextAuthSessionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<NextAuthSessionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: NextAuthSessionCountAggregateInputType | true
    }

  export interface NextAuthSessionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['NextAuthSession'], meta: { name: 'NextAuthSession' } }
    /**
     * Find zero or one NextAuthSession that matches the filter.
     * @param {NextAuthSessionFindUniqueArgs} args - Arguments to find a NextAuthSession
     * @example
     * // Get one NextAuthSession
     * const nextAuthSession = await prisma.nextAuthSession.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends NextAuthSessionFindUniqueArgs>(args: SelectSubset<T, NextAuthSessionFindUniqueArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one NextAuthSession that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {NextAuthSessionFindUniqueOrThrowArgs} args - Arguments to find a NextAuthSession
     * @example
     * // Get one NextAuthSession
     * const nextAuthSession = await prisma.nextAuthSession.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends NextAuthSessionFindUniqueOrThrowArgs>(args: SelectSubset<T, NextAuthSessionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first NextAuthSession that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NextAuthSessionFindFirstArgs} args - Arguments to find a NextAuthSession
     * @example
     * // Get one NextAuthSession
     * const nextAuthSession = await prisma.nextAuthSession.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends NextAuthSessionFindFirstArgs>(args?: SelectSubset<T, NextAuthSessionFindFirstArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first NextAuthSession that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NextAuthSessionFindFirstOrThrowArgs} args - Arguments to find a NextAuthSession
     * @example
     * // Get one NextAuthSession
     * const nextAuthSession = await prisma.nextAuthSession.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends NextAuthSessionFindFirstOrThrowArgs>(args?: SelectSubset<T, NextAuthSessionFindFirstOrThrowArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more NextAuthSessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NextAuthSessionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all NextAuthSessions
     * const nextAuthSessions = await prisma.nextAuthSession.findMany()
     * 
     * // Get first 10 NextAuthSessions
     * const nextAuthSessions = await prisma.nextAuthSession.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const nextAuthSessionWithIdOnly = await prisma.nextAuthSession.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends NextAuthSessionFindManyArgs>(args?: SelectSubset<T, NextAuthSessionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a NextAuthSession.
     * @param {NextAuthSessionCreateArgs} args - Arguments to create a NextAuthSession.
     * @example
     * // Create one NextAuthSession
     * const NextAuthSession = await prisma.nextAuthSession.create({
     *   data: {
     *     // ... data to create a NextAuthSession
     *   }
     * })
     * 
     */
    create<T extends NextAuthSessionCreateArgs>(args: SelectSubset<T, NextAuthSessionCreateArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many NextAuthSessions.
     * @param {NextAuthSessionCreateManyArgs} args - Arguments to create many NextAuthSessions.
     * @example
     * // Create many NextAuthSessions
     * const nextAuthSession = await prisma.nextAuthSession.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends NextAuthSessionCreateManyArgs>(args?: SelectSubset<T, NextAuthSessionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many NextAuthSessions and returns the data saved in the database.
     * @param {NextAuthSessionCreateManyAndReturnArgs} args - Arguments to create many NextAuthSessions.
     * @example
     * // Create many NextAuthSessions
     * const nextAuthSession = await prisma.nextAuthSession.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many NextAuthSessions and only return the `id`
     * const nextAuthSessionWithIdOnly = await prisma.nextAuthSession.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends NextAuthSessionCreateManyAndReturnArgs>(args?: SelectSubset<T, NextAuthSessionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a NextAuthSession.
     * @param {NextAuthSessionDeleteArgs} args - Arguments to delete one NextAuthSession.
     * @example
     * // Delete one NextAuthSession
     * const NextAuthSession = await prisma.nextAuthSession.delete({
     *   where: {
     *     // ... filter to delete one NextAuthSession
     *   }
     * })
     * 
     */
    delete<T extends NextAuthSessionDeleteArgs>(args: SelectSubset<T, NextAuthSessionDeleteArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one NextAuthSession.
     * @param {NextAuthSessionUpdateArgs} args - Arguments to update one NextAuthSession.
     * @example
     * // Update one NextAuthSession
     * const nextAuthSession = await prisma.nextAuthSession.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends NextAuthSessionUpdateArgs>(args: SelectSubset<T, NextAuthSessionUpdateArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more NextAuthSessions.
     * @param {NextAuthSessionDeleteManyArgs} args - Arguments to filter NextAuthSessions to delete.
     * @example
     * // Delete a few NextAuthSessions
     * const { count } = await prisma.nextAuthSession.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends NextAuthSessionDeleteManyArgs>(args?: SelectSubset<T, NextAuthSessionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more NextAuthSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NextAuthSessionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many NextAuthSessions
     * const nextAuthSession = await prisma.nextAuthSession.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends NextAuthSessionUpdateManyArgs>(args: SelectSubset<T, NextAuthSessionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more NextAuthSessions and returns the data updated in the database.
     * @param {NextAuthSessionUpdateManyAndReturnArgs} args - Arguments to update many NextAuthSessions.
     * @example
     * // Update many NextAuthSessions
     * const nextAuthSession = await prisma.nextAuthSession.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more NextAuthSessions and only return the `id`
     * const nextAuthSessionWithIdOnly = await prisma.nextAuthSession.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends NextAuthSessionUpdateManyAndReturnArgs>(args: SelectSubset<T, NextAuthSessionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one NextAuthSession.
     * @param {NextAuthSessionUpsertArgs} args - Arguments to update or create a NextAuthSession.
     * @example
     * // Update or create a NextAuthSession
     * const nextAuthSession = await prisma.nextAuthSession.upsert({
     *   create: {
     *     // ... data to create a NextAuthSession
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the NextAuthSession we want to update
     *   }
     * })
     */
    upsert<T extends NextAuthSessionUpsertArgs>(args: SelectSubset<T, NextAuthSessionUpsertArgs<ExtArgs>>): Prisma__NextAuthSessionClient<$Result.GetResult<Prisma.$NextAuthSessionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of NextAuthSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NextAuthSessionCountArgs} args - Arguments to filter NextAuthSessions to count.
     * @example
     * // Count the number of NextAuthSessions
     * const count = await prisma.nextAuthSession.count({
     *   where: {
     *     // ... the filter for the NextAuthSessions we want to count
     *   }
     * })
    **/
    count<T extends NextAuthSessionCountArgs>(
      args?: Subset<T, NextAuthSessionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], NextAuthSessionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a NextAuthSession.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NextAuthSessionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends NextAuthSessionAggregateArgs>(args: Subset<T, NextAuthSessionAggregateArgs>): Prisma.PrismaPromise<GetNextAuthSessionAggregateType<T>>

    /**
     * Group by NextAuthSession.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {NextAuthSessionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends NextAuthSessionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: NextAuthSessionGroupByArgs['orderBy'] }
        : { orderBy?: NextAuthSessionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, NextAuthSessionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetNextAuthSessionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the NextAuthSession model
   */
  readonly fields: NextAuthSessionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for NextAuthSession.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__NextAuthSessionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the NextAuthSession model
   */
  interface NextAuthSessionFieldRefs {
    readonly id: FieldRef<"NextAuthSession", 'String'>
    readonly sessionToken: FieldRef<"NextAuthSession", 'String'>
    readonly userId: FieldRef<"NextAuthSession", 'String'>
    readonly expires: FieldRef<"NextAuthSession", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * NextAuthSession findUnique
   */
  export type NextAuthSessionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * Filter, which NextAuthSession to fetch.
     */
    where: NextAuthSessionWhereUniqueInput
  }

  /**
   * NextAuthSession findUniqueOrThrow
   */
  export type NextAuthSessionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * Filter, which NextAuthSession to fetch.
     */
    where: NextAuthSessionWhereUniqueInput
  }

  /**
   * NextAuthSession findFirst
   */
  export type NextAuthSessionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * Filter, which NextAuthSession to fetch.
     */
    where?: NextAuthSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NextAuthSessions to fetch.
     */
    orderBy?: NextAuthSessionOrderByWithRelationInput | NextAuthSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for NextAuthSessions.
     */
    cursor?: NextAuthSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NextAuthSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NextAuthSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of NextAuthSessions.
     */
    distinct?: NextAuthSessionScalarFieldEnum | NextAuthSessionScalarFieldEnum[]
  }

  /**
   * NextAuthSession findFirstOrThrow
   */
  export type NextAuthSessionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * Filter, which NextAuthSession to fetch.
     */
    where?: NextAuthSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NextAuthSessions to fetch.
     */
    orderBy?: NextAuthSessionOrderByWithRelationInput | NextAuthSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for NextAuthSessions.
     */
    cursor?: NextAuthSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NextAuthSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NextAuthSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of NextAuthSessions.
     */
    distinct?: NextAuthSessionScalarFieldEnum | NextAuthSessionScalarFieldEnum[]
  }

  /**
   * NextAuthSession findMany
   */
  export type NextAuthSessionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * Filter, which NextAuthSessions to fetch.
     */
    where?: NextAuthSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of NextAuthSessions to fetch.
     */
    orderBy?: NextAuthSessionOrderByWithRelationInput | NextAuthSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing NextAuthSessions.
     */
    cursor?: NextAuthSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` NextAuthSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` NextAuthSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of NextAuthSessions.
     */
    distinct?: NextAuthSessionScalarFieldEnum | NextAuthSessionScalarFieldEnum[]
  }

  /**
   * NextAuthSession create
   */
  export type NextAuthSessionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * The data needed to create a NextAuthSession.
     */
    data: XOR<NextAuthSessionCreateInput, NextAuthSessionUncheckedCreateInput>
  }

  /**
   * NextAuthSession createMany
   */
  export type NextAuthSessionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many NextAuthSessions.
     */
    data: NextAuthSessionCreateManyInput | NextAuthSessionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * NextAuthSession createManyAndReturn
   */
  export type NextAuthSessionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * The data used to create many NextAuthSessions.
     */
    data: NextAuthSessionCreateManyInput | NextAuthSessionCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * NextAuthSession update
   */
  export type NextAuthSessionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * The data needed to update a NextAuthSession.
     */
    data: XOR<NextAuthSessionUpdateInput, NextAuthSessionUncheckedUpdateInput>
    /**
     * Choose, which NextAuthSession to update.
     */
    where: NextAuthSessionWhereUniqueInput
  }

  /**
   * NextAuthSession updateMany
   */
  export type NextAuthSessionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update NextAuthSessions.
     */
    data: XOR<NextAuthSessionUpdateManyMutationInput, NextAuthSessionUncheckedUpdateManyInput>
    /**
     * Filter which NextAuthSessions to update
     */
    where?: NextAuthSessionWhereInput
    /**
     * Limit how many NextAuthSessions to update.
     */
    limit?: number
  }

  /**
   * NextAuthSession updateManyAndReturn
   */
  export type NextAuthSessionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * The data used to update NextAuthSessions.
     */
    data: XOR<NextAuthSessionUpdateManyMutationInput, NextAuthSessionUncheckedUpdateManyInput>
    /**
     * Filter which NextAuthSessions to update
     */
    where?: NextAuthSessionWhereInput
    /**
     * Limit how many NextAuthSessions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * NextAuthSession upsert
   */
  export type NextAuthSessionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * The filter to search for the NextAuthSession to update in case it exists.
     */
    where: NextAuthSessionWhereUniqueInput
    /**
     * In case the NextAuthSession found by the `where` argument doesn't exist, create a new NextAuthSession with this data.
     */
    create: XOR<NextAuthSessionCreateInput, NextAuthSessionUncheckedCreateInput>
    /**
     * In case the NextAuthSession was found with the provided `where` argument, update it with this data.
     */
    update: XOR<NextAuthSessionUpdateInput, NextAuthSessionUncheckedUpdateInput>
  }

  /**
   * NextAuthSession delete
   */
  export type NextAuthSessionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
    /**
     * Filter which NextAuthSession to delete.
     */
    where: NextAuthSessionWhereUniqueInput
  }

  /**
   * NextAuthSession deleteMany
   */
  export type NextAuthSessionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which NextAuthSessions to delete
     */
    where?: NextAuthSessionWhereInput
    /**
     * Limit how many NextAuthSessions to delete.
     */
    limit?: number
  }

  /**
   * NextAuthSession without action
   */
  export type NextAuthSessionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the NextAuthSession
     */
    select?: NextAuthSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the NextAuthSession
     */
    omit?: NextAuthSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: NextAuthSessionInclude<ExtArgs> | null
  }


  /**
   * Model VerificationToken
   */

  export type AggregateVerificationToken = {
    _count: VerificationTokenCountAggregateOutputType | null
    _min: VerificationTokenMinAggregateOutputType | null
    _max: VerificationTokenMaxAggregateOutputType | null
  }

  export type VerificationTokenMinAggregateOutputType = {
    identifier: string | null
    token: string | null
    expires: Date | null
  }

  export type VerificationTokenMaxAggregateOutputType = {
    identifier: string | null
    token: string | null
    expires: Date | null
  }

  export type VerificationTokenCountAggregateOutputType = {
    identifier: number
    token: number
    expires: number
    _all: number
  }


  export type VerificationTokenMinAggregateInputType = {
    identifier?: true
    token?: true
    expires?: true
  }

  export type VerificationTokenMaxAggregateInputType = {
    identifier?: true
    token?: true
    expires?: true
  }

  export type VerificationTokenCountAggregateInputType = {
    identifier?: true
    token?: true
    expires?: true
    _all?: true
  }

  export type VerificationTokenAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VerificationToken to aggregate.
     */
    where?: VerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VerificationTokens to fetch.
     */
    orderBy?: VerificationTokenOrderByWithRelationInput | VerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VerificationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned VerificationTokens
    **/
    _count?: true | VerificationTokenCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VerificationTokenMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VerificationTokenMaxAggregateInputType
  }

  export type GetVerificationTokenAggregateType<T extends VerificationTokenAggregateArgs> = {
        [P in keyof T & keyof AggregateVerificationToken]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVerificationToken[P]>
      : GetScalarType<T[P], AggregateVerificationToken[P]>
  }




  export type VerificationTokenGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VerificationTokenWhereInput
    orderBy?: VerificationTokenOrderByWithAggregationInput | VerificationTokenOrderByWithAggregationInput[]
    by: VerificationTokenScalarFieldEnum[] | VerificationTokenScalarFieldEnum
    having?: VerificationTokenScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VerificationTokenCountAggregateInputType | true
    _min?: VerificationTokenMinAggregateInputType
    _max?: VerificationTokenMaxAggregateInputType
  }

  export type VerificationTokenGroupByOutputType = {
    identifier: string
    token: string
    expires: Date
    _count: VerificationTokenCountAggregateOutputType | null
    _min: VerificationTokenMinAggregateOutputType | null
    _max: VerificationTokenMaxAggregateOutputType | null
  }

  type GetVerificationTokenGroupByPayload<T extends VerificationTokenGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VerificationTokenGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VerificationTokenGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VerificationTokenGroupByOutputType[P]>
            : GetScalarType<T[P], VerificationTokenGroupByOutputType[P]>
        }
      >
    >


  export type VerificationTokenSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    identifier?: boolean
    token?: boolean
    expires?: boolean
  }, ExtArgs["result"]["verificationToken"]>

  export type VerificationTokenSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    identifier?: boolean
    token?: boolean
    expires?: boolean
  }, ExtArgs["result"]["verificationToken"]>

  export type VerificationTokenSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    identifier?: boolean
    token?: boolean
    expires?: boolean
  }, ExtArgs["result"]["verificationToken"]>

  export type VerificationTokenSelectScalar = {
    identifier?: boolean
    token?: boolean
    expires?: boolean
  }

  export type VerificationTokenOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"identifier" | "token" | "expires", ExtArgs["result"]["verificationToken"]>

  export type $VerificationTokenPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "VerificationToken"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      identifier: string
      token: string
      expires: Date
    }, ExtArgs["result"]["verificationToken"]>
    composites: {}
  }

  type VerificationTokenGetPayload<S extends boolean | null | undefined | VerificationTokenDefaultArgs> = $Result.GetResult<Prisma.$VerificationTokenPayload, S>

  type VerificationTokenCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VerificationTokenFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VerificationTokenCountAggregateInputType | true
    }

  export interface VerificationTokenDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['VerificationToken'], meta: { name: 'VerificationToken' } }
    /**
     * Find zero or one VerificationToken that matches the filter.
     * @param {VerificationTokenFindUniqueArgs} args - Arguments to find a VerificationToken
     * @example
     * // Get one VerificationToken
     * const verificationToken = await prisma.verificationToken.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VerificationTokenFindUniqueArgs>(args: SelectSubset<T, VerificationTokenFindUniqueArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one VerificationToken that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VerificationTokenFindUniqueOrThrowArgs} args - Arguments to find a VerificationToken
     * @example
     * // Get one VerificationToken
     * const verificationToken = await prisma.verificationToken.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VerificationTokenFindUniqueOrThrowArgs>(args: SelectSubset<T, VerificationTokenFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VerificationToken that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VerificationTokenFindFirstArgs} args - Arguments to find a VerificationToken
     * @example
     * // Get one VerificationToken
     * const verificationToken = await prisma.verificationToken.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VerificationTokenFindFirstArgs>(args?: SelectSubset<T, VerificationTokenFindFirstArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VerificationToken that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VerificationTokenFindFirstOrThrowArgs} args - Arguments to find a VerificationToken
     * @example
     * // Get one VerificationToken
     * const verificationToken = await prisma.verificationToken.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VerificationTokenFindFirstOrThrowArgs>(args?: SelectSubset<T, VerificationTokenFindFirstOrThrowArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more VerificationTokens that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VerificationTokenFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VerificationTokens
     * const verificationTokens = await prisma.verificationToken.findMany()
     * 
     * // Get first 10 VerificationTokens
     * const verificationTokens = await prisma.verificationToken.findMany({ take: 10 })
     * 
     * // Only select the `identifier`
     * const verificationTokenWithIdentifierOnly = await prisma.verificationToken.findMany({ select: { identifier: true } })
     * 
     */
    findMany<T extends VerificationTokenFindManyArgs>(args?: SelectSubset<T, VerificationTokenFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a VerificationToken.
     * @param {VerificationTokenCreateArgs} args - Arguments to create a VerificationToken.
     * @example
     * // Create one VerificationToken
     * const VerificationToken = await prisma.verificationToken.create({
     *   data: {
     *     // ... data to create a VerificationToken
     *   }
     * })
     * 
     */
    create<T extends VerificationTokenCreateArgs>(args: SelectSubset<T, VerificationTokenCreateArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many VerificationTokens.
     * @param {VerificationTokenCreateManyArgs} args - Arguments to create many VerificationTokens.
     * @example
     * // Create many VerificationTokens
     * const verificationToken = await prisma.verificationToken.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VerificationTokenCreateManyArgs>(args?: SelectSubset<T, VerificationTokenCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many VerificationTokens and returns the data saved in the database.
     * @param {VerificationTokenCreateManyAndReturnArgs} args - Arguments to create many VerificationTokens.
     * @example
     * // Create many VerificationTokens
     * const verificationToken = await prisma.verificationToken.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many VerificationTokens and only return the `identifier`
     * const verificationTokenWithIdentifierOnly = await prisma.verificationToken.createManyAndReturn({
     *   select: { identifier: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends VerificationTokenCreateManyAndReturnArgs>(args?: SelectSubset<T, VerificationTokenCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a VerificationToken.
     * @param {VerificationTokenDeleteArgs} args - Arguments to delete one VerificationToken.
     * @example
     * // Delete one VerificationToken
     * const VerificationToken = await prisma.verificationToken.delete({
     *   where: {
     *     // ... filter to delete one VerificationToken
     *   }
     * })
     * 
     */
    delete<T extends VerificationTokenDeleteArgs>(args: SelectSubset<T, VerificationTokenDeleteArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one VerificationToken.
     * @param {VerificationTokenUpdateArgs} args - Arguments to update one VerificationToken.
     * @example
     * // Update one VerificationToken
     * const verificationToken = await prisma.verificationToken.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VerificationTokenUpdateArgs>(args: SelectSubset<T, VerificationTokenUpdateArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more VerificationTokens.
     * @param {VerificationTokenDeleteManyArgs} args - Arguments to filter VerificationTokens to delete.
     * @example
     * // Delete a few VerificationTokens
     * const { count } = await prisma.verificationToken.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VerificationTokenDeleteManyArgs>(args?: SelectSubset<T, VerificationTokenDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VerificationTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VerificationTokenUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VerificationTokens
     * const verificationToken = await prisma.verificationToken.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VerificationTokenUpdateManyArgs>(args: SelectSubset<T, VerificationTokenUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VerificationTokens and returns the data updated in the database.
     * @param {VerificationTokenUpdateManyAndReturnArgs} args - Arguments to update many VerificationTokens.
     * @example
     * // Update many VerificationTokens
     * const verificationToken = await prisma.verificationToken.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more VerificationTokens and only return the `identifier`
     * const verificationTokenWithIdentifierOnly = await prisma.verificationToken.updateManyAndReturn({
     *   select: { identifier: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends VerificationTokenUpdateManyAndReturnArgs>(args: SelectSubset<T, VerificationTokenUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one VerificationToken.
     * @param {VerificationTokenUpsertArgs} args - Arguments to update or create a VerificationToken.
     * @example
     * // Update or create a VerificationToken
     * const verificationToken = await prisma.verificationToken.upsert({
     *   create: {
     *     // ... data to create a VerificationToken
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VerificationToken we want to update
     *   }
     * })
     */
    upsert<T extends VerificationTokenUpsertArgs>(args: SelectSubset<T, VerificationTokenUpsertArgs<ExtArgs>>): Prisma__VerificationTokenClient<$Result.GetResult<Prisma.$VerificationTokenPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of VerificationTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VerificationTokenCountArgs} args - Arguments to filter VerificationTokens to count.
     * @example
     * // Count the number of VerificationTokens
     * const count = await prisma.verificationToken.count({
     *   where: {
     *     // ... the filter for the VerificationTokens we want to count
     *   }
     * })
    **/
    count<T extends VerificationTokenCountArgs>(
      args?: Subset<T, VerificationTokenCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VerificationTokenCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VerificationToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VerificationTokenAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VerificationTokenAggregateArgs>(args: Subset<T, VerificationTokenAggregateArgs>): Prisma.PrismaPromise<GetVerificationTokenAggregateType<T>>

    /**
     * Group by VerificationToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VerificationTokenGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VerificationTokenGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VerificationTokenGroupByArgs['orderBy'] }
        : { orderBy?: VerificationTokenGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VerificationTokenGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVerificationTokenGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the VerificationToken model
   */
  readonly fields: VerificationTokenFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for VerificationToken.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VerificationTokenClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the VerificationToken model
   */
  interface VerificationTokenFieldRefs {
    readonly identifier: FieldRef<"VerificationToken", 'String'>
    readonly token: FieldRef<"VerificationToken", 'String'>
    readonly expires: FieldRef<"VerificationToken", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * VerificationToken findUnique
   */
  export type VerificationTokenFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * Filter, which VerificationToken to fetch.
     */
    where: VerificationTokenWhereUniqueInput
  }

  /**
   * VerificationToken findUniqueOrThrow
   */
  export type VerificationTokenFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * Filter, which VerificationToken to fetch.
     */
    where: VerificationTokenWhereUniqueInput
  }

  /**
   * VerificationToken findFirst
   */
  export type VerificationTokenFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * Filter, which VerificationToken to fetch.
     */
    where?: VerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VerificationTokens to fetch.
     */
    orderBy?: VerificationTokenOrderByWithRelationInput | VerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VerificationTokens.
     */
    cursor?: VerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VerificationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VerificationTokens.
     */
    distinct?: VerificationTokenScalarFieldEnum | VerificationTokenScalarFieldEnum[]
  }

  /**
   * VerificationToken findFirstOrThrow
   */
  export type VerificationTokenFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * Filter, which VerificationToken to fetch.
     */
    where?: VerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VerificationTokens to fetch.
     */
    orderBy?: VerificationTokenOrderByWithRelationInput | VerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VerificationTokens.
     */
    cursor?: VerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VerificationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VerificationTokens.
     */
    distinct?: VerificationTokenScalarFieldEnum | VerificationTokenScalarFieldEnum[]
  }

  /**
   * VerificationToken findMany
   */
  export type VerificationTokenFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * Filter, which VerificationTokens to fetch.
     */
    where?: VerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VerificationTokens to fetch.
     */
    orderBy?: VerificationTokenOrderByWithRelationInput | VerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing VerificationTokens.
     */
    cursor?: VerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VerificationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VerificationTokens.
     */
    distinct?: VerificationTokenScalarFieldEnum | VerificationTokenScalarFieldEnum[]
  }

  /**
   * VerificationToken create
   */
  export type VerificationTokenCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * The data needed to create a VerificationToken.
     */
    data: XOR<VerificationTokenCreateInput, VerificationTokenUncheckedCreateInput>
  }

  /**
   * VerificationToken createMany
   */
  export type VerificationTokenCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many VerificationTokens.
     */
    data: VerificationTokenCreateManyInput | VerificationTokenCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * VerificationToken createManyAndReturn
   */
  export type VerificationTokenCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * The data used to create many VerificationTokens.
     */
    data: VerificationTokenCreateManyInput | VerificationTokenCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * VerificationToken update
   */
  export type VerificationTokenUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * The data needed to update a VerificationToken.
     */
    data: XOR<VerificationTokenUpdateInput, VerificationTokenUncheckedUpdateInput>
    /**
     * Choose, which VerificationToken to update.
     */
    where: VerificationTokenWhereUniqueInput
  }

  /**
   * VerificationToken updateMany
   */
  export type VerificationTokenUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update VerificationTokens.
     */
    data: XOR<VerificationTokenUpdateManyMutationInput, VerificationTokenUncheckedUpdateManyInput>
    /**
     * Filter which VerificationTokens to update
     */
    where?: VerificationTokenWhereInput
    /**
     * Limit how many VerificationTokens to update.
     */
    limit?: number
  }

  /**
   * VerificationToken updateManyAndReturn
   */
  export type VerificationTokenUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * The data used to update VerificationTokens.
     */
    data: XOR<VerificationTokenUpdateManyMutationInput, VerificationTokenUncheckedUpdateManyInput>
    /**
     * Filter which VerificationTokens to update
     */
    where?: VerificationTokenWhereInput
    /**
     * Limit how many VerificationTokens to update.
     */
    limit?: number
  }

  /**
   * VerificationToken upsert
   */
  export type VerificationTokenUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * The filter to search for the VerificationToken to update in case it exists.
     */
    where: VerificationTokenWhereUniqueInput
    /**
     * In case the VerificationToken found by the `where` argument doesn't exist, create a new VerificationToken with this data.
     */
    create: XOR<VerificationTokenCreateInput, VerificationTokenUncheckedCreateInput>
    /**
     * In case the VerificationToken was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VerificationTokenUpdateInput, VerificationTokenUncheckedUpdateInput>
  }

  /**
   * VerificationToken delete
   */
  export type VerificationTokenDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
    /**
     * Filter which VerificationToken to delete.
     */
    where: VerificationTokenWhereUniqueInput
  }

  /**
   * VerificationToken deleteMany
   */
  export type VerificationTokenDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VerificationTokens to delete
     */
    where?: VerificationTokenWhereInput
    /**
     * Limit how many VerificationTokens to delete.
     */
    limit?: number
  }

  /**
   * VerificationToken without action
   */
  export type VerificationTokenDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VerificationToken
     */
    select?: VerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VerificationToken
     */
    omit?: VerificationTokenOmit<ExtArgs> | null
  }


  /**
   * Model Equipment
   */

  export type AggregateEquipment = {
    _count: EquipmentCountAggregateOutputType | null
    _min: EquipmentMinAggregateOutputType | null
    _max: EquipmentMaxAggregateOutputType | null
  }

  export type EquipmentMinAggregateOutputType = {
    id: string | null
    name: string | null
    category: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type EquipmentMaxAggregateOutputType = {
    id: string | null
    name: string | null
    category: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type EquipmentCountAggregateOutputType = {
    id: number
    name: number
    category: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type EquipmentMinAggregateInputType = {
    id?: true
    name?: true
    category?: true
    createdAt?: true
    updatedAt?: true
  }

  export type EquipmentMaxAggregateInputType = {
    id?: true
    name?: true
    category?: true
    createdAt?: true
    updatedAt?: true
  }

  export type EquipmentCountAggregateInputType = {
    id?: true
    name?: true
    category?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type EquipmentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Equipment to aggregate.
     */
    where?: EquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Equipment to fetch.
     */
    orderBy?: EquipmentOrderByWithRelationInput | EquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Equipment from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Equipment.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Equipment
    **/
    _count?: true | EquipmentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EquipmentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EquipmentMaxAggregateInputType
  }

  export type GetEquipmentAggregateType<T extends EquipmentAggregateArgs> = {
        [P in keyof T & keyof AggregateEquipment]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEquipment[P]>
      : GetScalarType<T[P], AggregateEquipment[P]>
  }




  export type EquipmentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EquipmentWhereInput
    orderBy?: EquipmentOrderByWithAggregationInput | EquipmentOrderByWithAggregationInput[]
    by: EquipmentScalarFieldEnum[] | EquipmentScalarFieldEnum
    having?: EquipmentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EquipmentCountAggregateInputType | true
    _min?: EquipmentMinAggregateInputType
    _max?: EquipmentMaxAggregateInputType
  }

  export type EquipmentGroupByOutputType = {
    id: string
    name: string
    category: string
    createdAt: Date
    updatedAt: Date
    _count: EquipmentCountAggregateOutputType | null
    _min: EquipmentMinAggregateOutputType | null
    _max: EquipmentMaxAggregateOutputType | null
  }

  type GetEquipmentGroupByPayload<T extends EquipmentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EquipmentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EquipmentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EquipmentGroupByOutputType[P]>
            : GetScalarType<T[P], EquipmentGroupByOutputType[P]>
        }
      >
    >


  export type EquipmentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    category?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    userEquipment?: boolean | Equipment$userEquipmentArgs<ExtArgs>
    exercises?: boolean | Equipment$exercisesArgs<ExtArgs>
    workoutPlans?: boolean | Equipment$workoutPlansArgs<ExtArgs>
    _count?: boolean | EquipmentCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["equipment"]>

  export type EquipmentSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    category?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["equipment"]>

  export type EquipmentSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    category?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["equipment"]>

  export type EquipmentSelectScalar = {
    id?: boolean
    name?: boolean
    category?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type EquipmentOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "category" | "createdAt" | "updatedAt", ExtArgs["result"]["equipment"]>
  export type EquipmentInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    userEquipment?: boolean | Equipment$userEquipmentArgs<ExtArgs>
    exercises?: boolean | Equipment$exercisesArgs<ExtArgs>
    workoutPlans?: boolean | Equipment$workoutPlansArgs<ExtArgs>
    _count?: boolean | EquipmentCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type EquipmentIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type EquipmentIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $EquipmentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Equipment"
    objects: {
      userEquipment: Prisma.$UserEquipmentPayload<ExtArgs>[]
      exercises: Prisma.$ExercisePayload<ExtArgs>[]
      workoutPlans: Prisma.$WorkoutPlanPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      category: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["equipment"]>
    composites: {}
  }

  type EquipmentGetPayload<S extends boolean | null | undefined | EquipmentDefaultArgs> = $Result.GetResult<Prisma.$EquipmentPayload, S>

  type EquipmentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<EquipmentFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EquipmentCountAggregateInputType | true
    }

  export interface EquipmentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Equipment'], meta: { name: 'Equipment' } }
    /**
     * Find zero or one Equipment that matches the filter.
     * @param {EquipmentFindUniqueArgs} args - Arguments to find a Equipment
     * @example
     * // Get one Equipment
     * const equipment = await prisma.equipment.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EquipmentFindUniqueArgs>(args: SelectSubset<T, EquipmentFindUniqueArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Equipment that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {EquipmentFindUniqueOrThrowArgs} args - Arguments to find a Equipment
     * @example
     * // Get one Equipment
     * const equipment = await prisma.equipment.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EquipmentFindUniqueOrThrowArgs>(args: SelectSubset<T, EquipmentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Equipment that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EquipmentFindFirstArgs} args - Arguments to find a Equipment
     * @example
     * // Get one Equipment
     * const equipment = await prisma.equipment.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EquipmentFindFirstArgs>(args?: SelectSubset<T, EquipmentFindFirstArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Equipment that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EquipmentFindFirstOrThrowArgs} args - Arguments to find a Equipment
     * @example
     * // Get one Equipment
     * const equipment = await prisma.equipment.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EquipmentFindFirstOrThrowArgs>(args?: SelectSubset<T, EquipmentFindFirstOrThrowArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Equipment that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EquipmentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Equipment
     * const equipment = await prisma.equipment.findMany()
     * 
     * // Get first 10 Equipment
     * const equipment = await prisma.equipment.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const equipmentWithIdOnly = await prisma.equipment.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends EquipmentFindManyArgs>(args?: SelectSubset<T, EquipmentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Equipment.
     * @param {EquipmentCreateArgs} args - Arguments to create a Equipment.
     * @example
     * // Create one Equipment
     * const Equipment = await prisma.equipment.create({
     *   data: {
     *     // ... data to create a Equipment
     *   }
     * })
     * 
     */
    create<T extends EquipmentCreateArgs>(args: SelectSubset<T, EquipmentCreateArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Equipment.
     * @param {EquipmentCreateManyArgs} args - Arguments to create many Equipment.
     * @example
     * // Create many Equipment
     * const equipment = await prisma.equipment.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EquipmentCreateManyArgs>(args?: SelectSubset<T, EquipmentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Equipment and returns the data saved in the database.
     * @param {EquipmentCreateManyAndReturnArgs} args - Arguments to create many Equipment.
     * @example
     * // Create many Equipment
     * const equipment = await prisma.equipment.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Equipment and only return the `id`
     * const equipmentWithIdOnly = await prisma.equipment.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends EquipmentCreateManyAndReturnArgs>(args?: SelectSubset<T, EquipmentCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Equipment.
     * @param {EquipmentDeleteArgs} args - Arguments to delete one Equipment.
     * @example
     * // Delete one Equipment
     * const Equipment = await prisma.equipment.delete({
     *   where: {
     *     // ... filter to delete one Equipment
     *   }
     * })
     * 
     */
    delete<T extends EquipmentDeleteArgs>(args: SelectSubset<T, EquipmentDeleteArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Equipment.
     * @param {EquipmentUpdateArgs} args - Arguments to update one Equipment.
     * @example
     * // Update one Equipment
     * const equipment = await prisma.equipment.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EquipmentUpdateArgs>(args: SelectSubset<T, EquipmentUpdateArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Equipment.
     * @param {EquipmentDeleteManyArgs} args - Arguments to filter Equipment to delete.
     * @example
     * // Delete a few Equipment
     * const { count } = await prisma.equipment.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EquipmentDeleteManyArgs>(args?: SelectSubset<T, EquipmentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Equipment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EquipmentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Equipment
     * const equipment = await prisma.equipment.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EquipmentUpdateManyArgs>(args: SelectSubset<T, EquipmentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Equipment and returns the data updated in the database.
     * @param {EquipmentUpdateManyAndReturnArgs} args - Arguments to update many Equipment.
     * @example
     * // Update many Equipment
     * const equipment = await prisma.equipment.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Equipment and only return the `id`
     * const equipmentWithIdOnly = await prisma.equipment.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends EquipmentUpdateManyAndReturnArgs>(args: SelectSubset<T, EquipmentUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Equipment.
     * @param {EquipmentUpsertArgs} args - Arguments to update or create a Equipment.
     * @example
     * // Update or create a Equipment
     * const equipment = await prisma.equipment.upsert({
     *   create: {
     *     // ... data to create a Equipment
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Equipment we want to update
     *   }
     * })
     */
    upsert<T extends EquipmentUpsertArgs>(args: SelectSubset<T, EquipmentUpsertArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Equipment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EquipmentCountArgs} args - Arguments to filter Equipment to count.
     * @example
     * // Count the number of Equipment
     * const count = await prisma.equipment.count({
     *   where: {
     *     // ... the filter for the Equipment we want to count
     *   }
     * })
    **/
    count<T extends EquipmentCountArgs>(
      args?: Subset<T, EquipmentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EquipmentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Equipment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EquipmentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EquipmentAggregateArgs>(args: Subset<T, EquipmentAggregateArgs>): Prisma.PrismaPromise<GetEquipmentAggregateType<T>>

    /**
     * Group by Equipment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EquipmentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EquipmentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EquipmentGroupByArgs['orderBy'] }
        : { orderBy?: EquipmentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EquipmentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEquipmentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Equipment model
   */
  readonly fields: EquipmentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Equipment.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EquipmentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    userEquipment<T extends Equipment$userEquipmentArgs<ExtArgs> = {}>(args?: Subset<T, Equipment$userEquipmentArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    exercises<T extends Equipment$exercisesArgs<ExtArgs> = {}>(args?: Subset<T, Equipment$exercisesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    workoutPlans<T extends Equipment$workoutPlansArgs<ExtArgs> = {}>(args?: Subset<T, Equipment$workoutPlansArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Equipment model
   */
  interface EquipmentFieldRefs {
    readonly id: FieldRef<"Equipment", 'String'>
    readonly name: FieldRef<"Equipment", 'String'>
    readonly category: FieldRef<"Equipment", 'String'>
    readonly createdAt: FieldRef<"Equipment", 'DateTime'>
    readonly updatedAt: FieldRef<"Equipment", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Equipment findUnique
   */
  export type EquipmentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * Filter, which Equipment to fetch.
     */
    where: EquipmentWhereUniqueInput
  }

  /**
   * Equipment findUniqueOrThrow
   */
  export type EquipmentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * Filter, which Equipment to fetch.
     */
    where: EquipmentWhereUniqueInput
  }

  /**
   * Equipment findFirst
   */
  export type EquipmentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * Filter, which Equipment to fetch.
     */
    where?: EquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Equipment to fetch.
     */
    orderBy?: EquipmentOrderByWithRelationInput | EquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Equipment.
     */
    cursor?: EquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Equipment from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Equipment.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Equipment.
     */
    distinct?: EquipmentScalarFieldEnum | EquipmentScalarFieldEnum[]
  }

  /**
   * Equipment findFirstOrThrow
   */
  export type EquipmentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * Filter, which Equipment to fetch.
     */
    where?: EquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Equipment to fetch.
     */
    orderBy?: EquipmentOrderByWithRelationInput | EquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Equipment.
     */
    cursor?: EquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Equipment from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Equipment.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Equipment.
     */
    distinct?: EquipmentScalarFieldEnum | EquipmentScalarFieldEnum[]
  }

  /**
   * Equipment findMany
   */
  export type EquipmentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * Filter, which Equipment to fetch.
     */
    where?: EquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Equipment to fetch.
     */
    orderBy?: EquipmentOrderByWithRelationInput | EquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Equipment.
     */
    cursor?: EquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Equipment from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Equipment.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Equipment.
     */
    distinct?: EquipmentScalarFieldEnum | EquipmentScalarFieldEnum[]
  }

  /**
   * Equipment create
   */
  export type EquipmentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * The data needed to create a Equipment.
     */
    data: XOR<EquipmentCreateInput, EquipmentUncheckedCreateInput>
  }

  /**
   * Equipment createMany
   */
  export type EquipmentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Equipment.
     */
    data: EquipmentCreateManyInput | EquipmentCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Equipment createManyAndReturn
   */
  export type EquipmentCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * The data used to create many Equipment.
     */
    data: EquipmentCreateManyInput | EquipmentCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Equipment update
   */
  export type EquipmentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * The data needed to update a Equipment.
     */
    data: XOR<EquipmentUpdateInput, EquipmentUncheckedUpdateInput>
    /**
     * Choose, which Equipment to update.
     */
    where: EquipmentWhereUniqueInput
  }

  /**
   * Equipment updateMany
   */
  export type EquipmentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Equipment.
     */
    data: XOR<EquipmentUpdateManyMutationInput, EquipmentUncheckedUpdateManyInput>
    /**
     * Filter which Equipment to update
     */
    where?: EquipmentWhereInput
    /**
     * Limit how many Equipment to update.
     */
    limit?: number
  }

  /**
   * Equipment updateManyAndReturn
   */
  export type EquipmentUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * The data used to update Equipment.
     */
    data: XOR<EquipmentUpdateManyMutationInput, EquipmentUncheckedUpdateManyInput>
    /**
     * Filter which Equipment to update
     */
    where?: EquipmentWhereInput
    /**
     * Limit how many Equipment to update.
     */
    limit?: number
  }

  /**
   * Equipment upsert
   */
  export type EquipmentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * The filter to search for the Equipment to update in case it exists.
     */
    where: EquipmentWhereUniqueInput
    /**
     * In case the Equipment found by the `where` argument doesn't exist, create a new Equipment with this data.
     */
    create: XOR<EquipmentCreateInput, EquipmentUncheckedCreateInput>
    /**
     * In case the Equipment was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EquipmentUpdateInput, EquipmentUncheckedUpdateInput>
  }

  /**
   * Equipment delete
   */
  export type EquipmentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    /**
     * Filter which Equipment to delete.
     */
    where: EquipmentWhereUniqueInput
  }

  /**
   * Equipment deleteMany
   */
  export type EquipmentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Equipment to delete
     */
    where?: EquipmentWhereInput
    /**
     * Limit how many Equipment to delete.
     */
    limit?: number
  }

  /**
   * Equipment.userEquipment
   */
  export type Equipment$userEquipmentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    where?: UserEquipmentWhereInput
    orderBy?: UserEquipmentOrderByWithRelationInput | UserEquipmentOrderByWithRelationInput[]
    cursor?: UserEquipmentWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserEquipmentScalarFieldEnum | UserEquipmentScalarFieldEnum[]
  }

  /**
   * Equipment.exercises
   */
  export type Equipment$exercisesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    where?: ExerciseWhereInput
    orderBy?: ExerciseOrderByWithRelationInput | ExerciseOrderByWithRelationInput[]
    cursor?: ExerciseWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ExerciseScalarFieldEnum | ExerciseScalarFieldEnum[]
  }

  /**
   * Equipment.workoutPlans
   */
  export type Equipment$workoutPlansArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    where?: WorkoutPlanWhereInput
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    cursor?: WorkoutPlanWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * Equipment without action
   */
  export type EquipmentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
  }


  /**
   * Model Exercise
   */

  export type AggregateExercise = {
    _count: ExerciseCountAggregateOutputType | null
    _min: ExerciseMinAggregateOutputType | null
    _max: ExerciseMaxAggregateOutputType | null
  }

  export type ExerciseMinAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    youtubeUrl: string | null
    muscleGroup: $Enums.MuscleGroup | null
    equipmentId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ExerciseMaxAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    youtubeUrl: string | null
    muscleGroup: $Enums.MuscleGroup | null
    equipmentId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ExerciseCountAggregateOutputType = {
    id: number
    name: number
    description: number
    youtubeUrl: number
    musclesWorked: number
    muscleGroup: number
    equipmentId: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type ExerciseMinAggregateInputType = {
    id?: true
    name?: true
    description?: true
    youtubeUrl?: true
    muscleGroup?: true
    equipmentId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ExerciseMaxAggregateInputType = {
    id?: true
    name?: true
    description?: true
    youtubeUrl?: true
    muscleGroup?: true
    equipmentId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ExerciseCountAggregateInputType = {
    id?: true
    name?: true
    description?: true
    youtubeUrl?: true
    musclesWorked?: true
    muscleGroup?: true
    equipmentId?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type ExerciseAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Exercise to aggregate.
     */
    where?: ExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Exercises to fetch.
     */
    orderBy?: ExerciseOrderByWithRelationInput | ExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Exercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Exercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Exercises
    **/
    _count?: true | ExerciseCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ExerciseMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ExerciseMaxAggregateInputType
  }

  export type GetExerciseAggregateType<T extends ExerciseAggregateArgs> = {
        [P in keyof T & keyof AggregateExercise]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateExercise[P]>
      : GetScalarType<T[P], AggregateExercise[P]>
  }




  export type ExerciseGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExerciseWhereInput
    orderBy?: ExerciseOrderByWithAggregationInput | ExerciseOrderByWithAggregationInput[]
    by: ExerciseScalarFieldEnum[] | ExerciseScalarFieldEnum
    having?: ExerciseScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ExerciseCountAggregateInputType | true
    _min?: ExerciseMinAggregateInputType
    _max?: ExerciseMaxAggregateInputType
  }

  export type ExerciseGroupByOutputType = {
    id: string
    name: string
    description: string | null
    youtubeUrl: string | null
    musclesWorked: string[]
    muscleGroup: $Enums.MuscleGroup
    equipmentId: string | null
    createdAt: Date
    updatedAt: Date
    _count: ExerciseCountAggregateOutputType | null
    _min: ExerciseMinAggregateOutputType | null
    _max: ExerciseMaxAggregateOutputType | null
  }

  type GetExerciseGroupByPayload<T extends ExerciseGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ExerciseGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ExerciseGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ExerciseGroupByOutputType[P]>
            : GetScalarType<T[P], ExerciseGroupByOutputType[P]>
        }
      >
    >


  export type ExerciseSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    youtubeUrl?: boolean
    musclesWorked?: boolean
    muscleGroup?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    equipment?: boolean | Exercise$equipmentArgs<ExtArgs>
    plannedExercises?: boolean | Exercise$plannedExercisesArgs<ExtArgs>
    _count?: boolean | ExerciseCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["exercise"]>

  export type ExerciseSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    youtubeUrl?: boolean
    musclesWorked?: boolean
    muscleGroup?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    equipment?: boolean | Exercise$equipmentArgs<ExtArgs>
  }, ExtArgs["result"]["exercise"]>

  export type ExerciseSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    youtubeUrl?: boolean
    musclesWorked?: boolean
    muscleGroup?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    equipment?: boolean | Exercise$equipmentArgs<ExtArgs>
  }, ExtArgs["result"]["exercise"]>

  export type ExerciseSelectScalar = {
    id?: boolean
    name?: boolean
    description?: boolean
    youtubeUrl?: boolean
    musclesWorked?: boolean
    muscleGroup?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type ExerciseOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "description" | "youtubeUrl" | "musclesWorked" | "muscleGroup" | "equipmentId" | "createdAt" | "updatedAt", ExtArgs["result"]["exercise"]>
  export type ExerciseInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    equipment?: boolean | Exercise$equipmentArgs<ExtArgs>
    plannedExercises?: boolean | Exercise$plannedExercisesArgs<ExtArgs>
    _count?: boolean | ExerciseCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type ExerciseIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    equipment?: boolean | Exercise$equipmentArgs<ExtArgs>
  }
  export type ExerciseIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    equipment?: boolean | Exercise$equipmentArgs<ExtArgs>
  }

  export type $ExercisePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Exercise"
    objects: {
      equipment: Prisma.$EquipmentPayload<ExtArgs> | null
      plannedExercises: Prisma.$PlannedExercisePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      description: string | null
      youtubeUrl: string | null
      musclesWorked: string[]
      muscleGroup: $Enums.MuscleGroup
      equipmentId: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["exercise"]>
    composites: {}
  }

  type ExerciseGetPayload<S extends boolean | null | undefined | ExerciseDefaultArgs> = $Result.GetResult<Prisma.$ExercisePayload, S>

  type ExerciseCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ExerciseFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ExerciseCountAggregateInputType | true
    }

  export interface ExerciseDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Exercise'], meta: { name: 'Exercise' } }
    /**
     * Find zero or one Exercise that matches the filter.
     * @param {ExerciseFindUniqueArgs} args - Arguments to find a Exercise
     * @example
     * // Get one Exercise
     * const exercise = await prisma.exercise.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ExerciseFindUniqueArgs>(args: SelectSubset<T, ExerciseFindUniqueArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Exercise that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ExerciseFindUniqueOrThrowArgs} args - Arguments to find a Exercise
     * @example
     * // Get one Exercise
     * const exercise = await prisma.exercise.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ExerciseFindUniqueOrThrowArgs>(args: SelectSubset<T, ExerciseFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Exercise that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExerciseFindFirstArgs} args - Arguments to find a Exercise
     * @example
     * // Get one Exercise
     * const exercise = await prisma.exercise.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ExerciseFindFirstArgs>(args?: SelectSubset<T, ExerciseFindFirstArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Exercise that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExerciseFindFirstOrThrowArgs} args - Arguments to find a Exercise
     * @example
     * // Get one Exercise
     * const exercise = await prisma.exercise.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ExerciseFindFirstOrThrowArgs>(args?: SelectSubset<T, ExerciseFindFirstOrThrowArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Exercises that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExerciseFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Exercises
     * const exercises = await prisma.exercise.findMany()
     * 
     * // Get first 10 Exercises
     * const exercises = await prisma.exercise.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const exerciseWithIdOnly = await prisma.exercise.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ExerciseFindManyArgs>(args?: SelectSubset<T, ExerciseFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Exercise.
     * @param {ExerciseCreateArgs} args - Arguments to create a Exercise.
     * @example
     * // Create one Exercise
     * const Exercise = await prisma.exercise.create({
     *   data: {
     *     // ... data to create a Exercise
     *   }
     * })
     * 
     */
    create<T extends ExerciseCreateArgs>(args: SelectSubset<T, ExerciseCreateArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Exercises.
     * @param {ExerciseCreateManyArgs} args - Arguments to create many Exercises.
     * @example
     * // Create many Exercises
     * const exercise = await prisma.exercise.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ExerciseCreateManyArgs>(args?: SelectSubset<T, ExerciseCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Exercises and returns the data saved in the database.
     * @param {ExerciseCreateManyAndReturnArgs} args - Arguments to create many Exercises.
     * @example
     * // Create many Exercises
     * const exercise = await prisma.exercise.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Exercises and only return the `id`
     * const exerciseWithIdOnly = await prisma.exercise.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ExerciseCreateManyAndReturnArgs>(args?: SelectSubset<T, ExerciseCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Exercise.
     * @param {ExerciseDeleteArgs} args - Arguments to delete one Exercise.
     * @example
     * // Delete one Exercise
     * const Exercise = await prisma.exercise.delete({
     *   where: {
     *     // ... filter to delete one Exercise
     *   }
     * })
     * 
     */
    delete<T extends ExerciseDeleteArgs>(args: SelectSubset<T, ExerciseDeleteArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Exercise.
     * @param {ExerciseUpdateArgs} args - Arguments to update one Exercise.
     * @example
     * // Update one Exercise
     * const exercise = await prisma.exercise.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ExerciseUpdateArgs>(args: SelectSubset<T, ExerciseUpdateArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Exercises.
     * @param {ExerciseDeleteManyArgs} args - Arguments to filter Exercises to delete.
     * @example
     * // Delete a few Exercises
     * const { count } = await prisma.exercise.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ExerciseDeleteManyArgs>(args?: SelectSubset<T, ExerciseDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Exercises.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExerciseUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Exercises
     * const exercise = await prisma.exercise.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ExerciseUpdateManyArgs>(args: SelectSubset<T, ExerciseUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Exercises and returns the data updated in the database.
     * @param {ExerciseUpdateManyAndReturnArgs} args - Arguments to update many Exercises.
     * @example
     * // Update many Exercises
     * const exercise = await prisma.exercise.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Exercises and only return the `id`
     * const exerciseWithIdOnly = await prisma.exercise.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ExerciseUpdateManyAndReturnArgs>(args: SelectSubset<T, ExerciseUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Exercise.
     * @param {ExerciseUpsertArgs} args - Arguments to update or create a Exercise.
     * @example
     * // Update or create a Exercise
     * const exercise = await prisma.exercise.upsert({
     *   create: {
     *     // ... data to create a Exercise
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Exercise we want to update
     *   }
     * })
     */
    upsert<T extends ExerciseUpsertArgs>(args: SelectSubset<T, ExerciseUpsertArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Exercises.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExerciseCountArgs} args - Arguments to filter Exercises to count.
     * @example
     * // Count the number of Exercises
     * const count = await prisma.exercise.count({
     *   where: {
     *     // ... the filter for the Exercises we want to count
     *   }
     * })
    **/
    count<T extends ExerciseCountArgs>(
      args?: Subset<T, ExerciseCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ExerciseCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Exercise.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExerciseAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ExerciseAggregateArgs>(args: Subset<T, ExerciseAggregateArgs>): Prisma.PrismaPromise<GetExerciseAggregateType<T>>

    /**
     * Group by Exercise.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExerciseGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ExerciseGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ExerciseGroupByArgs['orderBy'] }
        : { orderBy?: ExerciseGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ExerciseGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetExerciseGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Exercise model
   */
  readonly fields: ExerciseFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Exercise.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ExerciseClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    equipment<T extends Exercise$equipmentArgs<ExtArgs> = {}>(args?: Subset<T, Exercise$equipmentArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    plannedExercises<T extends Exercise$plannedExercisesArgs<ExtArgs> = {}>(args?: Subset<T, Exercise$plannedExercisesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Exercise model
   */
  interface ExerciseFieldRefs {
    readonly id: FieldRef<"Exercise", 'String'>
    readonly name: FieldRef<"Exercise", 'String'>
    readonly description: FieldRef<"Exercise", 'String'>
    readonly youtubeUrl: FieldRef<"Exercise", 'String'>
    readonly musclesWorked: FieldRef<"Exercise", 'String[]'>
    readonly muscleGroup: FieldRef<"Exercise", 'MuscleGroup'>
    readonly equipmentId: FieldRef<"Exercise", 'String'>
    readonly createdAt: FieldRef<"Exercise", 'DateTime'>
    readonly updatedAt: FieldRef<"Exercise", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Exercise findUnique
   */
  export type ExerciseFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * Filter, which Exercise to fetch.
     */
    where: ExerciseWhereUniqueInput
  }

  /**
   * Exercise findUniqueOrThrow
   */
  export type ExerciseFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * Filter, which Exercise to fetch.
     */
    where: ExerciseWhereUniqueInput
  }

  /**
   * Exercise findFirst
   */
  export type ExerciseFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * Filter, which Exercise to fetch.
     */
    where?: ExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Exercises to fetch.
     */
    orderBy?: ExerciseOrderByWithRelationInput | ExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Exercises.
     */
    cursor?: ExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Exercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Exercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Exercises.
     */
    distinct?: ExerciseScalarFieldEnum | ExerciseScalarFieldEnum[]
  }

  /**
   * Exercise findFirstOrThrow
   */
  export type ExerciseFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * Filter, which Exercise to fetch.
     */
    where?: ExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Exercises to fetch.
     */
    orderBy?: ExerciseOrderByWithRelationInput | ExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Exercises.
     */
    cursor?: ExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Exercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Exercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Exercises.
     */
    distinct?: ExerciseScalarFieldEnum | ExerciseScalarFieldEnum[]
  }

  /**
   * Exercise findMany
   */
  export type ExerciseFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * Filter, which Exercises to fetch.
     */
    where?: ExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Exercises to fetch.
     */
    orderBy?: ExerciseOrderByWithRelationInput | ExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Exercises.
     */
    cursor?: ExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Exercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Exercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Exercises.
     */
    distinct?: ExerciseScalarFieldEnum | ExerciseScalarFieldEnum[]
  }

  /**
   * Exercise create
   */
  export type ExerciseCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * The data needed to create a Exercise.
     */
    data: XOR<ExerciseCreateInput, ExerciseUncheckedCreateInput>
  }

  /**
   * Exercise createMany
   */
  export type ExerciseCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Exercises.
     */
    data: ExerciseCreateManyInput | ExerciseCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Exercise createManyAndReturn
   */
  export type ExerciseCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * The data used to create many Exercises.
     */
    data: ExerciseCreateManyInput | ExerciseCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Exercise update
   */
  export type ExerciseUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * The data needed to update a Exercise.
     */
    data: XOR<ExerciseUpdateInput, ExerciseUncheckedUpdateInput>
    /**
     * Choose, which Exercise to update.
     */
    where: ExerciseWhereUniqueInput
  }

  /**
   * Exercise updateMany
   */
  export type ExerciseUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Exercises.
     */
    data: XOR<ExerciseUpdateManyMutationInput, ExerciseUncheckedUpdateManyInput>
    /**
     * Filter which Exercises to update
     */
    where?: ExerciseWhereInput
    /**
     * Limit how many Exercises to update.
     */
    limit?: number
  }

  /**
   * Exercise updateManyAndReturn
   */
  export type ExerciseUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * The data used to update Exercises.
     */
    data: XOR<ExerciseUpdateManyMutationInput, ExerciseUncheckedUpdateManyInput>
    /**
     * Filter which Exercises to update
     */
    where?: ExerciseWhereInput
    /**
     * Limit how many Exercises to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Exercise upsert
   */
  export type ExerciseUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * The filter to search for the Exercise to update in case it exists.
     */
    where: ExerciseWhereUniqueInput
    /**
     * In case the Exercise found by the `where` argument doesn't exist, create a new Exercise with this data.
     */
    create: XOR<ExerciseCreateInput, ExerciseUncheckedCreateInput>
    /**
     * In case the Exercise was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ExerciseUpdateInput, ExerciseUncheckedUpdateInput>
  }

  /**
   * Exercise delete
   */
  export type ExerciseDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
    /**
     * Filter which Exercise to delete.
     */
    where: ExerciseWhereUniqueInput
  }

  /**
   * Exercise deleteMany
   */
  export type ExerciseDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Exercises to delete
     */
    where?: ExerciseWhereInput
    /**
     * Limit how many Exercises to delete.
     */
    limit?: number
  }

  /**
   * Exercise.equipment
   */
  export type Exercise$equipmentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    where?: EquipmentWhereInput
  }

  /**
   * Exercise.plannedExercises
   */
  export type Exercise$plannedExercisesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    where?: PlannedExerciseWhereInput
    orderBy?: PlannedExerciseOrderByWithRelationInput | PlannedExerciseOrderByWithRelationInput[]
    cursor?: PlannedExerciseWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PlannedExerciseScalarFieldEnum | PlannedExerciseScalarFieldEnum[]
  }

  /**
   * Exercise without action
   */
  export type ExerciseDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Exercise
     */
    select?: ExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Exercise
     */
    omit?: ExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExerciseInclude<ExtArgs> | null
  }


  /**
   * Model WorkoutPlan
   */

  export type AggregateWorkoutPlan = {
    _count: WorkoutPlanCountAggregateOutputType | null
    _avg: WorkoutPlanAvgAggregateOutputType | null
    _sum: WorkoutPlanSumAggregateOutputType | null
    _min: WorkoutPlanMinAggregateOutputType | null
    _max: WorkoutPlanMaxAggregateOutputType | null
  }

  export type WorkoutPlanAvgAggregateOutputType = {
    durationWeeks: number | null
    sessionsPerWeek: number | null
  }

  export type WorkoutPlanSumAggregateOutputType = {
    durationWeeks: number | null
    sessionsPerWeek: number | null
  }

  export type WorkoutPlanMinAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    muscleGroup: $Enums.MuscleGroup | null
    durationWeeks: number | null
    sessionsPerWeek: number | null
    tier: $Enums.PlanTier | null
    equipmentId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WorkoutPlanMaxAggregateOutputType = {
    id: string | null
    name: string | null
    description: string | null
    muscleGroup: $Enums.MuscleGroup | null
    durationWeeks: number | null
    sessionsPerWeek: number | null
    tier: $Enums.PlanTier | null
    equipmentId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WorkoutPlanCountAggregateOutputType = {
    id: number
    name: number
    description: number
    muscleGroup: number
    durationWeeks: number
    sessionsPerWeek: number
    tier: number
    equipmentId: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type WorkoutPlanAvgAggregateInputType = {
    durationWeeks?: true
    sessionsPerWeek?: true
  }

  export type WorkoutPlanSumAggregateInputType = {
    durationWeeks?: true
    sessionsPerWeek?: true
  }

  export type WorkoutPlanMinAggregateInputType = {
    id?: true
    name?: true
    description?: true
    muscleGroup?: true
    durationWeeks?: true
    sessionsPerWeek?: true
    tier?: true
    equipmentId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WorkoutPlanMaxAggregateInputType = {
    id?: true
    name?: true
    description?: true
    muscleGroup?: true
    durationWeeks?: true
    sessionsPerWeek?: true
    tier?: true
    equipmentId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WorkoutPlanCountAggregateInputType = {
    id?: true
    name?: true
    description?: true
    muscleGroup?: true
    durationWeeks?: true
    sessionsPerWeek?: true
    tier?: true
    equipmentId?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type WorkoutPlanAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WorkoutPlan to aggregate.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned WorkoutPlans
    **/
    _count?: true | WorkoutPlanCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: WorkoutPlanAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: WorkoutPlanSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WorkoutPlanMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WorkoutPlanMaxAggregateInputType
  }

  export type GetWorkoutPlanAggregateType<T extends WorkoutPlanAggregateArgs> = {
        [P in keyof T & keyof AggregateWorkoutPlan]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWorkoutPlan[P]>
      : GetScalarType<T[P], AggregateWorkoutPlan[P]>
  }




  export type WorkoutPlanGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutPlanWhereInput
    orderBy?: WorkoutPlanOrderByWithAggregationInput | WorkoutPlanOrderByWithAggregationInput[]
    by: WorkoutPlanScalarFieldEnum[] | WorkoutPlanScalarFieldEnum
    having?: WorkoutPlanScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WorkoutPlanCountAggregateInputType | true
    _avg?: WorkoutPlanAvgAggregateInputType
    _sum?: WorkoutPlanSumAggregateInputType
    _min?: WorkoutPlanMinAggregateInputType
    _max?: WorkoutPlanMaxAggregateInputType
  }

  export type WorkoutPlanGroupByOutputType = {
    id: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier: $Enums.PlanTier
    equipmentId: string | null
    createdAt: Date
    updatedAt: Date
    _count: WorkoutPlanCountAggregateOutputType | null
    _avg: WorkoutPlanAvgAggregateOutputType | null
    _sum: WorkoutPlanSumAggregateOutputType | null
    _min: WorkoutPlanMinAggregateOutputType | null
    _max: WorkoutPlanMaxAggregateOutputType | null
  }

  type GetWorkoutPlanGroupByPayload<T extends WorkoutPlanGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WorkoutPlanGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WorkoutPlanGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WorkoutPlanGroupByOutputType[P]>
            : GetScalarType<T[P], WorkoutPlanGroupByOutputType[P]>
        }
      >
    >


  export type WorkoutPlanSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    muscleGroup?: boolean
    durationWeeks?: boolean
    sessionsPerWeek?: boolean
    tier?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    equipment?: boolean | WorkoutPlan$equipmentArgs<ExtArgs>
    plannedSessions?: boolean | WorkoutPlan$plannedSessionsArgs<ExtArgs>
    instances?: boolean | WorkoutPlan$instancesArgs<ExtArgs>
    _count?: boolean | WorkoutPlanCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workoutPlan"]>

  export type WorkoutPlanSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    muscleGroup?: boolean
    durationWeeks?: boolean
    sessionsPerWeek?: boolean
    tier?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    equipment?: boolean | WorkoutPlan$equipmentArgs<ExtArgs>
  }, ExtArgs["result"]["workoutPlan"]>

  export type WorkoutPlanSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    muscleGroup?: boolean
    durationWeeks?: boolean
    sessionsPerWeek?: boolean
    tier?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    equipment?: boolean | WorkoutPlan$equipmentArgs<ExtArgs>
  }, ExtArgs["result"]["workoutPlan"]>

  export type WorkoutPlanSelectScalar = {
    id?: boolean
    name?: boolean
    description?: boolean
    muscleGroup?: boolean
    durationWeeks?: boolean
    sessionsPerWeek?: boolean
    tier?: boolean
    equipmentId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type WorkoutPlanOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "description" | "muscleGroup" | "durationWeeks" | "sessionsPerWeek" | "tier" | "equipmentId" | "createdAt" | "updatedAt", ExtArgs["result"]["workoutPlan"]>
  export type WorkoutPlanInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    equipment?: boolean | WorkoutPlan$equipmentArgs<ExtArgs>
    plannedSessions?: boolean | WorkoutPlan$plannedSessionsArgs<ExtArgs>
    instances?: boolean | WorkoutPlan$instancesArgs<ExtArgs>
    _count?: boolean | WorkoutPlanCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type WorkoutPlanIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    equipment?: boolean | WorkoutPlan$equipmentArgs<ExtArgs>
  }
  export type WorkoutPlanIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    equipment?: boolean | WorkoutPlan$equipmentArgs<ExtArgs>
  }

  export type $WorkoutPlanPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "WorkoutPlan"
    objects: {
      equipment: Prisma.$EquipmentPayload<ExtArgs> | null
      plannedSessions: Prisma.$PlannedSessionPayload<ExtArgs>[]
      instances: Prisma.$PlanInstancePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      description: string
      muscleGroup: $Enums.MuscleGroup
      durationWeeks: number
      sessionsPerWeek: number
      tier: $Enums.PlanTier
      equipmentId: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["workoutPlan"]>
    composites: {}
  }

  type WorkoutPlanGetPayload<S extends boolean | null | undefined | WorkoutPlanDefaultArgs> = $Result.GetResult<Prisma.$WorkoutPlanPayload, S>

  type WorkoutPlanCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WorkoutPlanFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WorkoutPlanCountAggregateInputType | true
    }

  export interface WorkoutPlanDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['WorkoutPlan'], meta: { name: 'WorkoutPlan' } }
    /**
     * Find zero or one WorkoutPlan that matches the filter.
     * @param {WorkoutPlanFindUniqueArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WorkoutPlanFindUniqueArgs>(args: SelectSubset<T, WorkoutPlanFindUniqueArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one WorkoutPlan that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WorkoutPlanFindUniqueOrThrowArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WorkoutPlanFindUniqueOrThrowArgs>(args: SelectSubset<T, WorkoutPlanFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WorkoutPlan that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanFindFirstArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WorkoutPlanFindFirstArgs>(args?: SelectSubset<T, WorkoutPlanFindFirstArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WorkoutPlan that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanFindFirstOrThrowArgs} args - Arguments to find a WorkoutPlan
     * @example
     * // Get one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WorkoutPlanFindFirstOrThrowArgs>(args?: SelectSubset<T, WorkoutPlanFindFirstOrThrowArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more WorkoutPlans that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WorkoutPlans
     * const workoutPlans = await prisma.workoutPlan.findMany()
     * 
     * // Get first 10 WorkoutPlans
     * const workoutPlans = await prisma.workoutPlan.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const workoutPlanWithIdOnly = await prisma.workoutPlan.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WorkoutPlanFindManyArgs>(args?: SelectSubset<T, WorkoutPlanFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a WorkoutPlan.
     * @param {WorkoutPlanCreateArgs} args - Arguments to create a WorkoutPlan.
     * @example
     * // Create one WorkoutPlan
     * const WorkoutPlan = await prisma.workoutPlan.create({
     *   data: {
     *     // ... data to create a WorkoutPlan
     *   }
     * })
     * 
     */
    create<T extends WorkoutPlanCreateArgs>(args: SelectSubset<T, WorkoutPlanCreateArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many WorkoutPlans.
     * @param {WorkoutPlanCreateManyArgs} args - Arguments to create many WorkoutPlans.
     * @example
     * // Create many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WorkoutPlanCreateManyArgs>(args?: SelectSubset<T, WorkoutPlanCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many WorkoutPlans and returns the data saved in the database.
     * @param {WorkoutPlanCreateManyAndReturnArgs} args - Arguments to create many WorkoutPlans.
     * @example
     * // Create many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many WorkoutPlans and only return the `id`
     * const workoutPlanWithIdOnly = await prisma.workoutPlan.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends WorkoutPlanCreateManyAndReturnArgs>(args?: SelectSubset<T, WorkoutPlanCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a WorkoutPlan.
     * @param {WorkoutPlanDeleteArgs} args - Arguments to delete one WorkoutPlan.
     * @example
     * // Delete one WorkoutPlan
     * const WorkoutPlan = await prisma.workoutPlan.delete({
     *   where: {
     *     // ... filter to delete one WorkoutPlan
     *   }
     * })
     * 
     */
    delete<T extends WorkoutPlanDeleteArgs>(args: SelectSubset<T, WorkoutPlanDeleteArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one WorkoutPlan.
     * @param {WorkoutPlanUpdateArgs} args - Arguments to update one WorkoutPlan.
     * @example
     * // Update one WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WorkoutPlanUpdateArgs>(args: SelectSubset<T, WorkoutPlanUpdateArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more WorkoutPlans.
     * @param {WorkoutPlanDeleteManyArgs} args - Arguments to filter WorkoutPlans to delete.
     * @example
     * // Delete a few WorkoutPlans
     * const { count } = await prisma.workoutPlan.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WorkoutPlanDeleteManyArgs>(args?: SelectSubset<T, WorkoutPlanDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WorkoutPlans.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WorkoutPlanUpdateManyArgs>(args: SelectSubset<T, WorkoutPlanUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WorkoutPlans and returns the data updated in the database.
     * @param {WorkoutPlanUpdateManyAndReturnArgs} args - Arguments to update many WorkoutPlans.
     * @example
     * // Update many WorkoutPlans
     * const workoutPlan = await prisma.workoutPlan.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more WorkoutPlans and only return the `id`
     * const workoutPlanWithIdOnly = await prisma.workoutPlan.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends WorkoutPlanUpdateManyAndReturnArgs>(args: SelectSubset<T, WorkoutPlanUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one WorkoutPlan.
     * @param {WorkoutPlanUpsertArgs} args - Arguments to update or create a WorkoutPlan.
     * @example
     * // Update or create a WorkoutPlan
     * const workoutPlan = await prisma.workoutPlan.upsert({
     *   create: {
     *     // ... data to create a WorkoutPlan
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WorkoutPlan we want to update
     *   }
     * })
     */
    upsert<T extends WorkoutPlanUpsertArgs>(args: SelectSubset<T, WorkoutPlanUpsertArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of WorkoutPlans.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanCountArgs} args - Arguments to filter WorkoutPlans to count.
     * @example
     * // Count the number of WorkoutPlans
     * const count = await prisma.workoutPlan.count({
     *   where: {
     *     // ... the filter for the WorkoutPlans we want to count
     *   }
     * })
    **/
    count<T extends WorkoutPlanCountArgs>(
      args?: Subset<T, WorkoutPlanCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WorkoutPlanCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a WorkoutPlan.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WorkoutPlanAggregateArgs>(args: Subset<T, WorkoutPlanAggregateArgs>): Prisma.PrismaPromise<GetWorkoutPlanAggregateType<T>>

    /**
     * Group by WorkoutPlan.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutPlanGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WorkoutPlanGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WorkoutPlanGroupByArgs['orderBy'] }
        : { orderBy?: WorkoutPlanGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WorkoutPlanGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWorkoutPlanGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the WorkoutPlan model
   */
  readonly fields: WorkoutPlanFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for WorkoutPlan.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WorkoutPlanClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    equipment<T extends WorkoutPlan$equipmentArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutPlan$equipmentArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    plannedSessions<T extends WorkoutPlan$plannedSessionsArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutPlan$plannedSessionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    instances<T extends WorkoutPlan$instancesArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutPlan$instancesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the WorkoutPlan model
   */
  interface WorkoutPlanFieldRefs {
    readonly id: FieldRef<"WorkoutPlan", 'String'>
    readonly name: FieldRef<"WorkoutPlan", 'String'>
    readonly description: FieldRef<"WorkoutPlan", 'String'>
    readonly muscleGroup: FieldRef<"WorkoutPlan", 'MuscleGroup'>
    readonly durationWeeks: FieldRef<"WorkoutPlan", 'Int'>
    readonly sessionsPerWeek: FieldRef<"WorkoutPlan", 'Int'>
    readonly tier: FieldRef<"WorkoutPlan", 'PlanTier'>
    readonly equipmentId: FieldRef<"WorkoutPlan", 'String'>
    readonly createdAt: FieldRef<"WorkoutPlan", 'DateTime'>
    readonly updatedAt: FieldRef<"WorkoutPlan", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * WorkoutPlan findUnique
   */
  export type WorkoutPlanFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan findUniqueOrThrow
   */
  export type WorkoutPlanFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan findFirst
   */
  export type WorkoutPlanFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WorkoutPlans.
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutPlans.
     */
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * WorkoutPlan findFirstOrThrow
   */
  export type WorkoutPlanFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlan to fetch.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WorkoutPlans.
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutPlans.
     */
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * WorkoutPlan findMany
   */
  export type WorkoutPlanFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutPlans to fetch.
     */
    where?: WorkoutPlanWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutPlans to fetch.
     */
    orderBy?: WorkoutPlanOrderByWithRelationInput | WorkoutPlanOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing WorkoutPlans.
     */
    cursor?: WorkoutPlanWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutPlans from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutPlans.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutPlans.
     */
    distinct?: WorkoutPlanScalarFieldEnum | WorkoutPlanScalarFieldEnum[]
  }

  /**
   * WorkoutPlan create
   */
  export type WorkoutPlanCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * The data needed to create a WorkoutPlan.
     */
    data: XOR<WorkoutPlanCreateInput, WorkoutPlanUncheckedCreateInput>
  }

  /**
   * WorkoutPlan createMany
   */
  export type WorkoutPlanCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many WorkoutPlans.
     */
    data: WorkoutPlanCreateManyInput | WorkoutPlanCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * WorkoutPlan createManyAndReturn
   */
  export type WorkoutPlanCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * The data used to create many WorkoutPlans.
     */
    data: WorkoutPlanCreateManyInput | WorkoutPlanCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * WorkoutPlan update
   */
  export type WorkoutPlanUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * The data needed to update a WorkoutPlan.
     */
    data: XOR<WorkoutPlanUpdateInput, WorkoutPlanUncheckedUpdateInput>
    /**
     * Choose, which WorkoutPlan to update.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan updateMany
   */
  export type WorkoutPlanUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update WorkoutPlans.
     */
    data: XOR<WorkoutPlanUpdateManyMutationInput, WorkoutPlanUncheckedUpdateManyInput>
    /**
     * Filter which WorkoutPlans to update
     */
    where?: WorkoutPlanWhereInput
    /**
     * Limit how many WorkoutPlans to update.
     */
    limit?: number
  }

  /**
   * WorkoutPlan updateManyAndReturn
   */
  export type WorkoutPlanUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * The data used to update WorkoutPlans.
     */
    data: XOR<WorkoutPlanUpdateManyMutationInput, WorkoutPlanUncheckedUpdateManyInput>
    /**
     * Filter which WorkoutPlans to update
     */
    where?: WorkoutPlanWhereInput
    /**
     * Limit how many WorkoutPlans to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * WorkoutPlan upsert
   */
  export type WorkoutPlanUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * The filter to search for the WorkoutPlan to update in case it exists.
     */
    where: WorkoutPlanWhereUniqueInput
    /**
     * In case the WorkoutPlan found by the `where` argument doesn't exist, create a new WorkoutPlan with this data.
     */
    create: XOR<WorkoutPlanCreateInput, WorkoutPlanUncheckedCreateInput>
    /**
     * In case the WorkoutPlan was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WorkoutPlanUpdateInput, WorkoutPlanUncheckedUpdateInput>
  }

  /**
   * WorkoutPlan delete
   */
  export type WorkoutPlanDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
    /**
     * Filter which WorkoutPlan to delete.
     */
    where: WorkoutPlanWhereUniqueInput
  }

  /**
   * WorkoutPlan deleteMany
   */
  export type WorkoutPlanDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WorkoutPlans to delete
     */
    where?: WorkoutPlanWhereInput
    /**
     * Limit how many WorkoutPlans to delete.
     */
    limit?: number
  }

  /**
   * WorkoutPlan.equipment
   */
  export type WorkoutPlan$equipmentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Equipment
     */
    select?: EquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Equipment
     */
    omit?: EquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EquipmentInclude<ExtArgs> | null
    where?: EquipmentWhereInput
  }

  /**
   * WorkoutPlan.plannedSessions
   */
  export type WorkoutPlan$plannedSessionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    where?: PlannedSessionWhereInput
    orderBy?: PlannedSessionOrderByWithRelationInput | PlannedSessionOrderByWithRelationInput[]
    cursor?: PlannedSessionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PlannedSessionScalarFieldEnum | PlannedSessionScalarFieldEnum[]
  }

  /**
   * WorkoutPlan.instances
   */
  export type WorkoutPlan$instancesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    where?: PlanInstanceWhereInput
    orderBy?: PlanInstanceOrderByWithRelationInput | PlanInstanceOrderByWithRelationInput[]
    cursor?: PlanInstanceWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PlanInstanceScalarFieldEnum | PlanInstanceScalarFieldEnum[]
  }

  /**
   * WorkoutPlan without action
   */
  export type WorkoutPlanDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutPlan
     */
    select?: WorkoutPlanSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutPlan
     */
    omit?: WorkoutPlanOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutPlanInclude<ExtArgs> | null
  }


  /**
   * Model PlannedSession
   */

  export type AggregatePlannedSession = {
    _count: PlannedSessionCountAggregateOutputType | null
    _avg: PlannedSessionAvgAggregateOutputType | null
    _sum: PlannedSessionSumAggregateOutputType | null
    _min: PlannedSessionMinAggregateOutputType | null
    _max: PlannedSessionMaxAggregateOutputType | null
  }

  export type PlannedSessionAvgAggregateOutputType = {
    sessionNumber: number | null
  }

  export type PlannedSessionSumAggregateOutputType = {
    sessionNumber: number | null
  }

  export type PlannedSessionMinAggregateOutputType = {
    id: string | null
    sessionNumber: number | null
    focus: string | null
    planId: string | null
  }

  export type PlannedSessionMaxAggregateOutputType = {
    id: string | null
    sessionNumber: number | null
    focus: string | null
    planId: string | null
  }

  export type PlannedSessionCountAggregateOutputType = {
    id: number
    sessionNumber: number
    focus: number
    planId: number
    _all: number
  }


  export type PlannedSessionAvgAggregateInputType = {
    sessionNumber?: true
  }

  export type PlannedSessionSumAggregateInputType = {
    sessionNumber?: true
  }

  export type PlannedSessionMinAggregateInputType = {
    id?: true
    sessionNumber?: true
    focus?: true
    planId?: true
  }

  export type PlannedSessionMaxAggregateInputType = {
    id?: true
    sessionNumber?: true
    focus?: true
    planId?: true
  }

  export type PlannedSessionCountAggregateInputType = {
    id?: true
    sessionNumber?: true
    focus?: true
    planId?: true
    _all?: true
  }

  export type PlannedSessionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlannedSession to aggregate.
     */
    where?: PlannedSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedSessions to fetch.
     */
    orderBy?: PlannedSessionOrderByWithRelationInput | PlannedSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PlannedSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PlannedSessions
    **/
    _count?: true | PlannedSessionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PlannedSessionAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PlannedSessionSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PlannedSessionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PlannedSessionMaxAggregateInputType
  }

  export type GetPlannedSessionAggregateType<T extends PlannedSessionAggregateArgs> = {
        [P in keyof T & keyof AggregatePlannedSession]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePlannedSession[P]>
      : GetScalarType<T[P], AggregatePlannedSession[P]>
  }




  export type PlannedSessionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlannedSessionWhereInput
    orderBy?: PlannedSessionOrderByWithAggregationInput | PlannedSessionOrderByWithAggregationInput[]
    by: PlannedSessionScalarFieldEnum[] | PlannedSessionScalarFieldEnum
    having?: PlannedSessionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PlannedSessionCountAggregateInputType | true
    _avg?: PlannedSessionAvgAggregateInputType
    _sum?: PlannedSessionSumAggregateInputType
    _min?: PlannedSessionMinAggregateInputType
    _max?: PlannedSessionMaxAggregateInputType
  }

  export type PlannedSessionGroupByOutputType = {
    id: string
    sessionNumber: number
    focus: string
    planId: string
    _count: PlannedSessionCountAggregateOutputType | null
    _avg: PlannedSessionAvgAggregateOutputType | null
    _sum: PlannedSessionSumAggregateOutputType | null
    _min: PlannedSessionMinAggregateOutputType | null
    _max: PlannedSessionMaxAggregateOutputType | null
  }

  type GetPlannedSessionGroupByPayload<T extends PlannedSessionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PlannedSessionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PlannedSessionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PlannedSessionGroupByOutputType[P]>
            : GetScalarType<T[P], PlannedSessionGroupByOutputType[P]>
        }
      >
    >


  export type PlannedSessionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionNumber?: boolean
    focus?: boolean
    planId?: boolean
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    plannedExercises?: boolean | PlannedSession$plannedExercisesArgs<ExtArgs>
    _count?: boolean | PlannedSessionCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["plannedSession"]>

  export type PlannedSessionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionNumber?: boolean
    focus?: boolean
    planId?: boolean
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["plannedSession"]>

  export type PlannedSessionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionNumber?: boolean
    focus?: boolean
    planId?: boolean
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["plannedSession"]>

  export type PlannedSessionSelectScalar = {
    id?: boolean
    sessionNumber?: boolean
    focus?: boolean
    planId?: boolean
  }

  export type PlannedSessionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "sessionNumber" | "focus" | "planId", ExtArgs["result"]["plannedSession"]>
  export type PlannedSessionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    plannedExercises?: boolean | PlannedSession$plannedExercisesArgs<ExtArgs>
    _count?: boolean | PlannedSessionCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type PlannedSessionIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }
  export type PlannedSessionIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }

  export type $PlannedSessionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PlannedSession"
    objects: {
      plan: Prisma.$WorkoutPlanPayload<ExtArgs>
      plannedExercises: Prisma.$PlannedExercisePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      sessionNumber: number
      focus: string
      planId: string
    }, ExtArgs["result"]["plannedSession"]>
    composites: {}
  }

  type PlannedSessionGetPayload<S extends boolean | null | undefined | PlannedSessionDefaultArgs> = $Result.GetResult<Prisma.$PlannedSessionPayload, S>

  type PlannedSessionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PlannedSessionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PlannedSessionCountAggregateInputType | true
    }

  export interface PlannedSessionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PlannedSession'], meta: { name: 'PlannedSession' } }
    /**
     * Find zero or one PlannedSession that matches the filter.
     * @param {PlannedSessionFindUniqueArgs} args - Arguments to find a PlannedSession
     * @example
     * // Get one PlannedSession
     * const plannedSession = await prisma.plannedSession.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PlannedSessionFindUniqueArgs>(args: SelectSubset<T, PlannedSessionFindUniqueArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PlannedSession that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PlannedSessionFindUniqueOrThrowArgs} args - Arguments to find a PlannedSession
     * @example
     * // Get one PlannedSession
     * const plannedSession = await prisma.plannedSession.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PlannedSessionFindUniqueOrThrowArgs>(args: SelectSubset<T, PlannedSessionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlannedSession that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedSessionFindFirstArgs} args - Arguments to find a PlannedSession
     * @example
     * // Get one PlannedSession
     * const plannedSession = await prisma.plannedSession.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PlannedSessionFindFirstArgs>(args?: SelectSubset<T, PlannedSessionFindFirstArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlannedSession that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedSessionFindFirstOrThrowArgs} args - Arguments to find a PlannedSession
     * @example
     * // Get one PlannedSession
     * const plannedSession = await prisma.plannedSession.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PlannedSessionFindFirstOrThrowArgs>(args?: SelectSubset<T, PlannedSessionFindFirstOrThrowArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PlannedSessions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedSessionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PlannedSessions
     * const plannedSessions = await prisma.plannedSession.findMany()
     * 
     * // Get first 10 PlannedSessions
     * const plannedSessions = await prisma.plannedSession.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const plannedSessionWithIdOnly = await prisma.plannedSession.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PlannedSessionFindManyArgs>(args?: SelectSubset<T, PlannedSessionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PlannedSession.
     * @param {PlannedSessionCreateArgs} args - Arguments to create a PlannedSession.
     * @example
     * // Create one PlannedSession
     * const PlannedSession = await prisma.plannedSession.create({
     *   data: {
     *     // ... data to create a PlannedSession
     *   }
     * })
     * 
     */
    create<T extends PlannedSessionCreateArgs>(args: SelectSubset<T, PlannedSessionCreateArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PlannedSessions.
     * @param {PlannedSessionCreateManyArgs} args - Arguments to create many PlannedSessions.
     * @example
     * // Create many PlannedSessions
     * const plannedSession = await prisma.plannedSession.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PlannedSessionCreateManyArgs>(args?: SelectSubset<T, PlannedSessionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PlannedSessions and returns the data saved in the database.
     * @param {PlannedSessionCreateManyAndReturnArgs} args - Arguments to create many PlannedSessions.
     * @example
     * // Create many PlannedSessions
     * const plannedSession = await prisma.plannedSession.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PlannedSessions and only return the `id`
     * const plannedSessionWithIdOnly = await prisma.plannedSession.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PlannedSessionCreateManyAndReturnArgs>(args?: SelectSubset<T, PlannedSessionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PlannedSession.
     * @param {PlannedSessionDeleteArgs} args - Arguments to delete one PlannedSession.
     * @example
     * // Delete one PlannedSession
     * const PlannedSession = await prisma.plannedSession.delete({
     *   where: {
     *     // ... filter to delete one PlannedSession
     *   }
     * })
     * 
     */
    delete<T extends PlannedSessionDeleteArgs>(args: SelectSubset<T, PlannedSessionDeleteArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PlannedSession.
     * @param {PlannedSessionUpdateArgs} args - Arguments to update one PlannedSession.
     * @example
     * // Update one PlannedSession
     * const plannedSession = await prisma.plannedSession.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PlannedSessionUpdateArgs>(args: SelectSubset<T, PlannedSessionUpdateArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PlannedSessions.
     * @param {PlannedSessionDeleteManyArgs} args - Arguments to filter PlannedSessions to delete.
     * @example
     * // Delete a few PlannedSessions
     * const { count } = await prisma.plannedSession.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PlannedSessionDeleteManyArgs>(args?: SelectSubset<T, PlannedSessionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlannedSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedSessionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PlannedSessions
     * const plannedSession = await prisma.plannedSession.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PlannedSessionUpdateManyArgs>(args: SelectSubset<T, PlannedSessionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlannedSessions and returns the data updated in the database.
     * @param {PlannedSessionUpdateManyAndReturnArgs} args - Arguments to update many PlannedSessions.
     * @example
     * // Update many PlannedSessions
     * const plannedSession = await prisma.plannedSession.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PlannedSessions and only return the `id`
     * const plannedSessionWithIdOnly = await prisma.plannedSession.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PlannedSessionUpdateManyAndReturnArgs>(args: SelectSubset<T, PlannedSessionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PlannedSession.
     * @param {PlannedSessionUpsertArgs} args - Arguments to update or create a PlannedSession.
     * @example
     * // Update or create a PlannedSession
     * const plannedSession = await prisma.plannedSession.upsert({
     *   create: {
     *     // ... data to create a PlannedSession
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PlannedSession we want to update
     *   }
     * })
     */
    upsert<T extends PlannedSessionUpsertArgs>(args: SelectSubset<T, PlannedSessionUpsertArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PlannedSessions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedSessionCountArgs} args - Arguments to filter PlannedSessions to count.
     * @example
     * // Count the number of PlannedSessions
     * const count = await prisma.plannedSession.count({
     *   where: {
     *     // ... the filter for the PlannedSessions we want to count
     *   }
     * })
    **/
    count<T extends PlannedSessionCountArgs>(
      args?: Subset<T, PlannedSessionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PlannedSessionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PlannedSession.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedSessionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PlannedSessionAggregateArgs>(args: Subset<T, PlannedSessionAggregateArgs>): Prisma.PrismaPromise<GetPlannedSessionAggregateType<T>>

    /**
     * Group by PlannedSession.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedSessionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PlannedSessionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PlannedSessionGroupByArgs['orderBy'] }
        : { orderBy?: PlannedSessionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PlannedSessionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPlannedSessionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PlannedSession model
   */
  readonly fields: PlannedSessionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PlannedSession.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PlannedSessionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    plan<T extends WorkoutPlanDefaultArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutPlanDefaultArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    plannedExercises<T extends PlannedSession$plannedExercisesArgs<ExtArgs> = {}>(args?: Subset<T, PlannedSession$plannedExercisesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PlannedSession model
   */
  interface PlannedSessionFieldRefs {
    readonly id: FieldRef<"PlannedSession", 'String'>
    readonly sessionNumber: FieldRef<"PlannedSession", 'Int'>
    readonly focus: FieldRef<"PlannedSession", 'String'>
    readonly planId: FieldRef<"PlannedSession", 'String'>
  }
    

  // Custom InputTypes
  /**
   * PlannedSession findUnique
   */
  export type PlannedSessionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * Filter, which PlannedSession to fetch.
     */
    where: PlannedSessionWhereUniqueInput
  }

  /**
   * PlannedSession findUniqueOrThrow
   */
  export type PlannedSessionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * Filter, which PlannedSession to fetch.
     */
    where: PlannedSessionWhereUniqueInput
  }

  /**
   * PlannedSession findFirst
   */
  export type PlannedSessionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * Filter, which PlannedSession to fetch.
     */
    where?: PlannedSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedSessions to fetch.
     */
    orderBy?: PlannedSessionOrderByWithRelationInput | PlannedSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlannedSessions.
     */
    cursor?: PlannedSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlannedSessions.
     */
    distinct?: PlannedSessionScalarFieldEnum | PlannedSessionScalarFieldEnum[]
  }

  /**
   * PlannedSession findFirstOrThrow
   */
  export type PlannedSessionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * Filter, which PlannedSession to fetch.
     */
    where?: PlannedSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedSessions to fetch.
     */
    orderBy?: PlannedSessionOrderByWithRelationInput | PlannedSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlannedSessions.
     */
    cursor?: PlannedSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlannedSessions.
     */
    distinct?: PlannedSessionScalarFieldEnum | PlannedSessionScalarFieldEnum[]
  }

  /**
   * PlannedSession findMany
   */
  export type PlannedSessionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * Filter, which PlannedSessions to fetch.
     */
    where?: PlannedSessionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedSessions to fetch.
     */
    orderBy?: PlannedSessionOrderByWithRelationInput | PlannedSessionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PlannedSessions.
     */
    cursor?: PlannedSessionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedSessions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedSessions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlannedSessions.
     */
    distinct?: PlannedSessionScalarFieldEnum | PlannedSessionScalarFieldEnum[]
  }

  /**
   * PlannedSession create
   */
  export type PlannedSessionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * The data needed to create a PlannedSession.
     */
    data: XOR<PlannedSessionCreateInput, PlannedSessionUncheckedCreateInput>
  }

  /**
   * PlannedSession createMany
   */
  export type PlannedSessionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PlannedSessions.
     */
    data: PlannedSessionCreateManyInput | PlannedSessionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PlannedSession createManyAndReturn
   */
  export type PlannedSessionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * The data used to create many PlannedSessions.
     */
    data: PlannedSessionCreateManyInput | PlannedSessionCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlannedSession update
   */
  export type PlannedSessionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * The data needed to update a PlannedSession.
     */
    data: XOR<PlannedSessionUpdateInput, PlannedSessionUncheckedUpdateInput>
    /**
     * Choose, which PlannedSession to update.
     */
    where: PlannedSessionWhereUniqueInput
  }

  /**
   * PlannedSession updateMany
   */
  export type PlannedSessionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PlannedSessions.
     */
    data: XOR<PlannedSessionUpdateManyMutationInput, PlannedSessionUncheckedUpdateManyInput>
    /**
     * Filter which PlannedSessions to update
     */
    where?: PlannedSessionWhereInput
    /**
     * Limit how many PlannedSessions to update.
     */
    limit?: number
  }

  /**
   * PlannedSession updateManyAndReturn
   */
  export type PlannedSessionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * The data used to update PlannedSessions.
     */
    data: XOR<PlannedSessionUpdateManyMutationInput, PlannedSessionUncheckedUpdateManyInput>
    /**
     * Filter which PlannedSessions to update
     */
    where?: PlannedSessionWhereInput
    /**
     * Limit how many PlannedSessions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlannedSession upsert
   */
  export type PlannedSessionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * The filter to search for the PlannedSession to update in case it exists.
     */
    where: PlannedSessionWhereUniqueInput
    /**
     * In case the PlannedSession found by the `where` argument doesn't exist, create a new PlannedSession with this data.
     */
    create: XOR<PlannedSessionCreateInput, PlannedSessionUncheckedCreateInput>
    /**
     * In case the PlannedSession was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PlannedSessionUpdateInput, PlannedSessionUncheckedUpdateInput>
  }

  /**
   * PlannedSession delete
   */
  export type PlannedSessionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
    /**
     * Filter which PlannedSession to delete.
     */
    where: PlannedSessionWhereUniqueInput
  }

  /**
   * PlannedSession deleteMany
   */
  export type PlannedSessionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlannedSessions to delete
     */
    where?: PlannedSessionWhereInput
    /**
     * Limit how many PlannedSessions to delete.
     */
    limit?: number
  }

  /**
   * PlannedSession.plannedExercises
   */
  export type PlannedSession$plannedExercisesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    where?: PlannedExerciseWhereInput
    orderBy?: PlannedExerciseOrderByWithRelationInput | PlannedExerciseOrderByWithRelationInput[]
    cursor?: PlannedExerciseWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PlannedExerciseScalarFieldEnum | PlannedExerciseScalarFieldEnum[]
  }

  /**
   * PlannedSession without action
   */
  export type PlannedSessionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedSession
     */
    select?: PlannedSessionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedSession
     */
    omit?: PlannedSessionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedSessionInclude<ExtArgs> | null
  }


  /**
   * Model PlannedExercise
   */

  export type AggregatePlannedExercise = {
    _count: PlannedExerciseCountAggregateOutputType | null
    _avg: PlannedExerciseAvgAggregateOutputType | null
    _sum: PlannedExerciseSumAggregateOutputType | null
    _min: PlannedExerciseMinAggregateOutputType | null
    _max: PlannedExerciseMaxAggregateOutputType | null
  }

  export type PlannedExerciseAvgAggregateOutputType = {
    order: number | null
    beginnerSets: number | null
    beginnerReps: number | null
    intermediateSets: number | null
    intermediateReps: number | null
    advancedSets: number | null
    advancedReps: number | null
    restSeconds: number | null
  }

  export type PlannedExerciseSumAggregateOutputType = {
    order: number | null
    beginnerSets: number | null
    beginnerReps: number | null
    intermediateSets: number | null
    intermediateReps: number | null
    advancedSets: number | null
    advancedReps: number | null
    restSeconds: number | null
  }

  export type PlannedExerciseMinAggregateOutputType = {
    id: string | null
    order: number | null
    sessionId: string | null
    exerciseId: string | null
    beginnerSets: number | null
    beginnerReps: number | null
    intermediateSets: number | null
    intermediateReps: number | null
    advancedSets: number | null
    advancedReps: number | null
    restSeconds: number | null
  }

  export type PlannedExerciseMaxAggregateOutputType = {
    id: string | null
    order: number | null
    sessionId: string | null
    exerciseId: string | null
    beginnerSets: number | null
    beginnerReps: number | null
    intermediateSets: number | null
    intermediateReps: number | null
    advancedSets: number | null
    advancedReps: number | null
    restSeconds: number | null
  }

  export type PlannedExerciseCountAggregateOutputType = {
    id: number
    order: number
    sessionId: number
    exerciseId: number
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    _all: number
  }


  export type PlannedExerciseAvgAggregateInputType = {
    order?: true
    beginnerSets?: true
    beginnerReps?: true
    intermediateSets?: true
    intermediateReps?: true
    advancedSets?: true
    advancedReps?: true
    restSeconds?: true
  }

  export type PlannedExerciseSumAggregateInputType = {
    order?: true
    beginnerSets?: true
    beginnerReps?: true
    intermediateSets?: true
    intermediateReps?: true
    advancedSets?: true
    advancedReps?: true
    restSeconds?: true
  }

  export type PlannedExerciseMinAggregateInputType = {
    id?: true
    order?: true
    sessionId?: true
    exerciseId?: true
    beginnerSets?: true
    beginnerReps?: true
    intermediateSets?: true
    intermediateReps?: true
    advancedSets?: true
    advancedReps?: true
    restSeconds?: true
  }

  export type PlannedExerciseMaxAggregateInputType = {
    id?: true
    order?: true
    sessionId?: true
    exerciseId?: true
    beginnerSets?: true
    beginnerReps?: true
    intermediateSets?: true
    intermediateReps?: true
    advancedSets?: true
    advancedReps?: true
    restSeconds?: true
  }

  export type PlannedExerciseCountAggregateInputType = {
    id?: true
    order?: true
    sessionId?: true
    exerciseId?: true
    beginnerSets?: true
    beginnerReps?: true
    intermediateSets?: true
    intermediateReps?: true
    advancedSets?: true
    advancedReps?: true
    restSeconds?: true
    _all?: true
  }

  export type PlannedExerciseAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlannedExercise to aggregate.
     */
    where?: PlannedExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedExercises to fetch.
     */
    orderBy?: PlannedExerciseOrderByWithRelationInput | PlannedExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PlannedExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedExercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedExercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PlannedExercises
    **/
    _count?: true | PlannedExerciseCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PlannedExerciseAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PlannedExerciseSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PlannedExerciseMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PlannedExerciseMaxAggregateInputType
  }

  export type GetPlannedExerciseAggregateType<T extends PlannedExerciseAggregateArgs> = {
        [P in keyof T & keyof AggregatePlannedExercise]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePlannedExercise[P]>
      : GetScalarType<T[P], AggregatePlannedExercise[P]>
  }




  export type PlannedExerciseGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlannedExerciseWhereInput
    orderBy?: PlannedExerciseOrderByWithAggregationInput | PlannedExerciseOrderByWithAggregationInput[]
    by: PlannedExerciseScalarFieldEnum[] | PlannedExerciseScalarFieldEnum
    having?: PlannedExerciseScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PlannedExerciseCountAggregateInputType | true
    _avg?: PlannedExerciseAvgAggregateInputType
    _sum?: PlannedExerciseSumAggregateInputType
    _min?: PlannedExerciseMinAggregateInputType
    _max?: PlannedExerciseMaxAggregateInputType
  }

  export type PlannedExerciseGroupByOutputType = {
    id: string
    order: number
    sessionId: string
    exerciseId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    _count: PlannedExerciseCountAggregateOutputType | null
    _avg: PlannedExerciseAvgAggregateOutputType | null
    _sum: PlannedExerciseSumAggregateOutputType | null
    _min: PlannedExerciseMinAggregateOutputType | null
    _max: PlannedExerciseMaxAggregateOutputType | null
  }

  type GetPlannedExerciseGroupByPayload<T extends PlannedExerciseGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PlannedExerciseGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PlannedExerciseGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PlannedExerciseGroupByOutputType[P]>
            : GetScalarType<T[P], PlannedExerciseGroupByOutputType[P]>
        }
      >
    >


  export type PlannedExerciseSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    order?: boolean
    sessionId?: boolean
    exerciseId?: boolean
    beginnerSets?: boolean
    beginnerReps?: boolean
    intermediateSets?: boolean
    intermediateReps?: boolean
    advancedSets?: boolean
    advancedReps?: boolean
    restSeconds?: boolean
    session?: boolean | PlannedSessionDefaultArgs<ExtArgs>
    exercise?: boolean | ExerciseDefaultArgs<ExtArgs>
    loggedSets?: boolean | PlannedExercise$loggedSetsArgs<ExtArgs>
    _count?: boolean | PlannedExerciseCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["plannedExercise"]>

  export type PlannedExerciseSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    order?: boolean
    sessionId?: boolean
    exerciseId?: boolean
    beginnerSets?: boolean
    beginnerReps?: boolean
    intermediateSets?: boolean
    intermediateReps?: boolean
    advancedSets?: boolean
    advancedReps?: boolean
    restSeconds?: boolean
    session?: boolean | PlannedSessionDefaultArgs<ExtArgs>
    exercise?: boolean | ExerciseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["plannedExercise"]>

  export type PlannedExerciseSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    order?: boolean
    sessionId?: boolean
    exerciseId?: boolean
    beginnerSets?: boolean
    beginnerReps?: boolean
    intermediateSets?: boolean
    intermediateReps?: boolean
    advancedSets?: boolean
    advancedReps?: boolean
    restSeconds?: boolean
    session?: boolean | PlannedSessionDefaultArgs<ExtArgs>
    exercise?: boolean | ExerciseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["plannedExercise"]>

  export type PlannedExerciseSelectScalar = {
    id?: boolean
    order?: boolean
    sessionId?: boolean
    exerciseId?: boolean
    beginnerSets?: boolean
    beginnerReps?: boolean
    intermediateSets?: boolean
    intermediateReps?: boolean
    advancedSets?: boolean
    advancedReps?: boolean
    restSeconds?: boolean
  }

  export type PlannedExerciseOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "order" | "sessionId" | "exerciseId" | "beginnerSets" | "beginnerReps" | "intermediateSets" | "intermediateReps" | "advancedSets" | "advancedReps" | "restSeconds", ExtArgs["result"]["plannedExercise"]>
  export type PlannedExerciseInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    session?: boolean | PlannedSessionDefaultArgs<ExtArgs>
    exercise?: boolean | ExerciseDefaultArgs<ExtArgs>
    loggedSets?: boolean | PlannedExercise$loggedSetsArgs<ExtArgs>
    _count?: boolean | PlannedExerciseCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type PlannedExerciseIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    session?: boolean | PlannedSessionDefaultArgs<ExtArgs>
    exercise?: boolean | ExerciseDefaultArgs<ExtArgs>
  }
  export type PlannedExerciseIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    session?: boolean | PlannedSessionDefaultArgs<ExtArgs>
    exercise?: boolean | ExerciseDefaultArgs<ExtArgs>
  }

  export type $PlannedExercisePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PlannedExercise"
    objects: {
      session: Prisma.$PlannedSessionPayload<ExtArgs>
      exercise: Prisma.$ExercisePayload<ExtArgs>
      loggedSets: Prisma.$WorkoutLogPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      order: number
      sessionId: string
      exerciseId: string
      beginnerSets: number
      beginnerReps: number
      intermediateSets: number
      intermediateReps: number
      advancedSets: number
      advancedReps: number
      restSeconds: number
    }, ExtArgs["result"]["plannedExercise"]>
    composites: {}
  }

  type PlannedExerciseGetPayload<S extends boolean | null | undefined | PlannedExerciseDefaultArgs> = $Result.GetResult<Prisma.$PlannedExercisePayload, S>

  type PlannedExerciseCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PlannedExerciseFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PlannedExerciseCountAggregateInputType | true
    }

  export interface PlannedExerciseDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PlannedExercise'], meta: { name: 'PlannedExercise' } }
    /**
     * Find zero or one PlannedExercise that matches the filter.
     * @param {PlannedExerciseFindUniqueArgs} args - Arguments to find a PlannedExercise
     * @example
     * // Get one PlannedExercise
     * const plannedExercise = await prisma.plannedExercise.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PlannedExerciseFindUniqueArgs>(args: SelectSubset<T, PlannedExerciseFindUniqueArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PlannedExercise that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PlannedExerciseFindUniqueOrThrowArgs} args - Arguments to find a PlannedExercise
     * @example
     * // Get one PlannedExercise
     * const plannedExercise = await prisma.plannedExercise.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PlannedExerciseFindUniqueOrThrowArgs>(args: SelectSubset<T, PlannedExerciseFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlannedExercise that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedExerciseFindFirstArgs} args - Arguments to find a PlannedExercise
     * @example
     * // Get one PlannedExercise
     * const plannedExercise = await prisma.plannedExercise.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PlannedExerciseFindFirstArgs>(args?: SelectSubset<T, PlannedExerciseFindFirstArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlannedExercise that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedExerciseFindFirstOrThrowArgs} args - Arguments to find a PlannedExercise
     * @example
     * // Get one PlannedExercise
     * const plannedExercise = await prisma.plannedExercise.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PlannedExerciseFindFirstOrThrowArgs>(args?: SelectSubset<T, PlannedExerciseFindFirstOrThrowArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PlannedExercises that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedExerciseFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PlannedExercises
     * const plannedExercises = await prisma.plannedExercise.findMany()
     * 
     * // Get first 10 PlannedExercises
     * const plannedExercises = await prisma.plannedExercise.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const plannedExerciseWithIdOnly = await prisma.plannedExercise.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PlannedExerciseFindManyArgs>(args?: SelectSubset<T, PlannedExerciseFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PlannedExercise.
     * @param {PlannedExerciseCreateArgs} args - Arguments to create a PlannedExercise.
     * @example
     * // Create one PlannedExercise
     * const PlannedExercise = await prisma.plannedExercise.create({
     *   data: {
     *     // ... data to create a PlannedExercise
     *   }
     * })
     * 
     */
    create<T extends PlannedExerciseCreateArgs>(args: SelectSubset<T, PlannedExerciseCreateArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PlannedExercises.
     * @param {PlannedExerciseCreateManyArgs} args - Arguments to create many PlannedExercises.
     * @example
     * // Create many PlannedExercises
     * const plannedExercise = await prisma.plannedExercise.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PlannedExerciseCreateManyArgs>(args?: SelectSubset<T, PlannedExerciseCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PlannedExercises and returns the data saved in the database.
     * @param {PlannedExerciseCreateManyAndReturnArgs} args - Arguments to create many PlannedExercises.
     * @example
     * // Create many PlannedExercises
     * const plannedExercise = await prisma.plannedExercise.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PlannedExercises and only return the `id`
     * const plannedExerciseWithIdOnly = await prisma.plannedExercise.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PlannedExerciseCreateManyAndReturnArgs>(args?: SelectSubset<T, PlannedExerciseCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PlannedExercise.
     * @param {PlannedExerciseDeleteArgs} args - Arguments to delete one PlannedExercise.
     * @example
     * // Delete one PlannedExercise
     * const PlannedExercise = await prisma.plannedExercise.delete({
     *   where: {
     *     // ... filter to delete one PlannedExercise
     *   }
     * })
     * 
     */
    delete<T extends PlannedExerciseDeleteArgs>(args: SelectSubset<T, PlannedExerciseDeleteArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PlannedExercise.
     * @param {PlannedExerciseUpdateArgs} args - Arguments to update one PlannedExercise.
     * @example
     * // Update one PlannedExercise
     * const plannedExercise = await prisma.plannedExercise.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PlannedExerciseUpdateArgs>(args: SelectSubset<T, PlannedExerciseUpdateArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PlannedExercises.
     * @param {PlannedExerciseDeleteManyArgs} args - Arguments to filter PlannedExercises to delete.
     * @example
     * // Delete a few PlannedExercises
     * const { count } = await prisma.plannedExercise.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PlannedExerciseDeleteManyArgs>(args?: SelectSubset<T, PlannedExerciseDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlannedExercises.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedExerciseUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PlannedExercises
     * const plannedExercise = await prisma.plannedExercise.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PlannedExerciseUpdateManyArgs>(args: SelectSubset<T, PlannedExerciseUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlannedExercises and returns the data updated in the database.
     * @param {PlannedExerciseUpdateManyAndReturnArgs} args - Arguments to update many PlannedExercises.
     * @example
     * // Update many PlannedExercises
     * const plannedExercise = await prisma.plannedExercise.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PlannedExercises and only return the `id`
     * const plannedExerciseWithIdOnly = await prisma.plannedExercise.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PlannedExerciseUpdateManyAndReturnArgs>(args: SelectSubset<T, PlannedExerciseUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PlannedExercise.
     * @param {PlannedExerciseUpsertArgs} args - Arguments to update or create a PlannedExercise.
     * @example
     * // Update or create a PlannedExercise
     * const plannedExercise = await prisma.plannedExercise.upsert({
     *   create: {
     *     // ... data to create a PlannedExercise
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PlannedExercise we want to update
     *   }
     * })
     */
    upsert<T extends PlannedExerciseUpsertArgs>(args: SelectSubset<T, PlannedExerciseUpsertArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PlannedExercises.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedExerciseCountArgs} args - Arguments to filter PlannedExercises to count.
     * @example
     * // Count the number of PlannedExercises
     * const count = await prisma.plannedExercise.count({
     *   where: {
     *     // ... the filter for the PlannedExercises we want to count
     *   }
     * })
    **/
    count<T extends PlannedExerciseCountArgs>(
      args?: Subset<T, PlannedExerciseCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PlannedExerciseCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PlannedExercise.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedExerciseAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PlannedExerciseAggregateArgs>(args: Subset<T, PlannedExerciseAggregateArgs>): Prisma.PrismaPromise<GetPlannedExerciseAggregateType<T>>

    /**
     * Group by PlannedExercise.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlannedExerciseGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PlannedExerciseGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PlannedExerciseGroupByArgs['orderBy'] }
        : { orderBy?: PlannedExerciseGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PlannedExerciseGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPlannedExerciseGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PlannedExercise model
   */
  readonly fields: PlannedExerciseFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PlannedExercise.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PlannedExerciseClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    session<T extends PlannedSessionDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PlannedSessionDefaultArgs<ExtArgs>>): Prisma__PlannedSessionClient<$Result.GetResult<Prisma.$PlannedSessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    exercise<T extends ExerciseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ExerciseDefaultArgs<ExtArgs>>): Prisma__ExerciseClient<$Result.GetResult<Prisma.$ExercisePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    loggedSets<T extends PlannedExercise$loggedSetsArgs<ExtArgs> = {}>(args?: Subset<T, PlannedExercise$loggedSetsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PlannedExercise model
   */
  interface PlannedExerciseFieldRefs {
    readonly id: FieldRef<"PlannedExercise", 'String'>
    readonly order: FieldRef<"PlannedExercise", 'Int'>
    readonly sessionId: FieldRef<"PlannedExercise", 'String'>
    readonly exerciseId: FieldRef<"PlannedExercise", 'String'>
    readonly beginnerSets: FieldRef<"PlannedExercise", 'Int'>
    readonly beginnerReps: FieldRef<"PlannedExercise", 'Int'>
    readonly intermediateSets: FieldRef<"PlannedExercise", 'Int'>
    readonly intermediateReps: FieldRef<"PlannedExercise", 'Int'>
    readonly advancedSets: FieldRef<"PlannedExercise", 'Int'>
    readonly advancedReps: FieldRef<"PlannedExercise", 'Int'>
    readonly restSeconds: FieldRef<"PlannedExercise", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * PlannedExercise findUnique
   */
  export type PlannedExerciseFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * Filter, which PlannedExercise to fetch.
     */
    where: PlannedExerciseWhereUniqueInput
  }

  /**
   * PlannedExercise findUniqueOrThrow
   */
  export type PlannedExerciseFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * Filter, which PlannedExercise to fetch.
     */
    where: PlannedExerciseWhereUniqueInput
  }

  /**
   * PlannedExercise findFirst
   */
  export type PlannedExerciseFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * Filter, which PlannedExercise to fetch.
     */
    where?: PlannedExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedExercises to fetch.
     */
    orderBy?: PlannedExerciseOrderByWithRelationInput | PlannedExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlannedExercises.
     */
    cursor?: PlannedExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedExercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedExercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlannedExercises.
     */
    distinct?: PlannedExerciseScalarFieldEnum | PlannedExerciseScalarFieldEnum[]
  }

  /**
   * PlannedExercise findFirstOrThrow
   */
  export type PlannedExerciseFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * Filter, which PlannedExercise to fetch.
     */
    where?: PlannedExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedExercises to fetch.
     */
    orderBy?: PlannedExerciseOrderByWithRelationInput | PlannedExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlannedExercises.
     */
    cursor?: PlannedExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedExercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedExercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlannedExercises.
     */
    distinct?: PlannedExerciseScalarFieldEnum | PlannedExerciseScalarFieldEnum[]
  }

  /**
   * PlannedExercise findMany
   */
  export type PlannedExerciseFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * Filter, which PlannedExercises to fetch.
     */
    where?: PlannedExerciseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlannedExercises to fetch.
     */
    orderBy?: PlannedExerciseOrderByWithRelationInput | PlannedExerciseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PlannedExercises.
     */
    cursor?: PlannedExerciseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlannedExercises from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlannedExercises.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlannedExercises.
     */
    distinct?: PlannedExerciseScalarFieldEnum | PlannedExerciseScalarFieldEnum[]
  }

  /**
   * PlannedExercise create
   */
  export type PlannedExerciseCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * The data needed to create a PlannedExercise.
     */
    data: XOR<PlannedExerciseCreateInput, PlannedExerciseUncheckedCreateInput>
  }

  /**
   * PlannedExercise createMany
   */
  export type PlannedExerciseCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PlannedExercises.
     */
    data: PlannedExerciseCreateManyInput | PlannedExerciseCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PlannedExercise createManyAndReturn
   */
  export type PlannedExerciseCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * The data used to create many PlannedExercises.
     */
    data: PlannedExerciseCreateManyInput | PlannedExerciseCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlannedExercise update
   */
  export type PlannedExerciseUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * The data needed to update a PlannedExercise.
     */
    data: XOR<PlannedExerciseUpdateInput, PlannedExerciseUncheckedUpdateInput>
    /**
     * Choose, which PlannedExercise to update.
     */
    where: PlannedExerciseWhereUniqueInput
  }

  /**
   * PlannedExercise updateMany
   */
  export type PlannedExerciseUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PlannedExercises.
     */
    data: XOR<PlannedExerciseUpdateManyMutationInput, PlannedExerciseUncheckedUpdateManyInput>
    /**
     * Filter which PlannedExercises to update
     */
    where?: PlannedExerciseWhereInput
    /**
     * Limit how many PlannedExercises to update.
     */
    limit?: number
  }

  /**
   * PlannedExercise updateManyAndReturn
   */
  export type PlannedExerciseUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * The data used to update PlannedExercises.
     */
    data: XOR<PlannedExerciseUpdateManyMutationInput, PlannedExerciseUncheckedUpdateManyInput>
    /**
     * Filter which PlannedExercises to update
     */
    where?: PlannedExerciseWhereInput
    /**
     * Limit how many PlannedExercises to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlannedExercise upsert
   */
  export type PlannedExerciseUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * The filter to search for the PlannedExercise to update in case it exists.
     */
    where: PlannedExerciseWhereUniqueInput
    /**
     * In case the PlannedExercise found by the `where` argument doesn't exist, create a new PlannedExercise with this data.
     */
    create: XOR<PlannedExerciseCreateInput, PlannedExerciseUncheckedCreateInput>
    /**
     * In case the PlannedExercise was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PlannedExerciseUpdateInput, PlannedExerciseUncheckedUpdateInput>
  }

  /**
   * PlannedExercise delete
   */
  export type PlannedExerciseDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
    /**
     * Filter which PlannedExercise to delete.
     */
    where: PlannedExerciseWhereUniqueInput
  }

  /**
   * PlannedExercise deleteMany
   */
  export type PlannedExerciseDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlannedExercises to delete
     */
    where?: PlannedExerciseWhereInput
    /**
     * Limit how many PlannedExercises to delete.
     */
    limit?: number
  }

  /**
   * PlannedExercise.loggedSets
   */
  export type PlannedExercise$loggedSetsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    where?: WorkoutLogWhereInput
    orderBy?: WorkoutLogOrderByWithRelationInput | WorkoutLogOrderByWithRelationInput[]
    cursor?: WorkoutLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WorkoutLogScalarFieldEnum | WorkoutLogScalarFieldEnum[]
  }

  /**
   * PlannedExercise without action
   */
  export type PlannedExerciseDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlannedExercise
     */
    select?: PlannedExerciseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlannedExercise
     */
    omit?: PlannedExerciseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlannedExerciseInclude<ExtArgs> | null
  }


  /**
   * Model PlanInstance
   */

  export type AggregatePlanInstance = {
    _count: PlanInstanceCountAggregateOutputType | null
    _avg: PlanInstanceAvgAggregateOutputType | null
    _sum: PlanInstanceSumAggregateOutputType | null
    _min: PlanInstanceMinAggregateOutputType | null
    _max: PlanInstanceMaxAggregateOutputType | null
  }

  export type PlanInstanceAvgAggregateOutputType = {
    currentSession: number | null
  }

  export type PlanInstanceSumAggregateOutputType = {
    currentSession: number | null
  }

  export type PlanInstanceMinAggregateOutputType = {
    id: string | null
    level: $Enums.UserLevel | null
    status: $Enums.InstanceStatus | null
    currentSession: number | null
    startedAt: Date | null
    completedAt: Date | null
    userId: string | null
    planId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PlanInstanceMaxAggregateOutputType = {
    id: string | null
    level: $Enums.UserLevel | null
    status: $Enums.InstanceStatus | null
    currentSession: number | null
    startedAt: Date | null
    completedAt: Date | null
    userId: string | null
    planId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PlanInstanceCountAggregateOutputType = {
    id: number
    level: number
    status: number
    currentSession: number
    startedAt: number
    completedAt: number
    sessionDraft: number
    userId: number
    planId: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type PlanInstanceAvgAggregateInputType = {
    currentSession?: true
  }

  export type PlanInstanceSumAggregateInputType = {
    currentSession?: true
  }

  export type PlanInstanceMinAggregateInputType = {
    id?: true
    level?: true
    status?: true
    currentSession?: true
    startedAt?: true
    completedAt?: true
    userId?: true
    planId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PlanInstanceMaxAggregateInputType = {
    id?: true
    level?: true
    status?: true
    currentSession?: true
    startedAt?: true
    completedAt?: true
    userId?: true
    planId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PlanInstanceCountAggregateInputType = {
    id?: true
    level?: true
    status?: true
    currentSession?: true
    startedAt?: true
    completedAt?: true
    sessionDraft?: true
    userId?: true
    planId?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type PlanInstanceAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlanInstance to aggregate.
     */
    where?: PlanInstanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanInstances to fetch.
     */
    orderBy?: PlanInstanceOrderByWithRelationInput | PlanInstanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PlanInstanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanInstances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanInstances.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PlanInstances
    **/
    _count?: true | PlanInstanceCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PlanInstanceAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PlanInstanceSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PlanInstanceMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PlanInstanceMaxAggregateInputType
  }

  export type GetPlanInstanceAggregateType<T extends PlanInstanceAggregateArgs> = {
        [P in keyof T & keyof AggregatePlanInstance]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePlanInstance[P]>
      : GetScalarType<T[P], AggregatePlanInstance[P]>
  }




  export type PlanInstanceGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlanInstanceWhereInput
    orderBy?: PlanInstanceOrderByWithAggregationInput | PlanInstanceOrderByWithAggregationInput[]
    by: PlanInstanceScalarFieldEnum[] | PlanInstanceScalarFieldEnum
    having?: PlanInstanceScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PlanInstanceCountAggregateInputType | true
    _avg?: PlanInstanceAvgAggregateInputType
    _sum?: PlanInstanceSumAggregateInputType
    _min?: PlanInstanceMinAggregateInputType
    _max?: PlanInstanceMaxAggregateInputType
  }

  export type PlanInstanceGroupByOutputType = {
    id: string
    level: $Enums.UserLevel
    status: $Enums.InstanceStatus
    currentSession: number
    startedAt: Date
    completedAt: Date | null
    sessionDraft: JsonValue | null
    userId: string
    planId: string
    createdAt: Date
    updatedAt: Date
    _count: PlanInstanceCountAggregateOutputType | null
    _avg: PlanInstanceAvgAggregateOutputType | null
    _sum: PlanInstanceSumAggregateOutputType | null
    _min: PlanInstanceMinAggregateOutputType | null
    _max: PlanInstanceMaxAggregateOutputType | null
  }

  type GetPlanInstanceGroupByPayload<T extends PlanInstanceGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PlanInstanceGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PlanInstanceGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PlanInstanceGroupByOutputType[P]>
            : GetScalarType<T[P], PlanInstanceGroupByOutputType[P]>
        }
      >
    >


  export type PlanInstanceSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    level?: boolean
    status?: boolean
    currentSession?: boolean
    startedAt?: boolean
    completedAt?: boolean
    sessionDraft?: boolean
    userId?: boolean
    planId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workoutLogs?: boolean | PlanInstance$workoutLogsArgs<ExtArgs>
    _count?: boolean | PlanInstanceCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["planInstance"]>

  export type PlanInstanceSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    level?: boolean
    status?: boolean
    currentSession?: boolean
    startedAt?: boolean
    completedAt?: boolean
    sessionDraft?: boolean
    userId?: boolean
    planId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["planInstance"]>

  export type PlanInstanceSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    level?: boolean
    status?: boolean
    currentSession?: boolean
    startedAt?: boolean
    completedAt?: boolean
    sessionDraft?: boolean
    userId?: boolean
    planId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["planInstance"]>

  export type PlanInstanceSelectScalar = {
    id?: boolean
    level?: boolean
    status?: boolean
    currentSession?: boolean
    startedAt?: boolean
    completedAt?: boolean
    sessionDraft?: boolean
    userId?: boolean
    planId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type PlanInstanceOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "level" | "status" | "currentSession" | "startedAt" | "completedAt" | "sessionDraft" | "userId" | "planId" | "createdAt" | "updatedAt", ExtArgs["result"]["planInstance"]>
  export type PlanInstanceInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
    workoutLogs?: boolean | PlanInstance$workoutLogsArgs<ExtArgs>
    _count?: boolean | PlanInstanceCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type PlanInstanceIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }
  export type PlanInstanceIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    plan?: boolean | WorkoutPlanDefaultArgs<ExtArgs>
  }

  export type $PlanInstancePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PlanInstance"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      plan: Prisma.$WorkoutPlanPayload<ExtArgs>
      workoutLogs: Prisma.$WorkoutLogPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      level: $Enums.UserLevel
      status: $Enums.InstanceStatus
      currentSession: number
      startedAt: Date
      completedAt: Date | null
      sessionDraft: Prisma.JsonValue | null
      userId: string
      planId: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["planInstance"]>
    composites: {}
  }

  type PlanInstanceGetPayload<S extends boolean | null | undefined | PlanInstanceDefaultArgs> = $Result.GetResult<Prisma.$PlanInstancePayload, S>

  type PlanInstanceCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PlanInstanceFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PlanInstanceCountAggregateInputType | true
    }

  export interface PlanInstanceDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PlanInstance'], meta: { name: 'PlanInstance' } }
    /**
     * Find zero or one PlanInstance that matches the filter.
     * @param {PlanInstanceFindUniqueArgs} args - Arguments to find a PlanInstance
     * @example
     * // Get one PlanInstance
     * const planInstance = await prisma.planInstance.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PlanInstanceFindUniqueArgs>(args: SelectSubset<T, PlanInstanceFindUniqueArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PlanInstance that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PlanInstanceFindUniqueOrThrowArgs} args - Arguments to find a PlanInstance
     * @example
     * // Get one PlanInstance
     * const planInstance = await prisma.planInstance.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PlanInstanceFindUniqueOrThrowArgs>(args: SelectSubset<T, PlanInstanceFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlanInstance that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanInstanceFindFirstArgs} args - Arguments to find a PlanInstance
     * @example
     * // Get one PlanInstance
     * const planInstance = await prisma.planInstance.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PlanInstanceFindFirstArgs>(args?: SelectSubset<T, PlanInstanceFindFirstArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlanInstance that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanInstanceFindFirstOrThrowArgs} args - Arguments to find a PlanInstance
     * @example
     * // Get one PlanInstance
     * const planInstance = await prisma.planInstance.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PlanInstanceFindFirstOrThrowArgs>(args?: SelectSubset<T, PlanInstanceFindFirstOrThrowArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PlanInstances that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanInstanceFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PlanInstances
     * const planInstances = await prisma.planInstance.findMany()
     * 
     * // Get first 10 PlanInstances
     * const planInstances = await prisma.planInstance.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const planInstanceWithIdOnly = await prisma.planInstance.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PlanInstanceFindManyArgs>(args?: SelectSubset<T, PlanInstanceFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PlanInstance.
     * @param {PlanInstanceCreateArgs} args - Arguments to create a PlanInstance.
     * @example
     * // Create one PlanInstance
     * const PlanInstance = await prisma.planInstance.create({
     *   data: {
     *     // ... data to create a PlanInstance
     *   }
     * })
     * 
     */
    create<T extends PlanInstanceCreateArgs>(args: SelectSubset<T, PlanInstanceCreateArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PlanInstances.
     * @param {PlanInstanceCreateManyArgs} args - Arguments to create many PlanInstances.
     * @example
     * // Create many PlanInstances
     * const planInstance = await prisma.planInstance.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PlanInstanceCreateManyArgs>(args?: SelectSubset<T, PlanInstanceCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PlanInstances and returns the data saved in the database.
     * @param {PlanInstanceCreateManyAndReturnArgs} args - Arguments to create many PlanInstances.
     * @example
     * // Create many PlanInstances
     * const planInstance = await prisma.planInstance.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PlanInstances and only return the `id`
     * const planInstanceWithIdOnly = await prisma.planInstance.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PlanInstanceCreateManyAndReturnArgs>(args?: SelectSubset<T, PlanInstanceCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PlanInstance.
     * @param {PlanInstanceDeleteArgs} args - Arguments to delete one PlanInstance.
     * @example
     * // Delete one PlanInstance
     * const PlanInstance = await prisma.planInstance.delete({
     *   where: {
     *     // ... filter to delete one PlanInstance
     *   }
     * })
     * 
     */
    delete<T extends PlanInstanceDeleteArgs>(args: SelectSubset<T, PlanInstanceDeleteArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PlanInstance.
     * @param {PlanInstanceUpdateArgs} args - Arguments to update one PlanInstance.
     * @example
     * // Update one PlanInstance
     * const planInstance = await prisma.planInstance.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PlanInstanceUpdateArgs>(args: SelectSubset<T, PlanInstanceUpdateArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PlanInstances.
     * @param {PlanInstanceDeleteManyArgs} args - Arguments to filter PlanInstances to delete.
     * @example
     * // Delete a few PlanInstances
     * const { count } = await prisma.planInstance.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PlanInstanceDeleteManyArgs>(args?: SelectSubset<T, PlanInstanceDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlanInstances.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanInstanceUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PlanInstances
     * const planInstance = await prisma.planInstance.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PlanInstanceUpdateManyArgs>(args: SelectSubset<T, PlanInstanceUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlanInstances and returns the data updated in the database.
     * @param {PlanInstanceUpdateManyAndReturnArgs} args - Arguments to update many PlanInstances.
     * @example
     * // Update many PlanInstances
     * const planInstance = await prisma.planInstance.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PlanInstances and only return the `id`
     * const planInstanceWithIdOnly = await prisma.planInstance.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PlanInstanceUpdateManyAndReturnArgs>(args: SelectSubset<T, PlanInstanceUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PlanInstance.
     * @param {PlanInstanceUpsertArgs} args - Arguments to update or create a PlanInstance.
     * @example
     * // Update or create a PlanInstance
     * const planInstance = await prisma.planInstance.upsert({
     *   create: {
     *     // ... data to create a PlanInstance
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PlanInstance we want to update
     *   }
     * })
     */
    upsert<T extends PlanInstanceUpsertArgs>(args: SelectSubset<T, PlanInstanceUpsertArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PlanInstances.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanInstanceCountArgs} args - Arguments to filter PlanInstances to count.
     * @example
     * // Count the number of PlanInstances
     * const count = await prisma.planInstance.count({
     *   where: {
     *     // ... the filter for the PlanInstances we want to count
     *   }
     * })
    **/
    count<T extends PlanInstanceCountArgs>(
      args?: Subset<T, PlanInstanceCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PlanInstanceCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PlanInstance.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanInstanceAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PlanInstanceAggregateArgs>(args: Subset<T, PlanInstanceAggregateArgs>): Prisma.PrismaPromise<GetPlanInstanceAggregateType<T>>

    /**
     * Group by PlanInstance.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlanInstanceGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PlanInstanceGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PlanInstanceGroupByArgs['orderBy'] }
        : { orderBy?: PlanInstanceGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PlanInstanceGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPlanInstanceGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PlanInstance model
   */
  readonly fields: PlanInstanceFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PlanInstance.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PlanInstanceClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    plan<T extends WorkoutPlanDefaultArgs<ExtArgs> = {}>(args?: Subset<T, WorkoutPlanDefaultArgs<ExtArgs>>): Prisma__WorkoutPlanClient<$Result.GetResult<Prisma.$WorkoutPlanPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    workoutLogs<T extends PlanInstance$workoutLogsArgs<ExtArgs> = {}>(args?: Subset<T, PlanInstance$workoutLogsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PlanInstance model
   */
  interface PlanInstanceFieldRefs {
    readonly id: FieldRef<"PlanInstance", 'String'>
    readonly level: FieldRef<"PlanInstance", 'UserLevel'>
    readonly status: FieldRef<"PlanInstance", 'InstanceStatus'>
    readonly currentSession: FieldRef<"PlanInstance", 'Int'>
    readonly startedAt: FieldRef<"PlanInstance", 'DateTime'>
    readonly completedAt: FieldRef<"PlanInstance", 'DateTime'>
    readonly sessionDraft: FieldRef<"PlanInstance", 'Json'>
    readonly userId: FieldRef<"PlanInstance", 'String'>
    readonly planId: FieldRef<"PlanInstance", 'String'>
    readonly createdAt: FieldRef<"PlanInstance", 'DateTime'>
    readonly updatedAt: FieldRef<"PlanInstance", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PlanInstance findUnique
   */
  export type PlanInstanceFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * Filter, which PlanInstance to fetch.
     */
    where: PlanInstanceWhereUniqueInput
  }

  /**
   * PlanInstance findUniqueOrThrow
   */
  export type PlanInstanceFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * Filter, which PlanInstance to fetch.
     */
    where: PlanInstanceWhereUniqueInput
  }

  /**
   * PlanInstance findFirst
   */
  export type PlanInstanceFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * Filter, which PlanInstance to fetch.
     */
    where?: PlanInstanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanInstances to fetch.
     */
    orderBy?: PlanInstanceOrderByWithRelationInput | PlanInstanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlanInstances.
     */
    cursor?: PlanInstanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanInstances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanInstances.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlanInstances.
     */
    distinct?: PlanInstanceScalarFieldEnum | PlanInstanceScalarFieldEnum[]
  }

  /**
   * PlanInstance findFirstOrThrow
   */
  export type PlanInstanceFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * Filter, which PlanInstance to fetch.
     */
    where?: PlanInstanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanInstances to fetch.
     */
    orderBy?: PlanInstanceOrderByWithRelationInput | PlanInstanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlanInstances.
     */
    cursor?: PlanInstanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanInstances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanInstances.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlanInstances.
     */
    distinct?: PlanInstanceScalarFieldEnum | PlanInstanceScalarFieldEnum[]
  }

  /**
   * PlanInstance findMany
   */
  export type PlanInstanceFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * Filter, which PlanInstances to fetch.
     */
    where?: PlanInstanceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlanInstances to fetch.
     */
    orderBy?: PlanInstanceOrderByWithRelationInput | PlanInstanceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PlanInstances.
     */
    cursor?: PlanInstanceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlanInstances from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlanInstances.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlanInstances.
     */
    distinct?: PlanInstanceScalarFieldEnum | PlanInstanceScalarFieldEnum[]
  }

  /**
   * PlanInstance create
   */
  export type PlanInstanceCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * The data needed to create a PlanInstance.
     */
    data: XOR<PlanInstanceCreateInput, PlanInstanceUncheckedCreateInput>
  }

  /**
   * PlanInstance createMany
   */
  export type PlanInstanceCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PlanInstances.
     */
    data: PlanInstanceCreateManyInput | PlanInstanceCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PlanInstance createManyAndReturn
   */
  export type PlanInstanceCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * The data used to create many PlanInstances.
     */
    data: PlanInstanceCreateManyInput | PlanInstanceCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlanInstance update
   */
  export type PlanInstanceUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * The data needed to update a PlanInstance.
     */
    data: XOR<PlanInstanceUpdateInput, PlanInstanceUncheckedUpdateInput>
    /**
     * Choose, which PlanInstance to update.
     */
    where: PlanInstanceWhereUniqueInput
  }

  /**
   * PlanInstance updateMany
   */
  export type PlanInstanceUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PlanInstances.
     */
    data: XOR<PlanInstanceUpdateManyMutationInput, PlanInstanceUncheckedUpdateManyInput>
    /**
     * Filter which PlanInstances to update
     */
    where?: PlanInstanceWhereInput
    /**
     * Limit how many PlanInstances to update.
     */
    limit?: number
  }

  /**
   * PlanInstance updateManyAndReturn
   */
  export type PlanInstanceUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * The data used to update PlanInstances.
     */
    data: XOR<PlanInstanceUpdateManyMutationInput, PlanInstanceUncheckedUpdateManyInput>
    /**
     * Filter which PlanInstances to update
     */
    where?: PlanInstanceWhereInput
    /**
     * Limit how many PlanInstances to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * PlanInstance upsert
   */
  export type PlanInstanceUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * The filter to search for the PlanInstance to update in case it exists.
     */
    where: PlanInstanceWhereUniqueInput
    /**
     * In case the PlanInstance found by the `where` argument doesn't exist, create a new PlanInstance with this data.
     */
    create: XOR<PlanInstanceCreateInput, PlanInstanceUncheckedCreateInput>
    /**
     * In case the PlanInstance was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PlanInstanceUpdateInput, PlanInstanceUncheckedUpdateInput>
  }

  /**
   * PlanInstance delete
   */
  export type PlanInstanceDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
    /**
     * Filter which PlanInstance to delete.
     */
    where: PlanInstanceWhereUniqueInput
  }

  /**
   * PlanInstance deleteMany
   */
  export type PlanInstanceDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlanInstances to delete
     */
    where?: PlanInstanceWhereInput
    /**
     * Limit how many PlanInstances to delete.
     */
    limit?: number
  }

  /**
   * PlanInstance.workoutLogs
   */
  export type PlanInstance$workoutLogsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    where?: WorkoutLogWhereInput
    orderBy?: WorkoutLogOrderByWithRelationInput | WorkoutLogOrderByWithRelationInput[]
    cursor?: WorkoutLogWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WorkoutLogScalarFieldEnum | WorkoutLogScalarFieldEnum[]
  }

  /**
   * PlanInstance without action
   */
  export type PlanInstanceDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlanInstance
     */
    select?: PlanInstanceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlanInstance
     */
    omit?: PlanInstanceOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlanInstanceInclude<ExtArgs> | null
  }


  /**
   * Model WorkoutLog
   */

  export type AggregateWorkoutLog = {
    _count: WorkoutLogCountAggregateOutputType | null
    _avg: WorkoutLogAvgAggregateOutputType | null
    _sum: WorkoutLogSumAggregateOutputType | null
    _min: WorkoutLogMinAggregateOutputType | null
    _max: WorkoutLogMaxAggregateOutputType | null
  }

  export type WorkoutLogAvgAggregateOutputType = {
    sessionNumber: number | null
    weightKg: number | null
    actualReps: number | null
    actualSets: number | null
  }

  export type WorkoutLogSumAggregateOutputType = {
    sessionNumber: number | null
    weightKg: number | null
    actualReps: number | null
    actualSets: number | null
  }

  export type WorkoutLogMinAggregateOutputType = {
    id: string | null
    sessionNumber: number | null
    completedAt: Date | null
    weightKg: number | null
    actualReps: number | null
    actualSets: number | null
    userId: string | null
    instanceId: string | null
    plannedExerciseId: string | null
    createdAt: Date | null
  }

  export type WorkoutLogMaxAggregateOutputType = {
    id: string | null
    sessionNumber: number | null
    completedAt: Date | null
    weightKg: number | null
    actualReps: number | null
    actualSets: number | null
    userId: string | null
    instanceId: string | null
    plannedExerciseId: string | null
    createdAt: Date | null
  }

  export type WorkoutLogCountAggregateOutputType = {
    id: number
    sessionNumber: number
    completedAt: number
    weightKg: number
    actualReps: number
    actualSets: number
    userId: number
    instanceId: number
    plannedExerciseId: number
    createdAt: number
    _all: number
  }


  export type WorkoutLogAvgAggregateInputType = {
    sessionNumber?: true
    weightKg?: true
    actualReps?: true
    actualSets?: true
  }

  export type WorkoutLogSumAggregateInputType = {
    sessionNumber?: true
    weightKg?: true
    actualReps?: true
    actualSets?: true
  }

  export type WorkoutLogMinAggregateInputType = {
    id?: true
    sessionNumber?: true
    completedAt?: true
    weightKg?: true
    actualReps?: true
    actualSets?: true
    userId?: true
    instanceId?: true
    plannedExerciseId?: true
    createdAt?: true
  }

  export type WorkoutLogMaxAggregateInputType = {
    id?: true
    sessionNumber?: true
    completedAt?: true
    weightKg?: true
    actualReps?: true
    actualSets?: true
    userId?: true
    instanceId?: true
    plannedExerciseId?: true
    createdAt?: true
  }

  export type WorkoutLogCountAggregateInputType = {
    id?: true
    sessionNumber?: true
    completedAt?: true
    weightKg?: true
    actualReps?: true
    actualSets?: true
    userId?: true
    instanceId?: true
    plannedExerciseId?: true
    createdAt?: true
    _all?: true
  }

  export type WorkoutLogAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WorkoutLog to aggregate.
     */
    where?: WorkoutLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutLogs to fetch.
     */
    orderBy?: WorkoutLogOrderByWithRelationInput | WorkoutLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WorkoutLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned WorkoutLogs
    **/
    _count?: true | WorkoutLogCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: WorkoutLogAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: WorkoutLogSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WorkoutLogMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WorkoutLogMaxAggregateInputType
  }

  export type GetWorkoutLogAggregateType<T extends WorkoutLogAggregateArgs> = {
        [P in keyof T & keyof AggregateWorkoutLog]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWorkoutLog[P]>
      : GetScalarType<T[P], AggregateWorkoutLog[P]>
  }




  export type WorkoutLogGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WorkoutLogWhereInput
    orderBy?: WorkoutLogOrderByWithAggregationInput | WorkoutLogOrderByWithAggregationInput[]
    by: WorkoutLogScalarFieldEnum[] | WorkoutLogScalarFieldEnum
    having?: WorkoutLogScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WorkoutLogCountAggregateInputType | true
    _avg?: WorkoutLogAvgAggregateInputType
    _sum?: WorkoutLogSumAggregateInputType
    _min?: WorkoutLogMinAggregateInputType
    _max?: WorkoutLogMaxAggregateInputType
  }

  export type WorkoutLogGroupByOutputType = {
    id: string
    sessionNumber: number
    completedAt: Date
    weightKg: number | null
    actualReps: number | null
    actualSets: number | null
    userId: string
    instanceId: string
    plannedExerciseId: string
    createdAt: Date
    _count: WorkoutLogCountAggregateOutputType | null
    _avg: WorkoutLogAvgAggregateOutputType | null
    _sum: WorkoutLogSumAggregateOutputType | null
    _min: WorkoutLogMinAggregateOutputType | null
    _max: WorkoutLogMaxAggregateOutputType | null
  }

  type GetWorkoutLogGroupByPayload<T extends WorkoutLogGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WorkoutLogGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WorkoutLogGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WorkoutLogGroupByOutputType[P]>
            : GetScalarType<T[P], WorkoutLogGroupByOutputType[P]>
        }
      >
    >


  export type WorkoutLogSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionNumber?: boolean
    completedAt?: boolean
    weightKg?: boolean
    actualReps?: boolean
    actualSets?: boolean
    userId?: boolean
    instanceId?: boolean
    plannedExerciseId?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    instance?: boolean | PlanInstanceDefaultArgs<ExtArgs>
    plannedExercise?: boolean | PlannedExerciseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workoutLog"]>

  export type WorkoutLogSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionNumber?: boolean
    completedAt?: boolean
    weightKg?: boolean
    actualReps?: boolean
    actualSets?: boolean
    userId?: boolean
    instanceId?: boolean
    plannedExerciseId?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    instance?: boolean | PlanInstanceDefaultArgs<ExtArgs>
    plannedExercise?: boolean | PlannedExerciseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workoutLog"]>

  export type WorkoutLogSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sessionNumber?: boolean
    completedAt?: boolean
    weightKg?: boolean
    actualReps?: boolean
    actualSets?: boolean
    userId?: boolean
    instanceId?: boolean
    plannedExerciseId?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    instance?: boolean | PlanInstanceDefaultArgs<ExtArgs>
    plannedExercise?: boolean | PlannedExerciseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["workoutLog"]>

  export type WorkoutLogSelectScalar = {
    id?: boolean
    sessionNumber?: boolean
    completedAt?: boolean
    weightKg?: boolean
    actualReps?: boolean
    actualSets?: boolean
    userId?: boolean
    instanceId?: boolean
    plannedExerciseId?: boolean
    createdAt?: boolean
  }

  export type WorkoutLogOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "sessionNumber" | "completedAt" | "weightKg" | "actualReps" | "actualSets" | "userId" | "instanceId" | "plannedExerciseId" | "createdAt", ExtArgs["result"]["workoutLog"]>
  export type WorkoutLogInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    instance?: boolean | PlanInstanceDefaultArgs<ExtArgs>
    plannedExercise?: boolean | PlannedExerciseDefaultArgs<ExtArgs>
  }
  export type WorkoutLogIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    instance?: boolean | PlanInstanceDefaultArgs<ExtArgs>
    plannedExercise?: boolean | PlannedExerciseDefaultArgs<ExtArgs>
  }
  export type WorkoutLogIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    instance?: boolean | PlanInstanceDefaultArgs<ExtArgs>
    plannedExercise?: boolean | PlannedExerciseDefaultArgs<ExtArgs>
  }

  export type $WorkoutLogPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "WorkoutLog"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      instance: Prisma.$PlanInstancePayload<ExtArgs>
      plannedExercise: Prisma.$PlannedExercisePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      sessionNumber: number
      completedAt: Date
      weightKg: number | null
      actualReps: number | null
      actualSets: number | null
      userId: string
      instanceId: string
      plannedExerciseId: string
      createdAt: Date
    }, ExtArgs["result"]["workoutLog"]>
    composites: {}
  }

  type WorkoutLogGetPayload<S extends boolean | null | undefined | WorkoutLogDefaultArgs> = $Result.GetResult<Prisma.$WorkoutLogPayload, S>

  type WorkoutLogCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WorkoutLogFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WorkoutLogCountAggregateInputType | true
    }

  export interface WorkoutLogDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['WorkoutLog'], meta: { name: 'WorkoutLog' } }
    /**
     * Find zero or one WorkoutLog that matches the filter.
     * @param {WorkoutLogFindUniqueArgs} args - Arguments to find a WorkoutLog
     * @example
     * // Get one WorkoutLog
     * const workoutLog = await prisma.workoutLog.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WorkoutLogFindUniqueArgs>(args: SelectSubset<T, WorkoutLogFindUniqueArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one WorkoutLog that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WorkoutLogFindUniqueOrThrowArgs} args - Arguments to find a WorkoutLog
     * @example
     * // Get one WorkoutLog
     * const workoutLog = await prisma.workoutLog.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WorkoutLogFindUniqueOrThrowArgs>(args: SelectSubset<T, WorkoutLogFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WorkoutLog that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutLogFindFirstArgs} args - Arguments to find a WorkoutLog
     * @example
     * // Get one WorkoutLog
     * const workoutLog = await prisma.workoutLog.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WorkoutLogFindFirstArgs>(args?: SelectSubset<T, WorkoutLogFindFirstArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first WorkoutLog that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutLogFindFirstOrThrowArgs} args - Arguments to find a WorkoutLog
     * @example
     * // Get one WorkoutLog
     * const workoutLog = await prisma.workoutLog.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WorkoutLogFindFirstOrThrowArgs>(args?: SelectSubset<T, WorkoutLogFindFirstOrThrowArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more WorkoutLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutLogFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WorkoutLogs
     * const workoutLogs = await prisma.workoutLog.findMany()
     * 
     * // Get first 10 WorkoutLogs
     * const workoutLogs = await prisma.workoutLog.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const workoutLogWithIdOnly = await prisma.workoutLog.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WorkoutLogFindManyArgs>(args?: SelectSubset<T, WorkoutLogFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a WorkoutLog.
     * @param {WorkoutLogCreateArgs} args - Arguments to create a WorkoutLog.
     * @example
     * // Create one WorkoutLog
     * const WorkoutLog = await prisma.workoutLog.create({
     *   data: {
     *     // ... data to create a WorkoutLog
     *   }
     * })
     * 
     */
    create<T extends WorkoutLogCreateArgs>(args: SelectSubset<T, WorkoutLogCreateArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many WorkoutLogs.
     * @param {WorkoutLogCreateManyArgs} args - Arguments to create many WorkoutLogs.
     * @example
     * // Create many WorkoutLogs
     * const workoutLog = await prisma.workoutLog.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WorkoutLogCreateManyArgs>(args?: SelectSubset<T, WorkoutLogCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many WorkoutLogs and returns the data saved in the database.
     * @param {WorkoutLogCreateManyAndReturnArgs} args - Arguments to create many WorkoutLogs.
     * @example
     * // Create many WorkoutLogs
     * const workoutLog = await prisma.workoutLog.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many WorkoutLogs and only return the `id`
     * const workoutLogWithIdOnly = await prisma.workoutLog.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends WorkoutLogCreateManyAndReturnArgs>(args?: SelectSubset<T, WorkoutLogCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a WorkoutLog.
     * @param {WorkoutLogDeleteArgs} args - Arguments to delete one WorkoutLog.
     * @example
     * // Delete one WorkoutLog
     * const WorkoutLog = await prisma.workoutLog.delete({
     *   where: {
     *     // ... filter to delete one WorkoutLog
     *   }
     * })
     * 
     */
    delete<T extends WorkoutLogDeleteArgs>(args: SelectSubset<T, WorkoutLogDeleteArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one WorkoutLog.
     * @param {WorkoutLogUpdateArgs} args - Arguments to update one WorkoutLog.
     * @example
     * // Update one WorkoutLog
     * const workoutLog = await prisma.workoutLog.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WorkoutLogUpdateArgs>(args: SelectSubset<T, WorkoutLogUpdateArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more WorkoutLogs.
     * @param {WorkoutLogDeleteManyArgs} args - Arguments to filter WorkoutLogs to delete.
     * @example
     * // Delete a few WorkoutLogs
     * const { count } = await prisma.workoutLog.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WorkoutLogDeleteManyArgs>(args?: SelectSubset<T, WorkoutLogDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WorkoutLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutLogUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WorkoutLogs
     * const workoutLog = await prisma.workoutLog.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WorkoutLogUpdateManyArgs>(args: SelectSubset<T, WorkoutLogUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more WorkoutLogs and returns the data updated in the database.
     * @param {WorkoutLogUpdateManyAndReturnArgs} args - Arguments to update many WorkoutLogs.
     * @example
     * // Update many WorkoutLogs
     * const workoutLog = await prisma.workoutLog.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more WorkoutLogs and only return the `id`
     * const workoutLogWithIdOnly = await prisma.workoutLog.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends WorkoutLogUpdateManyAndReturnArgs>(args: SelectSubset<T, WorkoutLogUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one WorkoutLog.
     * @param {WorkoutLogUpsertArgs} args - Arguments to update or create a WorkoutLog.
     * @example
     * // Update or create a WorkoutLog
     * const workoutLog = await prisma.workoutLog.upsert({
     *   create: {
     *     // ... data to create a WorkoutLog
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WorkoutLog we want to update
     *   }
     * })
     */
    upsert<T extends WorkoutLogUpsertArgs>(args: SelectSubset<T, WorkoutLogUpsertArgs<ExtArgs>>): Prisma__WorkoutLogClient<$Result.GetResult<Prisma.$WorkoutLogPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of WorkoutLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutLogCountArgs} args - Arguments to filter WorkoutLogs to count.
     * @example
     * // Count the number of WorkoutLogs
     * const count = await prisma.workoutLog.count({
     *   where: {
     *     // ... the filter for the WorkoutLogs we want to count
     *   }
     * })
    **/
    count<T extends WorkoutLogCountArgs>(
      args?: Subset<T, WorkoutLogCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WorkoutLogCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a WorkoutLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutLogAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WorkoutLogAggregateArgs>(args: Subset<T, WorkoutLogAggregateArgs>): Prisma.PrismaPromise<GetWorkoutLogAggregateType<T>>

    /**
     * Group by WorkoutLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WorkoutLogGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WorkoutLogGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WorkoutLogGroupByArgs['orderBy'] }
        : { orderBy?: WorkoutLogGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WorkoutLogGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWorkoutLogGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the WorkoutLog model
   */
  readonly fields: WorkoutLogFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for WorkoutLog.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WorkoutLogClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    instance<T extends PlanInstanceDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PlanInstanceDefaultArgs<ExtArgs>>): Prisma__PlanInstanceClient<$Result.GetResult<Prisma.$PlanInstancePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    plannedExercise<T extends PlannedExerciseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PlannedExerciseDefaultArgs<ExtArgs>>): Prisma__PlannedExerciseClient<$Result.GetResult<Prisma.$PlannedExercisePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the WorkoutLog model
   */
  interface WorkoutLogFieldRefs {
    readonly id: FieldRef<"WorkoutLog", 'String'>
    readonly sessionNumber: FieldRef<"WorkoutLog", 'Int'>
    readonly completedAt: FieldRef<"WorkoutLog", 'DateTime'>
    readonly weightKg: FieldRef<"WorkoutLog", 'Float'>
    readonly actualReps: FieldRef<"WorkoutLog", 'Int'>
    readonly actualSets: FieldRef<"WorkoutLog", 'Int'>
    readonly userId: FieldRef<"WorkoutLog", 'String'>
    readonly instanceId: FieldRef<"WorkoutLog", 'String'>
    readonly plannedExerciseId: FieldRef<"WorkoutLog", 'String'>
    readonly createdAt: FieldRef<"WorkoutLog", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * WorkoutLog findUnique
   */
  export type WorkoutLogFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutLog to fetch.
     */
    where: WorkoutLogWhereUniqueInput
  }

  /**
   * WorkoutLog findUniqueOrThrow
   */
  export type WorkoutLogFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutLog to fetch.
     */
    where: WorkoutLogWhereUniqueInput
  }

  /**
   * WorkoutLog findFirst
   */
  export type WorkoutLogFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutLog to fetch.
     */
    where?: WorkoutLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutLogs to fetch.
     */
    orderBy?: WorkoutLogOrderByWithRelationInput | WorkoutLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WorkoutLogs.
     */
    cursor?: WorkoutLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutLogs.
     */
    distinct?: WorkoutLogScalarFieldEnum | WorkoutLogScalarFieldEnum[]
  }

  /**
   * WorkoutLog findFirstOrThrow
   */
  export type WorkoutLogFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutLog to fetch.
     */
    where?: WorkoutLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutLogs to fetch.
     */
    orderBy?: WorkoutLogOrderByWithRelationInput | WorkoutLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for WorkoutLogs.
     */
    cursor?: WorkoutLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutLogs.
     */
    distinct?: WorkoutLogScalarFieldEnum | WorkoutLogScalarFieldEnum[]
  }

  /**
   * WorkoutLog findMany
   */
  export type WorkoutLogFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * Filter, which WorkoutLogs to fetch.
     */
    where?: WorkoutLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of WorkoutLogs to fetch.
     */
    orderBy?: WorkoutLogOrderByWithRelationInput | WorkoutLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing WorkoutLogs.
     */
    cursor?: WorkoutLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` WorkoutLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` WorkoutLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of WorkoutLogs.
     */
    distinct?: WorkoutLogScalarFieldEnum | WorkoutLogScalarFieldEnum[]
  }

  /**
   * WorkoutLog create
   */
  export type WorkoutLogCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * The data needed to create a WorkoutLog.
     */
    data: XOR<WorkoutLogCreateInput, WorkoutLogUncheckedCreateInput>
  }

  /**
   * WorkoutLog createMany
   */
  export type WorkoutLogCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many WorkoutLogs.
     */
    data: WorkoutLogCreateManyInput | WorkoutLogCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * WorkoutLog createManyAndReturn
   */
  export type WorkoutLogCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * The data used to create many WorkoutLogs.
     */
    data: WorkoutLogCreateManyInput | WorkoutLogCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * WorkoutLog update
   */
  export type WorkoutLogUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * The data needed to update a WorkoutLog.
     */
    data: XOR<WorkoutLogUpdateInput, WorkoutLogUncheckedUpdateInput>
    /**
     * Choose, which WorkoutLog to update.
     */
    where: WorkoutLogWhereUniqueInput
  }

  /**
   * WorkoutLog updateMany
   */
  export type WorkoutLogUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update WorkoutLogs.
     */
    data: XOR<WorkoutLogUpdateManyMutationInput, WorkoutLogUncheckedUpdateManyInput>
    /**
     * Filter which WorkoutLogs to update
     */
    where?: WorkoutLogWhereInput
    /**
     * Limit how many WorkoutLogs to update.
     */
    limit?: number
  }

  /**
   * WorkoutLog updateManyAndReturn
   */
  export type WorkoutLogUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * The data used to update WorkoutLogs.
     */
    data: XOR<WorkoutLogUpdateManyMutationInput, WorkoutLogUncheckedUpdateManyInput>
    /**
     * Filter which WorkoutLogs to update
     */
    where?: WorkoutLogWhereInput
    /**
     * Limit how many WorkoutLogs to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * WorkoutLog upsert
   */
  export type WorkoutLogUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * The filter to search for the WorkoutLog to update in case it exists.
     */
    where: WorkoutLogWhereUniqueInput
    /**
     * In case the WorkoutLog found by the `where` argument doesn't exist, create a new WorkoutLog with this data.
     */
    create: XOR<WorkoutLogCreateInput, WorkoutLogUncheckedCreateInput>
    /**
     * In case the WorkoutLog was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WorkoutLogUpdateInput, WorkoutLogUncheckedUpdateInput>
  }

  /**
   * WorkoutLog delete
   */
  export type WorkoutLogDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
    /**
     * Filter which WorkoutLog to delete.
     */
    where: WorkoutLogWhereUniqueInput
  }

  /**
   * WorkoutLog deleteMany
   */
  export type WorkoutLogDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which WorkoutLogs to delete
     */
    where?: WorkoutLogWhereInput
    /**
     * Limit how many WorkoutLogs to delete.
     */
    limit?: number
  }

  /**
   * WorkoutLog without action
   */
  export type WorkoutLogDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WorkoutLog
     */
    select?: WorkoutLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the WorkoutLog
     */
    omit?: WorkoutLogOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WorkoutLogInclude<ExtArgs> | null
  }


  /**
   * Model Subscription
   */

  export type AggregateSubscription = {
    _count: SubscriptionCountAggregateOutputType | null
    _min: SubscriptionMinAggregateOutputType | null
    _max: SubscriptionMaxAggregateOutputType | null
  }

  export type SubscriptionMinAggregateOutputType = {
    id: string | null
    plan: $Enums.Plan | null
    status: string | null
    source: string | null
    startedAt: Date | null
    expiresAt: Date | null
    userId: string | null
  }

  export type SubscriptionMaxAggregateOutputType = {
    id: string | null
    plan: $Enums.Plan | null
    status: string | null
    source: string | null
    startedAt: Date | null
    expiresAt: Date | null
    userId: string | null
  }

  export type SubscriptionCountAggregateOutputType = {
    id: number
    plan: number
    status: number
    source: number
    startedAt: number
    expiresAt: number
    userId: number
    _all: number
  }


  export type SubscriptionMinAggregateInputType = {
    id?: true
    plan?: true
    status?: true
    source?: true
    startedAt?: true
    expiresAt?: true
    userId?: true
  }

  export type SubscriptionMaxAggregateInputType = {
    id?: true
    plan?: true
    status?: true
    source?: true
    startedAt?: true
    expiresAt?: true
    userId?: true
  }

  export type SubscriptionCountAggregateInputType = {
    id?: true
    plan?: true
    status?: true
    source?: true
    startedAt?: true
    expiresAt?: true
    userId?: true
    _all?: true
  }

  export type SubscriptionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Subscription to aggregate.
     */
    where?: SubscriptionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Subscriptions to fetch.
     */
    orderBy?: SubscriptionOrderByWithRelationInput | SubscriptionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SubscriptionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Subscriptions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Subscriptions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Subscriptions
    **/
    _count?: true | SubscriptionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SubscriptionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SubscriptionMaxAggregateInputType
  }

  export type GetSubscriptionAggregateType<T extends SubscriptionAggregateArgs> = {
        [P in keyof T & keyof AggregateSubscription]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSubscription[P]>
      : GetScalarType<T[P], AggregateSubscription[P]>
  }




  export type SubscriptionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SubscriptionWhereInput
    orderBy?: SubscriptionOrderByWithAggregationInput | SubscriptionOrderByWithAggregationInput[]
    by: SubscriptionScalarFieldEnum[] | SubscriptionScalarFieldEnum
    having?: SubscriptionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SubscriptionCountAggregateInputType | true
    _min?: SubscriptionMinAggregateInputType
    _max?: SubscriptionMaxAggregateInputType
  }

  export type SubscriptionGroupByOutputType = {
    id: string
    plan: $Enums.Plan
    status: string
    source: string | null
    startedAt: Date
    expiresAt: Date | null
    userId: string
    _count: SubscriptionCountAggregateOutputType | null
    _min: SubscriptionMinAggregateOutputType | null
    _max: SubscriptionMaxAggregateOutputType | null
  }

  type GetSubscriptionGroupByPayload<T extends SubscriptionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SubscriptionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SubscriptionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SubscriptionGroupByOutputType[P]>
            : GetScalarType<T[P], SubscriptionGroupByOutputType[P]>
        }
      >
    >


  export type SubscriptionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    plan?: boolean
    status?: boolean
    source?: boolean
    startedAt?: boolean
    expiresAt?: boolean
    userId?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["subscription"]>

  export type SubscriptionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    plan?: boolean
    status?: boolean
    source?: boolean
    startedAt?: boolean
    expiresAt?: boolean
    userId?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["subscription"]>

  export type SubscriptionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    plan?: boolean
    status?: boolean
    source?: boolean
    startedAt?: boolean
    expiresAt?: boolean
    userId?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["subscription"]>

  export type SubscriptionSelectScalar = {
    id?: boolean
    plan?: boolean
    status?: boolean
    source?: boolean
    startedAt?: boolean
    expiresAt?: boolean
    userId?: boolean
  }

  export type SubscriptionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "plan" | "status" | "source" | "startedAt" | "expiresAt" | "userId", ExtArgs["result"]["subscription"]>
  export type SubscriptionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type SubscriptionIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type SubscriptionIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $SubscriptionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Subscription"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      plan: $Enums.Plan
      status: string
      source: string | null
      startedAt: Date
      expiresAt: Date | null
      userId: string
    }, ExtArgs["result"]["subscription"]>
    composites: {}
  }

  type SubscriptionGetPayload<S extends boolean | null | undefined | SubscriptionDefaultArgs> = $Result.GetResult<Prisma.$SubscriptionPayload, S>

  type SubscriptionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SubscriptionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SubscriptionCountAggregateInputType | true
    }

  export interface SubscriptionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Subscription'], meta: { name: 'Subscription' } }
    /**
     * Find zero or one Subscription that matches the filter.
     * @param {SubscriptionFindUniqueArgs} args - Arguments to find a Subscription
     * @example
     * // Get one Subscription
     * const subscription = await prisma.subscription.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SubscriptionFindUniqueArgs>(args: SelectSubset<T, SubscriptionFindUniqueArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Subscription that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SubscriptionFindUniqueOrThrowArgs} args - Arguments to find a Subscription
     * @example
     * // Get one Subscription
     * const subscription = await prisma.subscription.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SubscriptionFindUniqueOrThrowArgs>(args: SelectSubset<T, SubscriptionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Subscription that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionFindFirstArgs} args - Arguments to find a Subscription
     * @example
     * // Get one Subscription
     * const subscription = await prisma.subscription.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SubscriptionFindFirstArgs>(args?: SelectSubset<T, SubscriptionFindFirstArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Subscription that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionFindFirstOrThrowArgs} args - Arguments to find a Subscription
     * @example
     * // Get one Subscription
     * const subscription = await prisma.subscription.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SubscriptionFindFirstOrThrowArgs>(args?: SelectSubset<T, SubscriptionFindFirstOrThrowArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Subscriptions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Subscriptions
     * const subscriptions = await prisma.subscription.findMany()
     * 
     * // Get first 10 Subscriptions
     * const subscriptions = await prisma.subscription.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const subscriptionWithIdOnly = await prisma.subscription.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SubscriptionFindManyArgs>(args?: SelectSubset<T, SubscriptionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Subscription.
     * @param {SubscriptionCreateArgs} args - Arguments to create a Subscription.
     * @example
     * // Create one Subscription
     * const Subscription = await prisma.subscription.create({
     *   data: {
     *     // ... data to create a Subscription
     *   }
     * })
     * 
     */
    create<T extends SubscriptionCreateArgs>(args: SelectSubset<T, SubscriptionCreateArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Subscriptions.
     * @param {SubscriptionCreateManyArgs} args - Arguments to create many Subscriptions.
     * @example
     * // Create many Subscriptions
     * const subscription = await prisma.subscription.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SubscriptionCreateManyArgs>(args?: SelectSubset<T, SubscriptionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Subscriptions and returns the data saved in the database.
     * @param {SubscriptionCreateManyAndReturnArgs} args - Arguments to create many Subscriptions.
     * @example
     * // Create many Subscriptions
     * const subscription = await prisma.subscription.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Subscriptions and only return the `id`
     * const subscriptionWithIdOnly = await prisma.subscription.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SubscriptionCreateManyAndReturnArgs>(args?: SelectSubset<T, SubscriptionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Subscription.
     * @param {SubscriptionDeleteArgs} args - Arguments to delete one Subscription.
     * @example
     * // Delete one Subscription
     * const Subscription = await prisma.subscription.delete({
     *   where: {
     *     // ... filter to delete one Subscription
     *   }
     * })
     * 
     */
    delete<T extends SubscriptionDeleteArgs>(args: SelectSubset<T, SubscriptionDeleteArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Subscription.
     * @param {SubscriptionUpdateArgs} args - Arguments to update one Subscription.
     * @example
     * // Update one Subscription
     * const subscription = await prisma.subscription.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SubscriptionUpdateArgs>(args: SelectSubset<T, SubscriptionUpdateArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Subscriptions.
     * @param {SubscriptionDeleteManyArgs} args - Arguments to filter Subscriptions to delete.
     * @example
     * // Delete a few Subscriptions
     * const { count } = await prisma.subscription.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SubscriptionDeleteManyArgs>(args?: SelectSubset<T, SubscriptionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Subscriptions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Subscriptions
     * const subscription = await prisma.subscription.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SubscriptionUpdateManyArgs>(args: SelectSubset<T, SubscriptionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Subscriptions and returns the data updated in the database.
     * @param {SubscriptionUpdateManyAndReturnArgs} args - Arguments to update many Subscriptions.
     * @example
     * // Update many Subscriptions
     * const subscription = await prisma.subscription.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Subscriptions and only return the `id`
     * const subscriptionWithIdOnly = await prisma.subscription.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SubscriptionUpdateManyAndReturnArgs>(args: SelectSubset<T, SubscriptionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Subscription.
     * @param {SubscriptionUpsertArgs} args - Arguments to update or create a Subscription.
     * @example
     * // Update or create a Subscription
     * const subscription = await prisma.subscription.upsert({
     *   create: {
     *     // ... data to create a Subscription
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Subscription we want to update
     *   }
     * })
     */
    upsert<T extends SubscriptionUpsertArgs>(args: SelectSubset<T, SubscriptionUpsertArgs<ExtArgs>>): Prisma__SubscriptionClient<$Result.GetResult<Prisma.$SubscriptionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Subscriptions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionCountArgs} args - Arguments to filter Subscriptions to count.
     * @example
     * // Count the number of Subscriptions
     * const count = await prisma.subscription.count({
     *   where: {
     *     // ... the filter for the Subscriptions we want to count
     *   }
     * })
    **/
    count<T extends SubscriptionCountArgs>(
      args?: Subset<T, SubscriptionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SubscriptionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Subscription.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SubscriptionAggregateArgs>(args: Subset<T, SubscriptionAggregateArgs>): Prisma.PrismaPromise<GetSubscriptionAggregateType<T>>

    /**
     * Group by Subscription.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubscriptionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SubscriptionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SubscriptionGroupByArgs['orderBy'] }
        : { orderBy?: SubscriptionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SubscriptionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSubscriptionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Subscription model
   */
  readonly fields: SubscriptionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Subscription.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SubscriptionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Subscription model
   */
  interface SubscriptionFieldRefs {
    readonly id: FieldRef<"Subscription", 'String'>
    readonly plan: FieldRef<"Subscription", 'Plan'>
    readonly status: FieldRef<"Subscription", 'String'>
    readonly source: FieldRef<"Subscription", 'String'>
    readonly startedAt: FieldRef<"Subscription", 'DateTime'>
    readonly expiresAt: FieldRef<"Subscription", 'DateTime'>
    readonly userId: FieldRef<"Subscription", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Subscription findUnique
   */
  export type SubscriptionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * Filter, which Subscription to fetch.
     */
    where: SubscriptionWhereUniqueInput
  }

  /**
   * Subscription findUniqueOrThrow
   */
  export type SubscriptionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * Filter, which Subscription to fetch.
     */
    where: SubscriptionWhereUniqueInput
  }

  /**
   * Subscription findFirst
   */
  export type SubscriptionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * Filter, which Subscription to fetch.
     */
    where?: SubscriptionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Subscriptions to fetch.
     */
    orderBy?: SubscriptionOrderByWithRelationInput | SubscriptionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Subscriptions.
     */
    cursor?: SubscriptionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Subscriptions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Subscriptions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Subscriptions.
     */
    distinct?: SubscriptionScalarFieldEnum | SubscriptionScalarFieldEnum[]
  }

  /**
   * Subscription findFirstOrThrow
   */
  export type SubscriptionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * Filter, which Subscription to fetch.
     */
    where?: SubscriptionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Subscriptions to fetch.
     */
    orderBy?: SubscriptionOrderByWithRelationInput | SubscriptionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Subscriptions.
     */
    cursor?: SubscriptionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Subscriptions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Subscriptions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Subscriptions.
     */
    distinct?: SubscriptionScalarFieldEnum | SubscriptionScalarFieldEnum[]
  }

  /**
   * Subscription findMany
   */
  export type SubscriptionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * Filter, which Subscriptions to fetch.
     */
    where?: SubscriptionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Subscriptions to fetch.
     */
    orderBy?: SubscriptionOrderByWithRelationInput | SubscriptionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Subscriptions.
     */
    cursor?: SubscriptionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Subscriptions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Subscriptions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Subscriptions.
     */
    distinct?: SubscriptionScalarFieldEnum | SubscriptionScalarFieldEnum[]
  }

  /**
   * Subscription create
   */
  export type SubscriptionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * The data needed to create a Subscription.
     */
    data: XOR<SubscriptionCreateInput, SubscriptionUncheckedCreateInput>
  }

  /**
   * Subscription createMany
   */
  export type SubscriptionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Subscriptions.
     */
    data: SubscriptionCreateManyInput | SubscriptionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Subscription createManyAndReturn
   */
  export type SubscriptionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * The data used to create many Subscriptions.
     */
    data: SubscriptionCreateManyInput | SubscriptionCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Subscription update
   */
  export type SubscriptionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * The data needed to update a Subscription.
     */
    data: XOR<SubscriptionUpdateInput, SubscriptionUncheckedUpdateInput>
    /**
     * Choose, which Subscription to update.
     */
    where: SubscriptionWhereUniqueInput
  }

  /**
   * Subscription updateMany
   */
  export type SubscriptionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Subscriptions.
     */
    data: XOR<SubscriptionUpdateManyMutationInput, SubscriptionUncheckedUpdateManyInput>
    /**
     * Filter which Subscriptions to update
     */
    where?: SubscriptionWhereInput
    /**
     * Limit how many Subscriptions to update.
     */
    limit?: number
  }

  /**
   * Subscription updateManyAndReturn
   */
  export type SubscriptionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * The data used to update Subscriptions.
     */
    data: XOR<SubscriptionUpdateManyMutationInput, SubscriptionUncheckedUpdateManyInput>
    /**
     * Filter which Subscriptions to update
     */
    where?: SubscriptionWhereInput
    /**
     * Limit how many Subscriptions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Subscription upsert
   */
  export type SubscriptionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * The filter to search for the Subscription to update in case it exists.
     */
    where: SubscriptionWhereUniqueInput
    /**
     * In case the Subscription found by the `where` argument doesn't exist, create a new Subscription with this data.
     */
    create: XOR<SubscriptionCreateInput, SubscriptionUncheckedCreateInput>
    /**
     * In case the Subscription was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SubscriptionUpdateInput, SubscriptionUncheckedUpdateInput>
  }

  /**
   * Subscription delete
   */
  export type SubscriptionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
    /**
     * Filter which Subscription to delete.
     */
    where: SubscriptionWhereUniqueInput
  }

  /**
   * Subscription deleteMany
   */
  export type SubscriptionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Subscriptions to delete
     */
    where?: SubscriptionWhereInput
    /**
     * Limit how many Subscriptions to delete.
     */
    limit?: number
  }

  /**
   * Subscription without action
   */
  export type SubscriptionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Subscription
     */
    select?: SubscriptionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Subscription
     */
    omit?: SubscriptionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubscriptionInclude<ExtArgs> | null
  }


  /**
   * Model UserEquipment
   */

  export type AggregateUserEquipment = {
    _count: UserEquipmentCountAggregateOutputType | null
    _min: UserEquipmentMinAggregateOutputType | null
    _max: UserEquipmentMaxAggregateOutputType | null
  }

  export type UserEquipmentMinAggregateOutputType = {
    id: string | null
    source: $Enums.EquipmentSource | null
    addedAt: Date | null
    trialExpiresAt: Date | null
    userId: string | null
    equipmentId: string | null
  }

  export type UserEquipmentMaxAggregateOutputType = {
    id: string | null
    source: $Enums.EquipmentSource | null
    addedAt: Date | null
    trialExpiresAt: Date | null
    userId: string | null
    equipmentId: string | null
  }

  export type UserEquipmentCountAggregateOutputType = {
    id: number
    source: number
    addedAt: number
    trialExpiresAt: number
    userId: number
    equipmentId: number
    _all: number
  }


  export type UserEquipmentMinAggregateInputType = {
    id?: true
    source?: true
    addedAt?: true
    trialExpiresAt?: true
    userId?: true
    equipmentId?: true
  }

  export type UserEquipmentMaxAggregateInputType = {
    id?: true
    source?: true
    addedAt?: true
    trialExpiresAt?: true
    userId?: true
    equipmentId?: true
  }

  export type UserEquipmentCountAggregateInputType = {
    id?: true
    source?: true
    addedAt?: true
    trialExpiresAt?: true
    userId?: true
    equipmentId?: true
    _all?: true
  }

  export type UserEquipmentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserEquipment to aggregate.
     */
    where?: UserEquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserEquipments to fetch.
     */
    orderBy?: UserEquipmentOrderByWithRelationInput | UserEquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserEquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserEquipments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserEquipments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned UserEquipments
    **/
    _count?: true | UserEquipmentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserEquipmentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserEquipmentMaxAggregateInputType
  }

  export type GetUserEquipmentAggregateType<T extends UserEquipmentAggregateArgs> = {
        [P in keyof T & keyof AggregateUserEquipment]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUserEquipment[P]>
      : GetScalarType<T[P], AggregateUserEquipment[P]>
  }




  export type UserEquipmentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserEquipmentWhereInput
    orderBy?: UserEquipmentOrderByWithAggregationInput | UserEquipmentOrderByWithAggregationInput[]
    by: UserEquipmentScalarFieldEnum[] | UserEquipmentScalarFieldEnum
    having?: UserEquipmentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserEquipmentCountAggregateInputType | true
    _min?: UserEquipmentMinAggregateInputType
    _max?: UserEquipmentMaxAggregateInputType
  }

  export type UserEquipmentGroupByOutputType = {
    id: string
    source: $Enums.EquipmentSource
    addedAt: Date
    trialExpiresAt: Date | null
    userId: string
    equipmentId: string
    _count: UserEquipmentCountAggregateOutputType | null
    _min: UserEquipmentMinAggregateOutputType | null
    _max: UserEquipmentMaxAggregateOutputType | null
  }

  type GetUserEquipmentGroupByPayload<T extends UserEquipmentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserEquipmentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserEquipmentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserEquipmentGroupByOutputType[P]>
            : GetScalarType<T[P], UserEquipmentGroupByOutputType[P]>
        }
      >
    >


  export type UserEquipmentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    source?: boolean
    addedAt?: boolean
    trialExpiresAt?: boolean
    userId?: boolean
    equipmentId?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    equipment?: boolean | EquipmentDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userEquipment"]>

  export type UserEquipmentSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    source?: boolean
    addedAt?: boolean
    trialExpiresAt?: boolean
    userId?: boolean
    equipmentId?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    equipment?: boolean | EquipmentDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userEquipment"]>

  export type UserEquipmentSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    source?: boolean
    addedAt?: boolean
    trialExpiresAt?: boolean
    userId?: boolean
    equipmentId?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    equipment?: boolean | EquipmentDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userEquipment"]>

  export type UserEquipmentSelectScalar = {
    id?: boolean
    source?: boolean
    addedAt?: boolean
    trialExpiresAt?: boolean
    userId?: boolean
    equipmentId?: boolean
  }

  export type UserEquipmentOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "source" | "addedAt" | "trialExpiresAt" | "userId" | "equipmentId", ExtArgs["result"]["userEquipment"]>
  export type UserEquipmentInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    equipment?: boolean | EquipmentDefaultArgs<ExtArgs>
  }
  export type UserEquipmentIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    equipment?: boolean | EquipmentDefaultArgs<ExtArgs>
  }
  export type UserEquipmentIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    equipment?: boolean | EquipmentDefaultArgs<ExtArgs>
  }

  export type $UserEquipmentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "UserEquipment"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      equipment: Prisma.$EquipmentPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      source: $Enums.EquipmentSource
      addedAt: Date
      trialExpiresAt: Date | null
      userId: string
      equipmentId: string
    }, ExtArgs["result"]["userEquipment"]>
    composites: {}
  }

  type UserEquipmentGetPayload<S extends boolean | null | undefined | UserEquipmentDefaultArgs> = $Result.GetResult<Prisma.$UserEquipmentPayload, S>

  type UserEquipmentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserEquipmentFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserEquipmentCountAggregateInputType | true
    }

  export interface UserEquipmentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['UserEquipment'], meta: { name: 'UserEquipment' } }
    /**
     * Find zero or one UserEquipment that matches the filter.
     * @param {UserEquipmentFindUniqueArgs} args - Arguments to find a UserEquipment
     * @example
     * // Get one UserEquipment
     * const userEquipment = await prisma.userEquipment.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserEquipmentFindUniqueArgs>(args: SelectSubset<T, UserEquipmentFindUniqueArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one UserEquipment that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserEquipmentFindUniqueOrThrowArgs} args - Arguments to find a UserEquipment
     * @example
     * // Get one UserEquipment
     * const userEquipment = await prisma.userEquipment.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserEquipmentFindUniqueOrThrowArgs>(args: SelectSubset<T, UserEquipmentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserEquipment that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserEquipmentFindFirstArgs} args - Arguments to find a UserEquipment
     * @example
     * // Get one UserEquipment
     * const userEquipment = await prisma.userEquipment.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserEquipmentFindFirstArgs>(args?: SelectSubset<T, UserEquipmentFindFirstArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserEquipment that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserEquipmentFindFirstOrThrowArgs} args - Arguments to find a UserEquipment
     * @example
     * // Get one UserEquipment
     * const userEquipment = await prisma.userEquipment.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserEquipmentFindFirstOrThrowArgs>(args?: SelectSubset<T, UserEquipmentFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more UserEquipments that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserEquipmentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UserEquipments
     * const userEquipments = await prisma.userEquipment.findMany()
     * 
     * // Get first 10 UserEquipments
     * const userEquipments = await prisma.userEquipment.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userEquipmentWithIdOnly = await prisma.userEquipment.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserEquipmentFindManyArgs>(args?: SelectSubset<T, UserEquipmentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a UserEquipment.
     * @param {UserEquipmentCreateArgs} args - Arguments to create a UserEquipment.
     * @example
     * // Create one UserEquipment
     * const UserEquipment = await prisma.userEquipment.create({
     *   data: {
     *     // ... data to create a UserEquipment
     *   }
     * })
     * 
     */
    create<T extends UserEquipmentCreateArgs>(args: SelectSubset<T, UserEquipmentCreateArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many UserEquipments.
     * @param {UserEquipmentCreateManyArgs} args - Arguments to create many UserEquipments.
     * @example
     * // Create many UserEquipments
     * const userEquipment = await prisma.userEquipment.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserEquipmentCreateManyArgs>(args?: SelectSubset<T, UserEquipmentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many UserEquipments and returns the data saved in the database.
     * @param {UserEquipmentCreateManyAndReturnArgs} args - Arguments to create many UserEquipments.
     * @example
     * // Create many UserEquipments
     * const userEquipment = await prisma.userEquipment.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many UserEquipments and only return the `id`
     * const userEquipmentWithIdOnly = await prisma.userEquipment.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserEquipmentCreateManyAndReturnArgs>(args?: SelectSubset<T, UserEquipmentCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a UserEquipment.
     * @param {UserEquipmentDeleteArgs} args - Arguments to delete one UserEquipment.
     * @example
     * // Delete one UserEquipment
     * const UserEquipment = await prisma.userEquipment.delete({
     *   where: {
     *     // ... filter to delete one UserEquipment
     *   }
     * })
     * 
     */
    delete<T extends UserEquipmentDeleteArgs>(args: SelectSubset<T, UserEquipmentDeleteArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one UserEquipment.
     * @param {UserEquipmentUpdateArgs} args - Arguments to update one UserEquipment.
     * @example
     * // Update one UserEquipment
     * const userEquipment = await prisma.userEquipment.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserEquipmentUpdateArgs>(args: SelectSubset<T, UserEquipmentUpdateArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more UserEquipments.
     * @param {UserEquipmentDeleteManyArgs} args - Arguments to filter UserEquipments to delete.
     * @example
     * // Delete a few UserEquipments
     * const { count } = await prisma.userEquipment.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserEquipmentDeleteManyArgs>(args?: SelectSubset<T, UserEquipmentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserEquipments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserEquipmentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UserEquipments
     * const userEquipment = await prisma.userEquipment.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserEquipmentUpdateManyArgs>(args: SelectSubset<T, UserEquipmentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserEquipments and returns the data updated in the database.
     * @param {UserEquipmentUpdateManyAndReturnArgs} args - Arguments to update many UserEquipments.
     * @example
     * // Update many UserEquipments
     * const userEquipment = await prisma.userEquipment.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more UserEquipments and only return the `id`
     * const userEquipmentWithIdOnly = await prisma.userEquipment.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserEquipmentUpdateManyAndReturnArgs>(args: SelectSubset<T, UserEquipmentUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one UserEquipment.
     * @param {UserEquipmentUpsertArgs} args - Arguments to update or create a UserEquipment.
     * @example
     * // Update or create a UserEquipment
     * const userEquipment = await prisma.userEquipment.upsert({
     *   create: {
     *     // ... data to create a UserEquipment
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UserEquipment we want to update
     *   }
     * })
     */
    upsert<T extends UserEquipmentUpsertArgs>(args: SelectSubset<T, UserEquipmentUpsertArgs<ExtArgs>>): Prisma__UserEquipmentClient<$Result.GetResult<Prisma.$UserEquipmentPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of UserEquipments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserEquipmentCountArgs} args - Arguments to filter UserEquipments to count.
     * @example
     * // Count the number of UserEquipments
     * const count = await prisma.userEquipment.count({
     *   where: {
     *     // ... the filter for the UserEquipments we want to count
     *   }
     * })
    **/
    count<T extends UserEquipmentCountArgs>(
      args?: Subset<T, UserEquipmentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserEquipmentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UserEquipment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserEquipmentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserEquipmentAggregateArgs>(args: Subset<T, UserEquipmentAggregateArgs>): Prisma.PrismaPromise<GetUserEquipmentAggregateType<T>>

    /**
     * Group by UserEquipment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserEquipmentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserEquipmentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserEquipmentGroupByArgs['orderBy'] }
        : { orderBy?: UserEquipmentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserEquipmentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserEquipmentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the UserEquipment model
   */
  readonly fields: UserEquipmentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for UserEquipment.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserEquipmentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    equipment<T extends EquipmentDefaultArgs<ExtArgs> = {}>(args?: Subset<T, EquipmentDefaultArgs<ExtArgs>>): Prisma__EquipmentClient<$Result.GetResult<Prisma.$EquipmentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the UserEquipment model
   */
  interface UserEquipmentFieldRefs {
    readonly id: FieldRef<"UserEquipment", 'String'>
    readonly source: FieldRef<"UserEquipment", 'EquipmentSource'>
    readonly addedAt: FieldRef<"UserEquipment", 'DateTime'>
    readonly trialExpiresAt: FieldRef<"UserEquipment", 'DateTime'>
    readonly userId: FieldRef<"UserEquipment", 'String'>
    readonly equipmentId: FieldRef<"UserEquipment", 'String'>
  }
    

  // Custom InputTypes
  /**
   * UserEquipment findUnique
   */
  export type UserEquipmentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * Filter, which UserEquipment to fetch.
     */
    where: UserEquipmentWhereUniqueInput
  }

  /**
   * UserEquipment findUniqueOrThrow
   */
  export type UserEquipmentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * Filter, which UserEquipment to fetch.
     */
    where: UserEquipmentWhereUniqueInput
  }

  /**
   * UserEquipment findFirst
   */
  export type UserEquipmentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * Filter, which UserEquipment to fetch.
     */
    where?: UserEquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserEquipments to fetch.
     */
    orderBy?: UserEquipmentOrderByWithRelationInput | UserEquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserEquipments.
     */
    cursor?: UserEquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserEquipments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserEquipments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserEquipments.
     */
    distinct?: UserEquipmentScalarFieldEnum | UserEquipmentScalarFieldEnum[]
  }

  /**
   * UserEquipment findFirstOrThrow
   */
  export type UserEquipmentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * Filter, which UserEquipment to fetch.
     */
    where?: UserEquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserEquipments to fetch.
     */
    orderBy?: UserEquipmentOrderByWithRelationInput | UserEquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserEquipments.
     */
    cursor?: UserEquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserEquipments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserEquipments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserEquipments.
     */
    distinct?: UserEquipmentScalarFieldEnum | UserEquipmentScalarFieldEnum[]
  }

  /**
   * UserEquipment findMany
   */
  export type UserEquipmentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * Filter, which UserEquipments to fetch.
     */
    where?: UserEquipmentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserEquipments to fetch.
     */
    orderBy?: UserEquipmentOrderByWithRelationInput | UserEquipmentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing UserEquipments.
     */
    cursor?: UserEquipmentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserEquipments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserEquipments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserEquipments.
     */
    distinct?: UserEquipmentScalarFieldEnum | UserEquipmentScalarFieldEnum[]
  }

  /**
   * UserEquipment create
   */
  export type UserEquipmentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * The data needed to create a UserEquipment.
     */
    data: XOR<UserEquipmentCreateInput, UserEquipmentUncheckedCreateInput>
  }

  /**
   * UserEquipment createMany
   */
  export type UserEquipmentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many UserEquipments.
     */
    data: UserEquipmentCreateManyInput | UserEquipmentCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * UserEquipment createManyAndReturn
   */
  export type UserEquipmentCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * The data used to create many UserEquipments.
     */
    data: UserEquipmentCreateManyInput | UserEquipmentCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * UserEquipment update
   */
  export type UserEquipmentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * The data needed to update a UserEquipment.
     */
    data: XOR<UserEquipmentUpdateInput, UserEquipmentUncheckedUpdateInput>
    /**
     * Choose, which UserEquipment to update.
     */
    where: UserEquipmentWhereUniqueInput
  }

  /**
   * UserEquipment updateMany
   */
  export type UserEquipmentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update UserEquipments.
     */
    data: XOR<UserEquipmentUpdateManyMutationInput, UserEquipmentUncheckedUpdateManyInput>
    /**
     * Filter which UserEquipments to update
     */
    where?: UserEquipmentWhereInput
    /**
     * Limit how many UserEquipments to update.
     */
    limit?: number
  }

  /**
   * UserEquipment updateManyAndReturn
   */
  export type UserEquipmentUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * The data used to update UserEquipments.
     */
    data: XOR<UserEquipmentUpdateManyMutationInput, UserEquipmentUncheckedUpdateManyInput>
    /**
     * Filter which UserEquipments to update
     */
    where?: UserEquipmentWhereInput
    /**
     * Limit how many UserEquipments to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * UserEquipment upsert
   */
  export type UserEquipmentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * The filter to search for the UserEquipment to update in case it exists.
     */
    where: UserEquipmentWhereUniqueInput
    /**
     * In case the UserEquipment found by the `where` argument doesn't exist, create a new UserEquipment with this data.
     */
    create: XOR<UserEquipmentCreateInput, UserEquipmentUncheckedCreateInput>
    /**
     * In case the UserEquipment was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserEquipmentUpdateInput, UserEquipmentUncheckedUpdateInput>
  }

  /**
   * UserEquipment delete
   */
  export type UserEquipmentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
    /**
     * Filter which UserEquipment to delete.
     */
    where: UserEquipmentWhereUniqueInput
  }

  /**
   * UserEquipment deleteMany
   */
  export type UserEquipmentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserEquipments to delete
     */
    where?: UserEquipmentWhereInput
    /**
     * Limit how many UserEquipments to delete.
     */
    limit?: number
  }

  /**
   * UserEquipment without action
   */
  export type UserEquipmentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserEquipment
     */
    select?: UserEquipmentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserEquipment
     */
    omit?: UserEquipmentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserEquipmentInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    email: 'email',
    name: 'name',
    password: 'password',
    emailVerified: 'emailVerified',
    image: 'image',
    role: 'role',
    lastLoginAt: 'lastLoginAt',
    onboardingComplete: 'onboardingComplete',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    isNewUser: 'isNewUser',
    primaryGoal: 'primaryGoal',
    trainingLocation: 'trainingLocation',
    biologicalSex: 'biologicalSex',
    experienceLevel: 'experienceLevel',
    onboardingCompletedAt: 'onboardingCompletedAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const AccountScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    type: 'type',
    provider: 'provider',
    providerAccountId: 'providerAccountId',
    refresh_token: 'refresh_token',
    access_token: 'access_token',
    expires_at: 'expires_at',
    token_type: 'token_type',
    scope: 'scope',
    id_token: 'id_token',
    session_state: 'session_state'
  };

  export type AccountScalarFieldEnum = (typeof AccountScalarFieldEnum)[keyof typeof AccountScalarFieldEnum]


  export const NextAuthSessionScalarFieldEnum: {
    id: 'id',
    sessionToken: 'sessionToken',
    userId: 'userId',
    expires: 'expires'
  };

  export type NextAuthSessionScalarFieldEnum = (typeof NextAuthSessionScalarFieldEnum)[keyof typeof NextAuthSessionScalarFieldEnum]


  export const VerificationTokenScalarFieldEnum: {
    identifier: 'identifier',
    token: 'token',
    expires: 'expires'
  };

  export type VerificationTokenScalarFieldEnum = (typeof VerificationTokenScalarFieldEnum)[keyof typeof VerificationTokenScalarFieldEnum]


  export const EquipmentScalarFieldEnum: {
    id: 'id',
    name: 'name',
    category: 'category',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type EquipmentScalarFieldEnum = (typeof EquipmentScalarFieldEnum)[keyof typeof EquipmentScalarFieldEnum]


  export const ExerciseScalarFieldEnum: {
    id: 'id',
    name: 'name',
    description: 'description',
    youtubeUrl: 'youtubeUrl',
    musclesWorked: 'musclesWorked',
    muscleGroup: 'muscleGroup',
    equipmentId: 'equipmentId',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type ExerciseScalarFieldEnum = (typeof ExerciseScalarFieldEnum)[keyof typeof ExerciseScalarFieldEnum]


  export const WorkoutPlanScalarFieldEnum: {
    id: 'id',
    name: 'name',
    description: 'description',
    muscleGroup: 'muscleGroup',
    durationWeeks: 'durationWeeks',
    sessionsPerWeek: 'sessionsPerWeek',
    tier: 'tier',
    equipmentId: 'equipmentId',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type WorkoutPlanScalarFieldEnum = (typeof WorkoutPlanScalarFieldEnum)[keyof typeof WorkoutPlanScalarFieldEnum]


  export const PlannedSessionScalarFieldEnum: {
    id: 'id',
    sessionNumber: 'sessionNumber',
    focus: 'focus',
    planId: 'planId'
  };

  export type PlannedSessionScalarFieldEnum = (typeof PlannedSessionScalarFieldEnum)[keyof typeof PlannedSessionScalarFieldEnum]


  export const PlannedExerciseScalarFieldEnum: {
    id: 'id',
    order: 'order',
    sessionId: 'sessionId',
    exerciseId: 'exerciseId',
    beginnerSets: 'beginnerSets',
    beginnerReps: 'beginnerReps',
    intermediateSets: 'intermediateSets',
    intermediateReps: 'intermediateReps',
    advancedSets: 'advancedSets',
    advancedReps: 'advancedReps',
    restSeconds: 'restSeconds'
  };

  export type PlannedExerciseScalarFieldEnum = (typeof PlannedExerciseScalarFieldEnum)[keyof typeof PlannedExerciseScalarFieldEnum]


  export const PlanInstanceScalarFieldEnum: {
    id: 'id',
    level: 'level',
    status: 'status',
    currentSession: 'currentSession',
    startedAt: 'startedAt',
    completedAt: 'completedAt',
    sessionDraft: 'sessionDraft',
    userId: 'userId',
    planId: 'planId',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type PlanInstanceScalarFieldEnum = (typeof PlanInstanceScalarFieldEnum)[keyof typeof PlanInstanceScalarFieldEnum]


  export const WorkoutLogScalarFieldEnum: {
    id: 'id',
    sessionNumber: 'sessionNumber',
    completedAt: 'completedAt',
    weightKg: 'weightKg',
    actualReps: 'actualReps',
    actualSets: 'actualSets',
    userId: 'userId',
    instanceId: 'instanceId',
    plannedExerciseId: 'plannedExerciseId',
    createdAt: 'createdAt'
  };

  export type WorkoutLogScalarFieldEnum = (typeof WorkoutLogScalarFieldEnum)[keyof typeof WorkoutLogScalarFieldEnum]


  export const SubscriptionScalarFieldEnum: {
    id: 'id',
    plan: 'plan',
    status: 'status',
    source: 'source',
    startedAt: 'startedAt',
    expiresAt: 'expiresAt',
    userId: 'userId'
  };

  export type SubscriptionScalarFieldEnum = (typeof SubscriptionScalarFieldEnum)[keyof typeof SubscriptionScalarFieldEnum]


  export const UserEquipmentScalarFieldEnum: {
    id: 'id',
    source: 'source',
    addedAt: 'addedAt',
    trialExpiresAt: 'trialExpiresAt',
    userId: 'userId',
    equipmentId: 'equipmentId'
  };

  export type UserEquipmentScalarFieldEnum = (typeof UserEquipmentScalarFieldEnum)[keyof typeof UserEquipmentScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'Role[]'
   */
  export type ListEnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'PrimaryGoal'
   */
  export type EnumPrimaryGoalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PrimaryGoal'>
    


  /**
   * Reference to a field of type 'PrimaryGoal[]'
   */
  export type ListEnumPrimaryGoalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PrimaryGoal[]'>
    


  /**
   * Reference to a field of type 'TrainingLocation'
   */
  export type EnumTrainingLocationFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'TrainingLocation'>
    


  /**
   * Reference to a field of type 'TrainingLocation[]'
   */
  export type ListEnumTrainingLocationFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'TrainingLocation[]'>
    


  /**
   * Reference to a field of type 'BiologicalSex'
   */
  export type EnumBiologicalSexFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BiologicalSex'>
    


  /**
   * Reference to a field of type 'BiologicalSex[]'
   */
  export type ListEnumBiologicalSexFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BiologicalSex[]'>
    


  /**
   * Reference to a field of type 'UserLevel'
   */
  export type EnumUserLevelFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'UserLevel'>
    


  /**
   * Reference to a field of type 'UserLevel[]'
   */
  export type ListEnumUserLevelFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'UserLevel[]'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'MuscleGroup'
   */
  export type EnumMuscleGroupFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MuscleGroup'>
    


  /**
   * Reference to a field of type 'MuscleGroup[]'
   */
  export type ListEnumMuscleGroupFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MuscleGroup[]'>
    


  /**
   * Reference to a field of type 'PlanTier'
   */
  export type EnumPlanTierFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PlanTier'>
    


  /**
   * Reference to a field of type 'PlanTier[]'
   */
  export type ListEnumPlanTierFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PlanTier[]'>
    


  /**
   * Reference to a field of type 'InstanceStatus'
   */
  export type EnumInstanceStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'InstanceStatus'>
    


  /**
   * Reference to a field of type 'InstanceStatus[]'
   */
  export type ListEnumInstanceStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'InstanceStatus[]'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    


  /**
   * Reference to a field of type 'Plan'
   */
  export type EnumPlanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Plan'>
    


  /**
   * Reference to a field of type 'Plan[]'
   */
  export type ListEnumPlanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Plan[]'>
    


  /**
   * Reference to a field of type 'EquipmentSource'
   */
  export type EnumEquipmentSourceFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'EquipmentSource'>
    


  /**
   * Reference to a field of type 'EquipmentSource[]'
   */
  export type ListEnumEquipmentSourceFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'EquipmentSource[]'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    name?: StringNullableFilter<"User"> | string | null
    password?: StringNullableFilter<"User"> | string | null
    emailVerified?: DateTimeNullableFilter<"User"> | Date | string | null
    image?: StringNullableFilter<"User"> | string | null
    role?: EnumRoleFilter<"User"> | $Enums.Role
    lastLoginAt?: DateTimeNullableFilter<"User"> | Date | string | null
    onboardingComplete?: BoolFilter<"User"> | boolean
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    isNewUser?: BoolFilter<"User"> | boolean
    primaryGoal?: EnumPrimaryGoalNullableFilter<"User"> | $Enums.PrimaryGoal | null
    trainingLocation?: EnumTrainingLocationNullableFilter<"User"> | $Enums.TrainingLocation | null
    biologicalSex?: EnumBiologicalSexNullableFilter<"User"> | $Enums.BiologicalSex | null
    experienceLevel?: EnumUserLevelNullableFilter<"User"> | $Enums.UserLevel | null
    onboardingCompletedAt?: DateTimeNullableFilter<"User"> | Date | string | null
    accounts?: AccountListRelationFilter
    sessions?: NextAuthSessionListRelationFilter
    subscription?: XOR<SubscriptionNullableScalarRelationFilter, SubscriptionWhereInput> | null
    userEquipment?: UserEquipmentListRelationFilter
    instances?: PlanInstanceListRelationFilter
    workoutLogs?: WorkoutLogListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    emailVerified?: SortOrderInput | SortOrder
    image?: SortOrderInput | SortOrder
    role?: SortOrder
    lastLoginAt?: SortOrderInput | SortOrder
    onboardingComplete?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isNewUser?: SortOrder
    primaryGoal?: SortOrderInput | SortOrder
    trainingLocation?: SortOrderInput | SortOrder
    biologicalSex?: SortOrderInput | SortOrder
    experienceLevel?: SortOrderInput | SortOrder
    onboardingCompletedAt?: SortOrderInput | SortOrder
    accounts?: AccountOrderByRelationAggregateInput
    sessions?: NextAuthSessionOrderByRelationAggregateInput
    subscription?: SubscriptionOrderByWithRelationInput
    userEquipment?: UserEquipmentOrderByRelationAggregateInput
    instances?: PlanInstanceOrderByRelationAggregateInput
    workoutLogs?: WorkoutLogOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    name?: StringNullableFilter<"User"> | string | null
    password?: StringNullableFilter<"User"> | string | null
    emailVerified?: DateTimeNullableFilter<"User"> | Date | string | null
    image?: StringNullableFilter<"User"> | string | null
    role?: EnumRoleFilter<"User"> | $Enums.Role
    lastLoginAt?: DateTimeNullableFilter<"User"> | Date | string | null
    onboardingComplete?: BoolFilter<"User"> | boolean
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    isNewUser?: BoolFilter<"User"> | boolean
    primaryGoal?: EnumPrimaryGoalNullableFilter<"User"> | $Enums.PrimaryGoal | null
    trainingLocation?: EnumTrainingLocationNullableFilter<"User"> | $Enums.TrainingLocation | null
    biologicalSex?: EnumBiologicalSexNullableFilter<"User"> | $Enums.BiologicalSex | null
    experienceLevel?: EnumUserLevelNullableFilter<"User"> | $Enums.UserLevel | null
    onboardingCompletedAt?: DateTimeNullableFilter<"User"> | Date | string | null
    accounts?: AccountListRelationFilter
    sessions?: NextAuthSessionListRelationFilter
    subscription?: XOR<SubscriptionNullableScalarRelationFilter, SubscriptionWhereInput> | null
    userEquipment?: UserEquipmentListRelationFilter
    instances?: PlanInstanceListRelationFilter
    workoutLogs?: WorkoutLogListRelationFilter
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrderInput | SortOrder
    password?: SortOrderInput | SortOrder
    emailVerified?: SortOrderInput | SortOrder
    image?: SortOrderInput | SortOrder
    role?: SortOrder
    lastLoginAt?: SortOrderInput | SortOrder
    onboardingComplete?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isNewUser?: SortOrder
    primaryGoal?: SortOrderInput | SortOrder
    trainingLocation?: SortOrderInput | SortOrder
    biologicalSex?: SortOrderInput | SortOrder
    experienceLevel?: SortOrderInput | SortOrder
    onboardingCompletedAt?: SortOrderInput | SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    name?: StringNullableWithAggregatesFilter<"User"> | string | null
    password?: StringNullableWithAggregatesFilter<"User"> | string | null
    emailVerified?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
    image?: StringNullableWithAggregatesFilter<"User"> | string | null
    role?: EnumRoleWithAggregatesFilter<"User"> | $Enums.Role
    lastLoginAt?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
    onboardingComplete?: BoolWithAggregatesFilter<"User"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    isNewUser?: BoolWithAggregatesFilter<"User"> | boolean
    primaryGoal?: EnumPrimaryGoalNullableWithAggregatesFilter<"User"> | $Enums.PrimaryGoal | null
    trainingLocation?: EnumTrainingLocationNullableWithAggregatesFilter<"User"> | $Enums.TrainingLocation | null
    biologicalSex?: EnumBiologicalSexNullableWithAggregatesFilter<"User"> | $Enums.BiologicalSex | null
    experienceLevel?: EnumUserLevelNullableWithAggregatesFilter<"User"> | $Enums.UserLevel | null
    onboardingCompletedAt?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
  }

  export type AccountWhereInput = {
    AND?: AccountWhereInput | AccountWhereInput[]
    OR?: AccountWhereInput[]
    NOT?: AccountWhereInput | AccountWhereInput[]
    id?: StringFilter<"Account"> | string
    userId?: StringFilter<"Account"> | string
    type?: StringFilter<"Account"> | string
    provider?: StringFilter<"Account"> | string
    providerAccountId?: StringFilter<"Account"> | string
    refresh_token?: StringNullableFilter<"Account"> | string | null
    access_token?: StringNullableFilter<"Account"> | string | null
    expires_at?: IntNullableFilter<"Account"> | number | null
    token_type?: StringNullableFilter<"Account"> | string | null
    scope?: StringNullableFilter<"Account"> | string | null
    id_token?: StringNullableFilter<"Account"> | string | null
    session_state?: StringNullableFilter<"Account"> | string | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type AccountOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    provider?: SortOrder
    providerAccountId?: SortOrder
    refresh_token?: SortOrderInput | SortOrder
    access_token?: SortOrderInput | SortOrder
    expires_at?: SortOrderInput | SortOrder
    token_type?: SortOrderInput | SortOrder
    scope?: SortOrderInput | SortOrder
    id_token?: SortOrderInput | SortOrder
    session_state?: SortOrderInput | SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type AccountWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    provider_providerAccountId?: AccountProviderProviderAccountIdCompoundUniqueInput
    AND?: AccountWhereInput | AccountWhereInput[]
    OR?: AccountWhereInput[]
    NOT?: AccountWhereInput | AccountWhereInput[]
    userId?: StringFilter<"Account"> | string
    type?: StringFilter<"Account"> | string
    provider?: StringFilter<"Account"> | string
    providerAccountId?: StringFilter<"Account"> | string
    refresh_token?: StringNullableFilter<"Account"> | string | null
    access_token?: StringNullableFilter<"Account"> | string | null
    expires_at?: IntNullableFilter<"Account"> | number | null
    token_type?: StringNullableFilter<"Account"> | string | null
    scope?: StringNullableFilter<"Account"> | string | null
    id_token?: StringNullableFilter<"Account"> | string | null
    session_state?: StringNullableFilter<"Account"> | string | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "provider_providerAccountId">

  export type AccountOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    provider?: SortOrder
    providerAccountId?: SortOrder
    refresh_token?: SortOrderInput | SortOrder
    access_token?: SortOrderInput | SortOrder
    expires_at?: SortOrderInput | SortOrder
    token_type?: SortOrderInput | SortOrder
    scope?: SortOrderInput | SortOrder
    id_token?: SortOrderInput | SortOrder
    session_state?: SortOrderInput | SortOrder
    _count?: AccountCountOrderByAggregateInput
    _avg?: AccountAvgOrderByAggregateInput
    _max?: AccountMaxOrderByAggregateInput
    _min?: AccountMinOrderByAggregateInput
    _sum?: AccountSumOrderByAggregateInput
  }

  export type AccountScalarWhereWithAggregatesInput = {
    AND?: AccountScalarWhereWithAggregatesInput | AccountScalarWhereWithAggregatesInput[]
    OR?: AccountScalarWhereWithAggregatesInput[]
    NOT?: AccountScalarWhereWithAggregatesInput | AccountScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Account"> | string
    userId?: StringWithAggregatesFilter<"Account"> | string
    type?: StringWithAggregatesFilter<"Account"> | string
    provider?: StringWithAggregatesFilter<"Account"> | string
    providerAccountId?: StringWithAggregatesFilter<"Account"> | string
    refresh_token?: StringNullableWithAggregatesFilter<"Account"> | string | null
    access_token?: StringNullableWithAggregatesFilter<"Account"> | string | null
    expires_at?: IntNullableWithAggregatesFilter<"Account"> | number | null
    token_type?: StringNullableWithAggregatesFilter<"Account"> | string | null
    scope?: StringNullableWithAggregatesFilter<"Account"> | string | null
    id_token?: StringNullableWithAggregatesFilter<"Account"> | string | null
    session_state?: StringNullableWithAggregatesFilter<"Account"> | string | null
  }

  export type NextAuthSessionWhereInput = {
    AND?: NextAuthSessionWhereInput | NextAuthSessionWhereInput[]
    OR?: NextAuthSessionWhereInput[]
    NOT?: NextAuthSessionWhereInput | NextAuthSessionWhereInput[]
    id?: StringFilter<"NextAuthSession"> | string
    sessionToken?: StringFilter<"NextAuthSession"> | string
    userId?: StringFilter<"NextAuthSession"> | string
    expires?: DateTimeFilter<"NextAuthSession"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type NextAuthSessionOrderByWithRelationInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type NextAuthSessionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    sessionToken?: string
    AND?: NextAuthSessionWhereInput | NextAuthSessionWhereInput[]
    OR?: NextAuthSessionWhereInput[]
    NOT?: NextAuthSessionWhereInput | NextAuthSessionWhereInput[]
    userId?: StringFilter<"NextAuthSession"> | string
    expires?: DateTimeFilter<"NextAuthSession"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "sessionToken">

  export type NextAuthSessionOrderByWithAggregationInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
    _count?: NextAuthSessionCountOrderByAggregateInput
    _max?: NextAuthSessionMaxOrderByAggregateInput
    _min?: NextAuthSessionMinOrderByAggregateInput
  }

  export type NextAuthSessionScalarWhereWithAggregatesInput = {
    AND?: NextAuthSessionScalarWhereWithAggregatesInput | NextAuthSessionScalarWhereWithAggregatesInput[]
    OR?: NextAuthSessionScalarWhereWithAggregatesInput[]
    NOT?: NextAuthSessionScalarWhereWithAggregatesInput | NextAuthSessionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"NextAuthSession"> | string
    sessionToken?: StringWithAggregatesFilter<"NextAuthSession"> | string
    userId?: StringWithAggregatesFilter<"NextAuthSession"> | string
    expires?: DateTimeWithAggregatesFilter<"NextAuthSession"> | Date | string
  }

  export type VerificationTokenWhereInput = {
    AND?: VerificationTokenWhereInput | VerificationTokenWhereInput[]
    OR?: VerificationTokenWhereInput[]
    NOT?: VerificationTokenWhereInput | VerificationTokenWhereInput[]
    identifier?: StringFilter<"VerificationToken"> | string
    token?: StringFilter<"VerificationToken"> | string
    expires?: DateTimeFilter<"VerificationToken"> | Date | string
  }

  export type VerificationTokenOrderByWithRelationInput = {
    identifier?: SortOrder
    token?: SortOrder
    expires?: SortOrder
  }

  export type VerificationTokenWhereUniqueInput = Prisma.AtLeast<{
    token?: string
    identifier_token?: VerificationTokenIdentifierTokenCompoundUniqueInput
    AND?: VerificationTokenWhereInput | VerificationTokenWhereInput[]
    OR?: VerificationTokenWhereInput[]
    NOT?: VerificationTokenWhereInput | VerificationTokenWhereInput[]
    identifier?: StringFilter<"VerificationToken"> | string
    expires?: DateTimeFilter<"VerificationToken"> | Date | string
  }, "token" | "identifier_token">

  export type VerificationTokenOrderByWithAggregationInput = {
    identifier?: SortOrder
    token?: SortOrder
    expires?: SortOrder
    _count?: VerificationTokenCountOrderByAggregateInput
    _max?: VerificationTokenMaxOrderByAggregateInput
    _min?: VerificationTokenMinOrderByAggregateInput
  }

  export type VerificationTokenScalarWhereWithAggregatesInput = {
    AND?: VerificationTokenScalarWhereWithAggregatesInput | VerificationTokenScalarWhereWithAggregatesInput[]
    OR?: VerificationTokenScalarWhereWithAggregatesInput[]
    NOT?: VerificationTokenScalarWhereWithAggregatesInput | VerificationTokenScalarWhereWithAggregatesInput[]
    identifier?: StringWithAggregatesFilter<"VerificationToken"> | string
    token?: StringWithAggregatesFilter<"VerificationToken"> | string
    expires?: DateTimeWithAggregatesFilter<"VerificationToken"> | Date | string
  }

  export type EquipmentWhereInput = {
    AND?: EquipmentWhereInput | EquipmentWhereInput[]
    OR?: EquipmentWhereInput[]
    NOT?: EquipmentWhereInput | EquipmentWhereInput[]
    id?: StringFilter<"Equipment"> | string
    name?: StringFilter<"Equipment"> | string
    category?: StringFilter<"Equipment"> | string
    createdAt?: DateTimeFilter<"Equipment"> | Date | string
    updatedAt?: DateTimeFilter<"Equipment"> | Date | string
    userEquipment?: UserEquipmentListRelationFilter
    exercises?: ExerciseListRelationFilter
    workoutPlans?: WorkoutPlanListRelationFilter
  }

  export type EquipmentOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    userEquipment?: UserEquipmentOrderByRelationAggregateInput
    exercises?: ExerciseOrderByRelationAggregateInput
    workoutPlans?: WorkoutPlanOrderByRelationAggregateInput
  }

  export type EquipmentWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    name?: string
    AND?: EquipmentWhereInput | EquipmentWhereInput[]
    OR?: EquipmentWhereInput[]
    NOT?: EquipmentWhereInput | EquipmentWhereInput[]
    category?: StringFilter<"Equipment"> | string
    createdAt?: DateTimeFilter<"Equipment"> | Date | string
    updatedAt?: DateTimeFilter<"Equipment"> | Date | string
    userEquipment?: UserEquipmentListRelationFilter
    exercises?: ExerciseListRelationFilter
    workoutPlans?: WorkoutPlanListRelationFilter
  }, "id" | "name">

  export type EquipmentOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: EquipmentCountOrderByAggregateInput
    _max?: EquipmentMaxOrderByAggregateInput
    _min?: EquipmentMinOrderByAggregateInput
  }

  export type EquipmentScalarWhereWithAggregatesInput = {
    AND?: EquipmentScalarWhereWithAggregatesInput | EquipmentScalarWhereWithAggregatesInput[]
    OR?: EquipmentScalarWhereWithAggregatesInput[]
    NOT?: EquipmentScalarWhereWithAggregatesInput | EquipmentScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Equipment"> | string
    name?: StringWithAggregatesFilter<"Equipment"> | string
    category?: StringWithAggregatesFilter<"Equipment"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Equipment"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Equipment"> | Date | string
  }

  export type ExerciseWhereInput = {
    AND?: ExerciseWhereInput | ExerciseWhereInput[]
    OR?: ExerciseWhereInput[]
    NOT?: ExerciseWhereInput | ExerciseWhereInput[]
    id?: StringFilter<"Exercise"> | string
    name?: StringFilter<"Exercise"> | string
    description?: StringNullableFilter<"Exercise"> | string | null
    youtubeUrl?: StringNullableFilter<"Exercise"> | string | null
    musclesWorked?: StringNullableListFilter<"Exercise">
    muscleGroup?: EnumMuscleGroupFilter<"Exercise"> | $Enums.MuscleGroup
    equipmentId?: StringNullableFilter<"Exercise"> | string | null
    createdAt?: DateTimeFilter<"Exercise"> | Date | string
    updatedAt?: DateTimeFilter<"Exercise"> | Date | string
    equipment?: XOR<EquipmentNullableScalarRelationFilter, EquipmentWhereInput> | null
    plannedExercises?: PlannedExerciseListRelationFilter
  }

  export type ExerciseOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    youtubeUrl?: SortOrderInput | SortOrder
    musclesWorked?: SortOrder
    muscleGroup?: SortOrder
    equipmentId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    equipment?: EquipmentOrderByWithRelationInput
    plannedExercises?: PlannedExerciseOrderByRelationAggregateInput
  }

  export type ExerciseWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    name?: string
    AND?: ExerciseWhereInput | ExerciseWhereInput[]
    OR?: ExerciseWhereInput[]
    NOT?: ExerciseWhereInput | ExerciseWhereInput[]
    description?: StringNullableFilter<"Exercise"> | string | null
    youtubeUrl?: StringNullableFilter<"Exercise"> | string | null
    musclesWorked?: StringNullableListFilter<"Exercise">
    muscleGroup?: EnumMuscleGroupFilter<"Exercise"> | $Enums.MuscleGroup
    equipmentId?: StringNullableFilter<"Exercise"> | string | null
    createdAt?: DateTimeFilter<"Exercise"> | Date | string
    updatedAt?: DateTimeFilter<"Exercise"> | Date | string
    equipment?: XOR<EquipmentNullableScalarRelationFilter, EquipmentWhereInput> | null
    plannedExercises?: PlannedExerciseListRelationFilter
  }, "id" | "name">

  export type ExerciseOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    youtubeUrl?: SortOrderInput | SortOrder
    musclesWorked?: SortOrder
    muscleGroup?: SortOrder
    equipmentId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: ExerciseCountOrderByAggregateInput
    _max?: ExerciseMaxOrderByAggregateInput
    _min?: ExerciseMinOrderByAggregateInput
  }

  export type ExerciseScalarWhereWithAggregatesInput = {
    AND?: ExerciseScalarWhereWithAggregatesInput | ExerciseScalarWhereWithAggregatesInput[]
    OR?: ExerciseScalarWhereWithAggregatesInput[]
    NOT?: ExerciseScalarWhereWithAggregatesInput | ExerciseScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Exercise"> | string
    name?: StringWithAggregatesFilter<"Exercise"> | string
    description?: StringNullableWithAggregatesFilter<"Exercise"> | string | null
    youtubeUrl?: StringNullableWithAggregatesFilter<"Exercise"> | string | null
    musclesWorked?: StringNullableListFilter<"Exercise">
    muscleGroup?: EnumMuscleGroupWithAggregatesFilter<"Exercise"> | $Enums.MuscleGroup
    equipmentId?: StringNullableWithAggregatesFilter<"Exercise"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Exercise"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Exercise"> | Date | string
  }

  export type WorkoutPlanWhereInput = {
    AND?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    OR?: WorkoutPlanWhereInput[]
    NOT?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    id?: StringFilter<"WorkoutPlan"> | string
    name?: StringFilter<"WorkoutPlan"> | string
    description?: StringFilter<"WorkoutPlan"> | string
    muscleGroup?: EnumMuscleGroupFilter<"WorkoutPlan"> | $Enums.MuscleGroup
    durationWeeks?: IntFilter<"WorkoutPlan"> | number
    sessionsPerWeek?: IntFilter<"WorkoutPlan"> | number
    tier?: EnumPlanTierFilter<"WorkoutPlan"> | $Enums.PlanTier
    equipmentId?: StringNullableFilter<"WorkoutPlan"> | string | null
    createdAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    equipment?: XOR<EquipmentNullableScalarRelationFilter, EquipmentWhereInput> | null
    plannedSessions?: PlannedSessionListRelationFilter
    instances?: PlanInstanceListRelationFilter
  }

  export type WorkoutPlanOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    muscleGroup?: SortOrder
    durationWeeks?: SortOrder
    sessionsPerWeek?: SortOrder
    tier?: SortOrder
    equipmentId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    equipment?: EquipmentOrderByWithRelationInput
    plannedSessions?: PlannedSessionOrderByRelationAggregateInput
    instances?: PlanInstanceOrderByRelationAggregateInput
  }

  export type WorkoutPlanWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    name?: string
    AND?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    OR?: WorkoutPlanWhereInput[]
    NOT?: WorkoutPlanWhereInput | WorkoutPlanWhereInput[]
    description?: StringFilter<"WorkoutPlan"> | string
    muscleGroup?: EnumMuscleGroupFilter<"WorkoutPlan"> | $Enums.MuscleGroup
    durationWeeks?: IntFilter<"WorkoutPlan"> | number
    sessionsPerWeek?: IntFilter<"WorkoutPlan"> | number
    tier?: EnumPlanTierFilter<"WorkoutPlan"> | $Enums.PlanTier
    equipmentId?: StringNullableFilter<"WorkoutPlan"> | string | null
    createdAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    equipment?: XOR<EquipmentNullableScalarRelationFilter, EquipmentWhereInput> | null
    plannedSessions?: PlannedSessionListRelationFilter
    instances?: PlanInstanceListRelationFilter
  }, "id" | "name">

  export type WorkoutPlanOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    muscleGroup?: SortOrder
    durationWeeks?: SortOrder
    sessionsPerWeek?: SortOrder
    tier?: SortOrder
    equipmentId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: WorkoutPlanCountOrderByAggregateInput
    _avg?: WorkoutPlanAvgOrderByAggregateInput
    _max?: WorkoutPlanMaxOrderByAggregateInput
    _min?: WorkoutPlanMinOrderByAggregateInput
    _sum?: WorkoutPlanSumOrderByAggregateInput
  }

  export type WorkoutPlanScalarWhereWithAggregatesInput = {
    AND?: WorkoutPlanScalarWhereWithAggregatesInput | WorkoutPlanScalarWhereWithAggregatesInput[]
    OR?: WorkoutPlanScalarWhereWithAggregatesInput[]
    NOT?: WorkoutPlanScalarWhereWithAggregatesInput | WorkoutPlanScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"WorkoutPlan"> | string
    name?: StringWithAggregatesFilter<"WorkoutPlan"> | string
    description?: StringWithAggregatesFilter<"WorkoutPlan"> | string
    muscleGroup?: EnumMuscleGroupWithAggregatesFilter<"WorkoutPlan"> | $Enums.MuscleGroup
    durationWeeks?: IntWithAggregatesFilter<"WorkoutPlan"> | number
    sessionsPerWeek?: IntWithAggregatesFilter<"WorkoutPlan"> | number
    tier?: EnumPlanTierWithAggregatesFilter<"WorkoutPlan"> | $Enums.PlanTier
    equipmentId?: StringNullableWithAggregatesFilter<"WorkoutPlan"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"WorkoutPlan"> | Date | string
  }

  export type PlannedSessionWhereInput = {
    AND?: PlannedSessionWhereInput | PlannedSessionWhereInput[]
    OR?: PlannedSessionWhereInput[]
    NOT?: PlannedSessionWhereInput | PlannedSessionWhereInput[]
    id?: StringFilter<"PlannedSession"> | string
    sessionNumber?: IntFilter<"PlannedSession"> | number
    focus?: StringFilter<"PlannedSession"> | string
    planId?: StringFilter<"PlannedSession"> | string
    plan?: XOR<WorkoutPlanScalarRelationFilter, WorkoutPlanWhereInput>
    plannedExercises?: PlannedExerciseListRelationFilter
  }

  export type PlannedSessionOrderByWithRelationInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    focus?: SortOrder
    planId?: SortOrder
    plan?: WorkoutPlanOrderByWithRelationInput
    plannedExercises?: PlannedExerciseOrderByRelationAggregateInput
  }

  export type PlannedSessionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    planId_sessionNumber?: PlannedSessionPlanIdSessionNumberCompoundUniqueInput
    AND?: PlannedSessionWhereInput | PlannedSessionWhereInput[]
    OR?: PlannedSessionWhereInput[]
    NOT?: PlannedSessionWhereInput | PlannedSessionWhereInput[]
    sessionNumber?: IntFilter<"PlannedSession"> | number
    focus?: StringFilter<"PlannedSession"> | string
    planId?: StringFilter<"PlannedSession"> | string
    plan?: XOR<WorkoutPlanScalarRelationFilter, WorkoutPlanWhereInput>
    plannedExercises?: PlannedExerciseListRelationFilter
  }, "id" | "planId_sessionNumber">

  export type PlannedSessionOrderByWithAggregationInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    focus?: SortOrder
    planId?: SortOrder
    _count?: PlannedSessionCountOrderByAggregateInput
    _avg?: PlannedSessionAvgOrderByAggregateInput
    _max?: PlannedSessionMaxOrderByAggregateInput
    _min?: PlannedSessionMinOrderByAggregateInput
    _sum?: PlannedSessionSumOrderByAggregateInput
  }

  export type PlannedSessionScalarWhereWithAggregatesInput = {
    AND?: PlannedSessionScalarWhereWithAggregatesInput | PlannedSessionScalarWhereWithAggregatesInput[]
    OR?: PlannedSessionScalarWhereWithAggregatesInput[]
    NOT?: PlannedSessionScalarWhereWithAggregatesInput | PlannedSessionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"PlannedSession"> | string
    sessionNumber?: IntWithAggregatesFilter<"PlannedSession"> | number
    focus?: StringWithAggregatesFilter<"PlannedSession"> | string
    planId?: StringWithAggregatesFilter<"PlannedSession"> | string
  }

  export type PlannedExerciseWhereInput = {
    AND?: PlannedExerciseWhereInput | PlannedExerciseWhereInput[]
    OR?: PlannedExerciseWhereInput[]
    NOT?: PlannedExerciseWhereInput | PlannedExerciseWhereInput[]
    id?: StringFilter<"PlannedExercise"> | string
    order?: IntFilter<"PlannedExercise"> | number
    sessionId?: StringFilter<"PlannedExercise"> | string
    exerciseId?: StringFilter<"PlannedExercise"> | string
    beginnerSets?: IntFilter<"PlannedExercise"> | number
    beginnerReps?: IntFilter<"PlannedExercise"> | number
    intermediateSets?: IntFilter<"PlannedExercise"> | number
    intermediateReps?: IntFilter<"PlannedExercise"> | number
    advancedSets?: IntFilter<"PlannedExercise"> | number
    advancedReps?: IntFilter<"PlannedExercise"> | number
    restSeconds?: IntFilter<"PlannedExercise"> | number
    session?: XOR<PlannedSessionScalarRelationFilter, PlannedSessionWhereInput>
    exercise?: XOR<ExerciseScalarRelationFilter, ExerciseWhereInput>
    loggedSets?: WorkoutLogListRelationFilter
  }

  export type PlannedExerciseOrderByWithRelationInput = {
    id?: SortOrder
    order?: SortOrder
    sessionId?: SortOrder
    exerciseId?: SortOrder
    beginnerSets?: SortOrder
    beginnerReps?: SortOrder
    intermediateSets?: SortOrder
    intermediateReps?: SortOrder
    advancedSets?: SortOrder
    advancedReps?: SortOrder
    restSeconds?: SortOrder
    session?: PlannedSessionOrderByWithRelationInput
    exercise?: ExerciseOrderByWithRelationInput
    loggedSets?: WorkoutLogOrderByRelationAggregateInput
  }

  export type PlannedExerciseWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    sessionId_order?: PlannedExerciseSessionIdOrderCompoundUniqueInput
    AND?: PlannedExerciseWhereInput | PlannedExerciseWhereInput[]
    OR?: PlannedExerciseWhereInput[]
    NOT?: PlannedExerciseWhereInput | PlannedExerciseWhereInput[]
    order?: IntFilter<"PlannedExercise"> | number
    sessionId?: StringFilter<"PlannedExercise"> | string
    exerciseId?: StringFilter<"PlannedExercise"> | string
    beginnerSets?: IntFilter<"PlannedExercise"> | number
    beginnerReps?: IntFilter<"PlannedExercise"> | number
    intermediateSets?: IntFilter<"PlannedExercise"> | number
    intermediateReps?: IntFilter<"PlannedExercise"> | number
    advancedSets?: IntFilter<"PlannedExercise"> | number
    advancedReps?: IntFilter<"PlannedExercise"> | number
    restSeconds?: IntFilter<"PlannedExercise"> | number
    session?: XOR<PlannedSessionScalarRelationFilter, PlannedSessionWhereInput>
    exercise?: XOR<ExerciseScalarRelationFilter, ExerciseWhereInput>
    loggedSets?: WorkoutLogListRelationFilter
  }, "id" | "sessionId_order">

  export type PlannedExerciseOrderByWithAggregationInput = {
    id?: SortOrder
    order?: SortOrder
    sessionId?: SortOrder
    exerciseId?: SortOrder
    beginnerSets?: SortOrder
    beginnerReps?: SortOrder
    intermediateSets?: SortOrder
    intermediateReps?: SortOrder
    advancedSets?: SortOrder
    advancedReps?: SortOrder
    restSeconds?: SortOrder
    _count?: PlannedExerciseCountOrderByAggregateInput
    _avg?: PlannedExerciseAvgOrderByAggregateInput
    _max?: PlannedExerciseMaxOrderByAggregateInput
    _min?: PlannedExerciseMinOrderByAggregateInput
    _sum?: PlannedExerciseSumOrderByAggregateInput
  }

  export type PlannedExerciseScalarWhereWithAggregatesInput = {
    AND?: PlannedExerciseScalarWhereWithAggregatesInput | PlannedExerciseScalarWhereWithAggregatesInput[]
    OR?: PlannedExerciseScalarWhereWithAggregatesInput[]
    NOT?: PlannedExerciseScalarWhereWithAggregatesInput | PlannedExerciseScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"PlannedExercise"> | string
    order?: IntWithAggregatesFilter<"PlannedExercise"> | number
    sessionId?: StringWithAggregatesFilter<"PlannedExercise"> | string
    exerciseId?: StringWithAggregatesFilter<"PlannedExercise"> | string
    beginnerSets?: IntWithAggregatesFilter<"PlannedExercise"> | number
    beginnerReps?: IntWithAggregatesFilter<"PlannedExercise"> | number
    intermediateSets?: IntWithAggregatesFilter<"PlannedExercise"> | number
    intermediateReps?: IntWithAggregatesFilter<"PlannedExercise"> | number
    advancedSets?: IntWithAggregatesFilter<"PlannedExercise"> | number
    advancedReps?: IntWithAggregatesFilter<"PlannedExercise"> | number
    restSeconds?: IntWithAggregatesFilter<"PlannedExercise"> | number
  }

  export type PlanInstanceWhereInput = {
    AND?: PlanInstanceWhereInput | PlanInstanceWhereInput[]
    OR?: PlanInstanceWhereInput[]
    NOT?: PlanInstanceWhereInput | PlanInstanceWhereInput[]
    id?: StringFilter<"PlanInstance"> | string
    level?: EnumUserLevelFilter<"PlanInstance"> | $Enums.UserLevel
    status?: EnumInstanceStatusFilter<"PlanInstance"> | $Enums.InstanceStatus
    currentSession?: IntFilter<"PlanInstance"> | number
    startedAt?: DateTimeFilter<"PlanInstance"> | Date | string
    completedAt?: DateTimeNullableFilter<"PlanInstance"> | Date | string | null
    sessionDraft?: JsonNullableFilter<"PlanInstance">
    userId?: StringFilter<"PlanInstance"> | string
    planId?: StringFilter<"PlanInstance"> | string
    createdAt?: DateTimeFilter<"PlanInstance"> | Date | string
    updatedAt?: DateTimeFilter<"PlanInstance"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    plan?: XOR<WorkoutPlanScalarRelationFilter, WorkoutPlanWhereInput>
    workoutLogs?: WorkoutLogListRelationFilter
  }

  export type PlanInstanceOrderByWithRelationInput = {
    id?: SortOrder
    level?: SortOrder
    status?: SortOrder
    currentSession?: SortOrder
    startedAt?: SortOrder
    completedAt?: SortOrderInput | SortOrder
    sessionDraft?: SortOrderInput | SortOrder
    userId?: SortOrder
    planId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    plan?: WorkoutPlanOrderByWithRelationInput
    workoutLogs?: WorkoutLogOrderByRelationAggregateInput
  }

  export type PlanInstanceWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: PlanInstanceWhereInput | PlanInstanceWhereInput[]
    OR?: PlanInstanceWhereInput[]
    NOT?: PlanInstanceWhereInput | PlanInstanceWhereInput[]
    level?: EnumUserLevelFilter<"PlanInstance"> | $Enums.UserLevel
    status?: EnumInstanceStatusFilter<"PlanInstance"> | $Enums.InstanceStatus
    currentSession?: IntFilter<"PlanInstance"> | number
    startedAt?: DateTimeFilter<"PlanInstance"> | Date | string
    completedAt?: DateTimeNullableFilter<"PlanInstance"> | Date | string | null
    sessionDraft?: JsonNullableFilter<"PlanInstance">
    userId?: StringFilter<"PlanInstance"> | string
    planId?: StringFilter<"PlanInstance"> | string
    createdAt?: DateTimeFilter<"PlanInstance"> | Date | string
    updatedAt?: DateTimeFilter<"PlanInstance"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    plan?: XOR<WorkoutPlanScalarRelationFilter, WorkoutPlanWhereInput>
    workoutLogs?: WorkoutLogListRelationFilter
  }, "id">

  export type PlanInstanceOrderByWithAggregationInput = {
    id?: SortOrder
    level?: SortOrder
    status?: SortOrder
    currentSession?: SortOrder
    startedAt?: SortOrder
    completedAt?: SortOrderInput | SortOrder
    sessionDraft?: SortOrderInput | SortOrder
    userId?: SortOrder
    planId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: PlanInstanceCountOrderByAggregateInput
    _avg?: PlanInstanceAvgOrderByAggregateInput
    _max?: PlanInstanceMaxOrderByAggregateInput
    _min?: PlanInstanceMinOrderByAggregateInput
    _sum?: PlanInstanceSumOrderByAggregateInput
  }

  export type PlanInstanceScalarWhereWithAggregatesInput = {
    AND?: PlanInstanceScalarWhereWithAggregatesInput | PlanInstanceScalarWhereWithAggregatesInput[]
    OR?: PlanInstanceScalarWhereWithAggregatesInput[]
    NOT?: PlanInstanceScalarWhereWithAggregatesInput | PlanInstanceScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"PlanInstance"> | string
    level?: EnumUserLevelWithAggregatesFilter<"PlanInstance"> | $Enums.UserLevel
    status?: EnumInstanceStatusWithAggregatesFilter<"PlanInstance"> | $Enums.InstanceStatus
    currentSession?: IntWithAggregatesFilter<"PlanInstance"> | number
    startedAt?: DateTimeWithAggregatesFilter<"PlanInstance"> | Date | string
    completedAt?: DateTimeNullableWithAggregatesFilter<"PlanInstance"> | Date | string | null
    sessionDraft?: JsonNullableWithAggregatesFilter<"PlanInstance">
    userId?: StringWithAggregatesFilter<"PlanInstance"> | string
    planId?: StringWithAggregatesFilter<"PlanInstance"> | string
    createdAt?: DateTimeWithAggregatesFilter<"PlanInstance"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"PlanInstance"> | Date | string
  }

  export type WorkoutLogWhereInput = {
    AND?: WorkoutLogWhereInput | WorkoutLogWhereInput[]
    OR?: WorkoutLogWhereInput[]
    NOT?: WorkoutLogWhereInput | WorkoutLogWhereInput[]
    id?: StringFilter<"WorkoutLog"> | string
    sessionNumber?: IntFilter<"WorkoutLog"> | number
    completedAt?: DateTimeFilter<"WorkoutLog"> | Date | string
    weightKg?: FloatNullableFilter<"WorkoutLog"> | number | null
    actualReps?: IntNullableFilter<"WorkoutLog"> | number | null
    actualSets?: IntNullableFilter<"WorkoutLog"> | number | null
    userId?: StringFilter<"WorkoutLog"> | string
    instanceId?: StringFilter<"WorkoutLog"> | string
    plannedExerciseId?: StringFilter<"WorkoutLog"> | string
    createdAt?: DateTimeFilter<"WorkoutLog"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    instance?: XOR<PlanInstanceScalarRelationFilter, PlanInstanceWhereInput>
    plannedExercise?: XOR<PlannedExerciseScalarRelationFilter, PlannedExerciseWhereInput>
  }

  export type WorkoutLogOrderByWithRelationInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    completedAt?: SortOrder
    weightKg?: SortOrderInput | SortOrder
    actualReps?: SortOrderInput | SortOrder
    actualSets?: SortOrderInput | SortOrder
    userId?: SortOrder
    instanceId?: SortOrder
    plannedExerciseId?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
    instance?: PlanInstanceOrderByWithRelationInput
    plannedExercise?: PlannedExerciseOrderByWithRelationInput
  }

  export type WorkoutLogWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: WorkoutLogWhereInput | WorkoutLogWhereInput[]
    OR?: WorkoutLogWhereInput[]
    NOT?: WorkoutLogWhereInput | WorkoutLogWhereInput[]
    sessionNumber?: IntFilter<"WorkoutLog"> | number
    completedAt?: DateTimeFilter<"WorkoutLog"> | Date | string
    weightKg?: FloatNullableFilter<"WorkoutLog"> | number | null
    actualReps?: IntNullableFilter<"WorkoutLog"> | number | null
    actualSets?: IntNullableFilter<"WorkoutLog"> | number | null
    userId?: StringFilter<"WorkoutLog"> | string
    instanceId?: StringFilter<"WorkoutLog"> | string
    plannedExerciseId?: StringFilter<"WorkoutLog"> | string
    createdAt?: DateTimeFilter<"WorkoutLog"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    instance?: XOR<PlanInstanceScalarRelationFilter, PlanInstanceWhereInput>
    plannedExercise?: XOR<PlannedExerciseScalarRelationFilter, PlannedExerciseWhereInput>
  }, "id">

  export type WorkoutLogOrderByWithAggregationInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    completedAt?: SortOrder
    weightKg?: SortOrderInput | SortOrder
    actualReps?: SortOrderInput | SortOrder
    actualSets?: SortOrderInput | SortOrder
    userId?: SortOrder
    instanceId?: SortOrder
    plannedExerciseId?: SortOrder
    createdAt?: SortOrder
    _count?: WorkoutLogCountOrderByAggregateInput
    _avg?: WorkoutLogAvgOrderByAggregateInput
    _max?: WorkoutLogMaxOrderByAggregateInput
    _min?: WorkoutLogMinOrderByAggregateInput
    _sum?: WorkoutLogSumOrderByAggregateInput
  }

  export type WorkoutLogScalarWhereWithAggregatesInput = {
    AND?: WorkoutLogScalarWhereWithAggregatesInput | WorkoutLogScalarWhereWithAggregatesInput[]
    OR?: WorkoutLogScalarWhereWithAggregatesInput[]
    NOT?: WorkoutLogScalarWhereWithAggregatesInput | WorkoutLogScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"WorkoutLog"> | string
    sessionNumber?: IntWithAggregatesFilter<"WorkoutLog"> | number
    completedAt?: DateTimeWithAggregatesFilter<"WorkoutLog"> | Date | string
    weightKg?: FloatNullableWithAggregatesFilter<"WorkoutLog"> | number | null
    actualReps?: IntNullableWithAggregatesFilter<"WorkoutLog"> | number | null
    actualSets?: IntNullableWithAggregatesFilter<"WorkoutLog"> | number | null
    userId?: StringWithAggregatesFilter<"WorkoutLog"> | string
    instanceId?: StringWithAggregatesFilter<"WorkoutLog"> | string
    plannedExerciseId?: StringWithAggregatesFilter<"WorkoutLog"> | string
    createdAt?: DateTimeWithAggregatesFilter<"WorkoutLog"> | Date | string
  }

  export type SubscriptionWhereInput = {
    AND?: SubscriptionWhereInput | SubscriptionWhereInput[]
    OR?: SubscriptionWhereInput[]
    NOT?: SubscriptionWhereInput | SubscriptionWhereInput[]
    id?: StringFilter<"Subscription"> | string
    plan?: EnumPlanFilter<"Subscription"> | $Enums.Plan
    status?: StringFilter<"Subscription"> | string
    source?: StringNullableFilter<"Subscription"> | string | null
    startedAt?: DateTimeFilter<"Subscription"> | Date | string
    expiresAt?: DateTimeNullableFilter<"Subscription"> | Date | string | null
    userId?: StringFilter<"Subscription"> | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type SubscriptionOrderByWithRelationInput = {
    id?: SortOrder
    plan?: SortOrder
    status?: SortOrder
    source?: SortOrderInput | SortOrder
    startedAt?: SortOrder
    expiresAt?: SortOrderInput | SortOrder
    userId?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type SubscriptionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    userId?: string
    AND?: SubscriptionWhereInput | SubscriptionWhereInput[]
    OR?: SubscriptionWhereInput[]
    NOT?: SubscriptionWhereInput | SubscriptionWhereInput[]
    plan?: EnumPlanFilter<"Subscription"> | $Enums.Plan
    status?: StringFilter<"Subscription"> | string
    source?: StringNullableFilter<"Subscription"> | string | null
    startedAt?: DateTimeFilter<"Subscription"> | Date | string
    expiresAt?: DateTimeNullableFilter<"Subscription"> | Date | string | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "userId">

  export type SubscriptionOrderByWithAggregationInput = {
    id?: SortOrder
    plan?: SortOrder
    status?: SortOrder
    source?: SortOrderInput | SortOrder
    startedAt?: SortOrder
    expiresAt?: SortOrderInput | SortOrder
    userId?: SortOrder
    _count?: SubscriptionCountOrderByAggregateInput
    _max?: SubscriptionMaxOrderByAggregateInput
    _min?: SubscriptionMinOrderByAggregateInput
  }

  export type SubscriptionScalarWhereWithAggregatesInput = {
    AND?: SubscriptionScalarWhereWithAggregatesInput | SubscriptionScalarWhereWithAggregatesInput[]
    OR?: SubscriptionScalarWhereWithAggregatesInput[]
    NOT?: SubscriptionScalarWhereWithAggregatesInput | SubscriptionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Subscription"> | string
    plan?: EnumPlanWithAggregatesFilter<"Subscription"> | $Enums.Plan
    status?: StringWithAggregatesFilter<"Subscription"> | string
    source?: StringNullableWithAggregatesFilter<"Subscription"> | string | null
    startedAt?: DateTimeWithAggregatesFilter<"Subscription"> | Date | string
    expiresAt?: DateTimeNullableWithAggregatesFilter<"Subscription"> | Date | string | null
    userId?: StringWithAggregatesFilter<"Subscription"> | string
  }

  export type UserEquipmentWhereInput = {
    AND?: UserEquipmentWhereInput | UserEquipmentWhereInput[]
    OR?: UserEquipmentWhereInput[]
    NOT?: UserEquipmentWhereInput | UserEquipmentWhereInput[]
    id?: StringFilter<"UserEquipment"> | string
    source?: EnumEquipmentSourceFilter<"UserEquipment"> | $Enums.EquipmentSource
    addedAt?: DateTimeFilter<"UserEquipment"> | Date | string
    trialExpiresAt?: DateTimeNullableFilter<"UserEquipment"> | Date | string | null
    userId?: StringFilter<"UserEquipment"> | string
    equipmentId?: StringFilter<"UserEquipment"> | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    equipment?: XOR<EquipmentScalarRelationFilter, EquipmentWhereInput>
  }

  export type UserEquipmentOrderByWithRelationInput = {
    id?: SortOrder
    source?: SortOrder
    addedAt?: SortOrder
    trialExpiresAt?: SortOrderInput | SortOrder
    userId?: SortOrder
    equipmentId?: SortOrder
    user?: UserOrderByWithRelationInput
    equipment?: EquipmentOrderByWithRelationInput
  }

  export type UserEquipmentWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: UserEquipmentWhereInput | UserEquipmentWhereInput[]
    OR?: UserEquipmentWhereInput[]
    NOT?: UserEquipmentWhereInput | UserEquipmentWhereInput[]
    source?: EnumEquipmentSourceFilter<"UserEquipment"> | $Enums.EquipmentSource
    addedAt?: DateTimeFilter<"UserEquipment"> | Date | string
    trialExpiresAt?: DateTimeNullableFilter<"UserEquipment"> | Date | string | null
    userId?: StringFilter<"UserEquipment"> | string
    equipmentId?: StringFilter<"UserEquipment"> | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    equipment?: XOR<EquipmentScalarRelationFilter, EquipmentWhereInput>
  }, "id">

  export type UserEquipmentOrderByWithAggregationInput = {
    id?: SortOrder
    source?: SortOrder
    addedAt?: SortOrder
    trialExpiresAt?: SortOrderInput | SortOrder
    userId?: SortOrder
    equipmentId?: SortOrder
    _count?: UserEquipmentCountOrderByAggregateInput
    _max?: UserEquipmentMaxOrderByAggregateInput
    _min?: UserEquipmentMinOrderByAggregateInput
  }

  export type UserEquipmentScalarWhereWithAggregatesInput = {
    AND?: UserEquipmentScalarWhereWithAggregatesInput | UserEquipmentScalarWhereWithAggregatesInput[]
    OR?: UserEquipmentScalarWhereWithAggregatesInput[]
    NOT?: UserEquipmentScalarWhereWithAggregatesInput | UserEquipmentScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"UserEquipment"> | string
    source?: EnumEquipmentSourceWithAggregatesFilter<"UserEquipment"> | $Enums.EquipmentSource
    addedAt?: DateTimeWithAggregatesFilter<"UserEquipment"> | Date | string
    trialExpiresAt?: DateTimeNullableWithAggregatesFilter<"UserEquipment"> | Date | string | null
    userId?: StringWithAggregatesFilter<"UserEquipment"> | string
    equipmentId?: StringWithAggregatesFilter<"UserEquipment"> | string
  }

  export type UserCreateInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionCreateNestedManyWithoutUserInput
    subscription?: SubscriptionCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentCreateNestedManyWithoutUserInput
    instances?: PlanInstanceCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountUncheckedCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionUncheckedCreateNestedManyWithoutUserInput
    subscription?: SubscriptionUncheckedCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutUserInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUncheckedUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUncheckedUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUncheckedUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type AccountCreateInput = {
    id?: string
    type: string
    provider: string
    providerAccountId: string
    refresh_token?: string | null
    access_token?: string | null
    expires_at?: number | null
    token_type?: string | null
    scope?: string | null
    id_token?: string | null
    session_state?: string | null
    user: UserCreateNestedOneWithoutAccountsInput
  }

  export type AccountUncheckedCreateInput = {
    id?: string
    userId: string
    type: string
    provider: string
    providerAccountId: string
    refresh_token?: string | null
    access_token?: string | null
    expires_at?: number | null
    token_type?: string | null
    scope?: string | null
    id_token?: string | null
    session_state?: string | null
  }

  export type AccountUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    providerAccountId?: StringFieldUpdateOperationsInput | string
    refresh_token?: NullableStringFieldUpdateOperationsInput | string | null
    access_token?: NullableStringFieldUpdateOperationsInput | string | null
    expires_at?: NullableIntFieldUpdateOperationsInput | number | null
    token_type?: NullableStringFieldUpdateOperationsInput | string | null
    scope?: NullableStringFieldUpdateOperationsInput | string | null
    id_token?: NullableStringFieldUpdateOperationsInput | string | null
    session_state?: NullableStringFieldUpdateOperationsInput | string | null
    user?: UserUpdateOneRequiredWithoutAccountsNestedInput
  }

  export type AccountUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    providerAccountId?: StringFieldUpdateOperationsInput | string
    refresh_token?: NullableStringFieldUpdateOperationsInput | string | null
    access_token?: NullableStringFieldUpdateOperationsInput | string | null
    expires_at?: NullableIntFieldUpdateOperationsInput | number | null
    token_type?: NullableStringFieldUpdateOperationsInput | string | null
    scope?: NullableStringFieldUpdateOperationsInput | string | null
    id_token?: NullableStringFieldUpdateOperationsInput | string | null
    session_state?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type AccountCreateManyInput = {
    id?: string
    userId: string
    type: string
    provider: string
    providerAccountId: string
    refresh_token?: string | null
    access_token?: string | null
    expires_at?: number | null
    token_type?: string | null
    scope?: string | null
    id_token?: string | null
    session_state?: string | null
  }

  export type AccountUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    providerAccountId?: StringFieldUpdateOperationsInput | string
    refresh_token?: NullableStringFieldUpdateOperationsInput | string | null
    access_token?: NullableStringFieldUpdateOperationsInput | string | null
    expires_at?: NullableIntFieldUpdateOperationsInput | number | null
    token_type?: NullableStringFieldUpdateOperationsInput | string | null
    scope?: NullableStringFieldUpdateOperationsInput | string | null
    id_token?: NullableStringFieldUpdateOperationsInput | string | null
    session_state?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type AccountUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    providerAccountId?: StringFieldUpdateOperationsInput | string
    refresh_token?: NullableStringFieldUpdateOperationsInput | string | null
    access_token?: NullableStringFieldUpdateOperationsInput | string | null
    expires_at?: NullableIntFieldUpdateOperationsInput | number | null
    token_type?: NullableStringFieldUpdateOperationsInput | string | null
    scope?: NullableStringFieldUpdateOperationsInput | string | null
    id_token?: NullableStringFieldUpdateOperationsInput | string | null
    session_state?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type NextAuthSessionCreateInput = {
    id?: string
    sessionToken: string
    expires: Date | string
    user: UserCreateNestedOneWithoutSessionsInput
  }

  export type NextAuthSessionUncheckedCreateInput = {
    id?: string
    sessionToken: string
    userId: string
    expires: Date | string
  }

  export type NextAuthSessionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutSessionsNestedInput
  }

  export type NextAuthSessionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NextAuthSessionCreateManyInput = {
    id?: string
    sessionToken: string
    userId: string
    expires: Date | string
  }

  export type NextAuthSessionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NextAuthSessionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VerificationTokenCreateInput = {
    identifier: string
    token: string
    expires: Date | string
  }

  export type VerificationTokenUncheckedCreateInput = {
    identifier: string
    token: string
    expires: Date | string
  }

  export type VerificationTokenUpdateInput = {
    identifier?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VerificationTokenUncheckedUpdateInput = {
    identifier?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VerificationTokenCreateManyInput = {
    identifier: string
    token: string
    expires: Date | string
  }

  export type VerificationTokenUpdateManyMutationInput = {
    identifier?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VerificationTokenUncheckedUpdateManyInput = {
    identifier?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EquipmentCreateInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userEquipment?: UserEquipmentCreateNestedManyWithoutEquipmentInput
    exercises?: ExerciseCreateNestedManyWithoutEquipmentInput
    workoutPlans?: WorkoutPlanCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentUncheckedCreateInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutEquipmentInput
    exercises?: ExerciseUncheckedCreateNestedManyWithoutEquipmentInput
    workoutPlans?: WorkoutPlanUncheckedCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userEquipment?: UserEquipmentUpdateManyWithoutEquipmentNestedInput
    exercises?: ExerciseUpdateManyWithoutEquipmentNestedInput
    workoutPlans?: WorkoutPlanUpdateManyWithoutEquipmentNestedInput
  }

  export type EquipmentUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutEquipmentNestedInput
    exercises?: ExerciseUncheckedUpdateManyWithoutEquipmentNestedInput
    workoutPlans?: WorkoutPlanUncheckedUpdateManyWithoutEquipmentNestedInput
  }

  export type EquipmentCreateManyInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type EquipmentUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EquipmentUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExerciseCreateInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    createdAt?: Date | string
    updatedAt?: Date | string
    equipment?: EquipmentCreateNestedOneWithoutExercisesInput
    plannedExercises?: PlannedExerciseCreateNestedManyWithoutExerciseInput
  }

  export type ExerciseUncheckedCreateInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    equipmentId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    plannedExercises?: PlannedExerciseUncheckedCreateNestedManyWithoutExerciseInput
  }

  export type ExerciseUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    equipment?: EquipmentUpdateOneWithoutExercisesNestedInput
    plannedExercises?: PlannedExerciseUpdateManyWithoutExerciseNestedInput
  }

  export type ExerciseUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    equipmentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plannedExercises?: PlannedExerciseUncheckedUpdateManyWithoutExerciseNestedInput
  }

  export type ExerciseCreateManyInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    equipmentId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ExerciseUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExerciseUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    equipmentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutPlanCreateInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    createdAt?: Date | string
    updatedAt?: Date | string
    equipment?: EquipmentCreateNestedOneWithoutWorkoutPlansInput
    plannedSessions?: PlannedSessionCreateNestedManyWithoutPlanInput
    instances?: PlanInstanceCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUncheckedCreateInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    equipmentId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    plannedSessions?: PlannedSessionUncheckedCreateNestedManyWithoutPlanInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    equipment?: EquipmentUpdateOneWithoutWorkoutPlansNestedInput
    plannedSessions?: PlannedSessionUpdateManyWithoutPlanNestedInput
    instances?: PlanInstanceUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    equipmentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plannedSessions?: PlannedSessionUncheckedUpdateManyWithoutPlanNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanCreateManyInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    equipmentId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WorkoutPlanUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutPlanUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    equipmentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlannedSessionCreateInput = {
    id?: string
    sessionNumber: number
    focus: string
    plan: WorkoutPlanCreateNestedOneWithoutPlannedSessionsInput
    plannedExercises?: PlannedExerciseCreateNestedManyWithoutSessionInput
  }

  export type PlannedSessionUncheckedCreateInput = {
    id?: string
    sessionNumber: number
    focus: string
    planId: string
    plannedExercises?: PlannedExerciseUncheckedCreateNestedManyWithoutSessionInput
  }

  export type PlannedSessionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
    plan?: WorkoutPlanUpdateOneRequiredWithoutPlannedSessionsNestedInput
    plannedExercises?: PlannedExerciseUpdateManyWithoutSessionNestedInput
  }

  export type PlannedSessionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
    planId?: StringFieldUpdateOperationsInput | string
    plannedExercises?: PlannedExerciseUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type PlannedSessionCreateManyInput = {
    id?: string
    sessionNumber: number
    focus: string
    planId: string
  }

  export type PlannedSessionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
  }

  export type PlannedSessionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
    planId?: StringFieldUpdateOperationsInput | string
  }

  export type PlannedExerciseCreateInput = {
    id?: string
    order: number
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    session: PlannedSessionCreateNestedOneWithoutPlannedExercisesInput
    exercise: ExerciseCreateNestedOneWithoutPlannedExercisesInput
    loggedSets?: WorkoutLogCreateNestedManyWithoutPlannedExerciseInput
  }

  export type PlannedExerciseUncheckedCreateInput = {
    id?: string
    order: number
    sessionId: string
    exerciseId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    loggedSets?: WorkoutLogUncheckedCreateNestedManyWithoutPlannedExerciseInput
  }

  export type PlannedExerciseUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
    session?: PlannedSessionUpdateOneRequiredWithoutPlannedExercisesNestedInput
    exercise?: ExerciseUpdateOneRequiredWithoutPlannedExercisesNestedInput
    loggedSets?: WorkoutLogUpdateManyWithoutPlannedExerciseNestedInput
  }

  export type PlannedExerciseUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    sessionId?: StringFieldUpdateOperationsInput | string
    exerciseId?: StringFieldUpdateOperationsInput | string
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
    loggedSets?: WorkoutLogUncheckedUpdateManyWithoutPlannedExerciseNestedInput
  }

  export type PlannedExerciseCreateManyInput = {
    id?: string
    order: number
    sessionId: string
    exerciseId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
  }

  export type PlannedExerciseUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
  }

  export type PlannedExerciseUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    sessionId?: StringFieldUpdateOperationsInput | string
    exerciseId?: StringFieldUpdateOperationsInput | string
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
  }

  export type PlanInstanceCreateInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutInstancesInput
    plan: WorkoutPlanCreateNestedOneWithoutInstancesInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutInstanceInput
  }

  export type PlanInstanceUncheckedCreateInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId: string
    planId: string
    createdAt?: Date | string
    updatedAt?: Date | string
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutInstanceInput
  }

  export type PlanInstanceUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutInstancesNestedInput
    plan?: WorkoutPlanUpdateOneRequiredWithoutInstancesNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutInstanceNestedInput
  }

  export type PlanInstanceUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId?: StringFieldUpdateOperationsInput | string
    planId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutInstanceNestedInput
  }

  export type PlanInstanceCreateManyInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId: string
    planId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PlanInstanceUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlanInstanceUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId?: StringFieldUpdateOperationsInput | string
    planId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogCreateInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutWorkoutLogsInput
    instance: PlanInstanceCreateNestedOneWithoutWorkoutLogsInput
    plannedExercise: PlannedExerciseCreateNestedOneWithoutLoggedSetsInput
  }

  export type WorkoutLogUncheckedCreateInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    userId: string
    instanceId: string
    plannedExerciseId: string
    createdAt?: Date | string
  }

  export type WorkoutLogUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutWorkoutLogsNestedInput
    instance?: PlanInstanceUpdateOneRequiredWithoutWorkoutLogsNestedInput
    plannedExercise?: PlannedExerciseUpdateOneRequiredWithoutLoggedSetsNestedInput
  }

  export type WorkoutLogUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    userId?: StringFieldUpdateOperationsInput | string
    instanceId?: StringFieldUpdateOperationsInput | string
    plannedExerciseId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogCreateManyInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    userId: string
    instanceId: string
    plannedExerciseId: string
    createdAt?: Date | string
  }

  export type WorkoutLogUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    userId?: StringFieldUpdateOperationsInput | string
    instanceId?: StringFieldUpdateOperationsInput | string
    plannedExerciseId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SubscriptionCreateInput = {
    id?: string
    plan?: $Enums.Plan
    status: string
    source?: string | null
    startedAt?: Date | string
    expiresAt?: Date | string | null
    user: UserCreateNestedOneWithoutSubscriptionInput
  }

  export type SubscriptionUncheckedCreateInput = {
    id?: string
    plan?: $Enums.Plan
    status: string
    source?: string | null
    startedAt?: Date | string
    expiresAt?: Date | string | null
    userId: string
  }

  export type SubscriptionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    plan?: EnumPlanFieldUpdateOperationsInput | $Enums.Plan
    status?: StringFieldUpdateOperationsInput | string
    source?: NullableStringFieldUpdateOperationsInput | string | null
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: UserUpdateOneRequiredWithoutSubscriptionNestedInput
  }

  export type SubscriptionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    plan?: EnumPlanFieldUpdateOperationsInput | $Enums.Plan
    status?: StringFieldUpdateOperationsInput | string
    source?: NullableStringFieldUpdateOperationsInput | string | null
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    userId?: StringFieldUpdateOperationsInput | string
  }

  export type SubscriptionCreateManyInput = {
    id?: string
    plan?: $Enums.Plan
    status: string
    source?: string | null
    startedAt?: Date | string
    expiresAt?: Date | string | null
    userId: string
  }

  export type SubscriptionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    plan?: EnumPlanFieldUpdateOperationsInput | $Enums.Plan
    status?: StringFieldUpdateOperationsInput | string
    source?: NullableStringFieldUpdateOperationsInput | string | null
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SubscriptionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    plan?: EnumPlanFieldUpdateOperationsInput | $Enums.Plan
    status?: StringFieldUpdateOperationsInput | string
    source?: NullableStringFieldUpdateOperationsInput | string | null
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    userId?: StringFieldUpdateOperationsInput | string
  }

  export type UserEquipmentCreateInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    user: UserCreateNestedOneWithoutUserEquipmentInput
    equipment: EquipmentCreateNestedOneWithoutUserEquipmentInput
  }

  export type UserEquipmentUncheckedCreateInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    userId: string
    equipmentId: string
  }

  export type UserEquipmentUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: UserUpdateOneRequiredWithoutUserEquipmentNestedInput
    equipment?: EquipmentUpdateOneRequiredWithoutUserEquipmentNestedInput
  }

  export type UserEquipmentUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    userId?: StringFieldUpdateOperationsInput | string
    equipmentId?: StringFieldUpdateOperationsInput | string
  }

  export type UserEquipmentCreateManyInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    userId: string
    equipmentId: string
  }

  export type UserEquipmentUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type UserEquipmentUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    userId?: StringFieldUpdateOperationsInput | string
    equipmentId?: StringFieldUpdateOperationsInput | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EnumPrimaryGoalNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.PrimaryGoal | EnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    in?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPrimaryGoalNullableFilter<$PrismaModel> | $Enums.PrimaryGoal | null
  }

  export type EnumTrainingLocationNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.TrainingLocation | EnumTrainingLocationFieldRefInput<$PrismaModel> | null
    in?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    not?: NestedEnumTrainingLocationNullableFilter<$PrismaModel> | $Enums.TrainingLocation | null
  }

  export type EnumBiologicalSexNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.BiologicalSex | EnumBiologicalSexFieldRefInput<$PrismaModel> | null
    in?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    not?: NestedEnumBiologicalSexNullableFilter<$PrismaModel> | $Enums.BiologicalSex | null
  }

  export type EnumUserLevelNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel> | null
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    not?: NestedEnumUserLevelNullableFilter<$PrismaModel> | $Enums.UserLevel | null
  }

  export type AccountListRelationFilter = {
    every?: AccountWhereInput
    some?: AccountWhereInput
    none?: AccountWhereInput
  }

  export type NextAuthSessionListRelationFilter = {
    every?: NextAuthSessionWhereInput
    some?: NextAuthSessionWhereInput
    none?: NextAuthSessionWhereInput
  }

  export type SubscriptionNullableScalarRelationFilter = {
    is?: SubscriptionWhereInput | null
    isNot?: SubscriptionWhereInput | null
  }

  export type UserEquipmentListRelationFilter = {
    every?: UserEquipmentWhereInput
    some?: UserEquipmentWhereInput
    none?: UserEquipmentWhereInput
  }

  export type PlanInstanceListRelationFilter = {
    every?: PlanInstanceWhereInput
    some?: PlanInstanceWhereInput
    none?: PlanInstanceWhereInput
  }

  export type WorkoutLogListRelationFilter = {
    every?: WorkoutLogWhereInput
    some?: WorkoutLogWhereInput
    none?: WorkoutLogWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type AccountOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type NextAuthSessionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserEquipmentOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PlanInstanceOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type WorkoutLogOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
    emailVerified?: SortOrder
    image?: SortOrder
    role?: SortOrder
    lastLoginAt?: SortOrder
    onboardingComplete?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isNewUser?: SortOrder
    primaryGoal?: SortOrder
    trainingLocation?: SortOrder
    biologicalSex?: SortOrder
    experienceLevel?: SortOrder
    onboardingCompletedAt?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
    emailVerified?: SortOrder
    image?: SortOrder
    role?: SortOrder
    lastLoginAt?: SortOrder
    onboardingComplete?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isNewUser?: SortOrder
    primaryGoal?: SortOrder
    trainingLocation?: SortOrder
    biologicalSex?: SortOrder
    experienceLevel?: SortOrder
    onboardingCompletedAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    password?: SortOrder
    emailVerified?: SortOrder
    image?: SortOrder
    role?: SortOrder
    lastLoginAt?: SortOrder
    onboardingComplete?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isNewUser?: SortOrder
    primaryGoal?: SortOrder
    trainingLocation?: SortOrder
    biologicalSex?: SortOrder
    experienceLevel?: SortOrder
    onboardingCompletedAt?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type EnumPrimaryGoalNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PrimaryGoal | EnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    in?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPrimaryGoalNullableWithAggregatesFilter<$PrismaModel> | $Enums.PrimaryGoal | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumPrimaryGoalNullableFilter<$PrismaModel>
    _max?: NestedEnumPrimaryGoalNullableFilter<$PrismaModel>
  }

  export type EnumTrainingLocationNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TrainingLocation | EnumTrainingLocationFieldRefInput<$PrismaModel> | null
    in?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    not?: NestedEnumTrainingLocationNullableWithAggregatesFilter<$PrismaModel> | $Enums.TrainingLocation | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumTrainingLocationNullableFilter<$PrismaModel>
    _max?: NestedEnumTrainingLocationNullableFilter<$PrismaModel>
  }

  export type EnumBiologicalSexNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BiologicalSex | EnumBiologicalSexFieldRefInput<$PrismaModel> | null
    in?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    not?: NestedEnumBiologicalSexNullableWithAggregatesFilter<$PrismaModel> | $Enums.BiologicalSex | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumBiologicalSexNullableFilter<$PrismaModel>
    _max?: NestedEnumBiologicalSexNullableFilter<$PrismaModel>
  }

  export type EnumUserLevelNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel> | null
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    not?: NestedEnumUserLevelNullableWithAggregatesFilter<$PrismaModel> | $Enums.UserLevel | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumUserLevelNullableFilter<$PrismaModel>
    _max?: NestedEnumUserLevelNullableFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type AccountProviderProviderAccountIdCompoundUniqueInput = {
    provider: string
    providerAccountId: string
  }

  export type AccountCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    provider?: SortOrder
    providerAccountId?: SortOrder
    refresh_token?: SortOrder
    access_token?: SortOrder
    expires_at?: SortOrder
    token_type?: SortOrder
    scope?: SortOrder
    id_token?: SortOrder
    session_state?: SortOrder
  }

  export type AccountAvgOrderByAggregateInput = {
    expires_at?: SortOrder
  }

  export type AccountMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    provider?: SortOrder
    providerAccountId?: SortOrder
    refresh_token?: SortOrder
    access_token?: SortOrder
    expires_at?: SortOrder
    token_type?: SortOrder
    scope?: SortOrder
    id_token?: SortOrder
    session_state?: SortOrder
  }

  export type AccountMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    provider?: SortOrder
    providerAccountId?: SortOrder
    refresh_token?: SortOrder
    access_token?: SortOrder
    expires_at?: SortOrder
    token_type?: SortOrder
    scope?: SortOrder
    id_token?: SortOrder
    session_state?: SortOrder
  }

  export type AccountSumOrderByAggregateInput = {
    expires_at?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NextAuthSessionCountOrderByAggregateInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
  }

  export type NextAuthSessionMaxOrderByAggregateInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
  }

  export type NextAuthSessionMinOrderByAggregateInput = {
    id?: SortOrder
    sessionToken?: SortOrder
    userId?: SortOrder
    expires?: SortOrder
  }

  export type VerificationTokenIdentifierTokenCompoundUniqueInput = {
    identifier: string
    token: string
  }

  export type VerificationTokenCountOrderByAggregateInput = {
    identifier?: SortOrder
    token?: SortOrder
    expires?: SortOrder
  }

  export type VerificationTokenMaxOrderByAggregateInput = {
    identifier?: SortOrder
    token?: SortOrder
    expires?: SortOrder
  }

  export type VerificationTokenMinOrderByAggregateInput = {
    identifier?: SortOrder
    token?: SortOrder
    expires?: SortOrder
  }

  export type ExerciseListRelationFilter = {
    every?: ExerciseWhereInput
    some?: ExerciseWhereInput
    none?: ExerciseWhereInput
  }

  export type WorkoutPlanListRelationFilter = {
    every?: WorkoutPlanWhereInput
    some?: WorkoutPlanWhereInput
    none?: WorkoutPlanWhereInput
  }

  export type ExerciseOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type WorkoutPlanOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type EquipmentCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type EquipmentMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type EquipmentMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    category?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringNullableListFilter<$PrismaModel = never> = {
    equals?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    has?: string | StringFieldRefInput<$PrismaModel> | null
    hasEvery?: string[] | ListStringFieldRefInput<$PrismaModel>
    hasSome?: string[] | ListStringFieldRefInput<$PrismaModel>
    isEmpty?: boolean
  }

  export type EnumMuscleGroupFilter<$PrismaModel = never> = {
    equals?: $Enums.MuscleGroup | EnumMuscleGroupFieldRefInput<$PrismaModel>
    in?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    notIn?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    not?: NestedEnumMuscleGroupFilter<$PrismaModel> | $Enums.MuscleGroup
  }

  export type EquipmentNullableScalarRelationFilter = {
    is?: EquipmentWhereInput | null
    isNot?: EquipmentWhereInput | null
  }

  export type PlannedExerciseListRelationFilter = {
    every?: PlannedExerciseWhereInput
    some?: PlannedExerciseWhereInput
    none?: PlannedExerciseWhereInput
  }

  export type PlannedExerciseOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ExerciseCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    youtubeUrl?: SortOrder
    musclesWorked?: SortOrder
    muscleGroup?: SortOrder
    equipmentId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ExerciseMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    youtubeUrl?: SortOrder
    muscleGroup?: SortOrder
    equipmentId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ExerciseMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    youtubeUrl?: SortOrder
    muscleGroup?: SortOrder
    equipmentId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type EnumMuscleGroupWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MuscleGroup | EnumMuscleGroupFieldRefInput<$PrismaModel>
    in?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    notIn?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    not?: NestedEnumMuscleGroupWithAggregatesFilter<$PrismaModel> | $Enums.MuscleGroup
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMuscleGroupFilter<$PrismaModel>
    _max?: NestedEnumMuscleGroupFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type EnumPlanTierFilter<$PrismaModel = never> = {
    equals?: $Enums.PlanTier | EnumPlanTierFieldRefInput<$PrismaModel>
    in?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    notIn?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanTierFilter<$PrismaModel> | $Enums.PlanTier
  }

  export type PlannedSessionListRelationFilter = {
    every?: PlannedSessionWhereInput
    some?: PlannedSessionWhereInput
    none?: PlannedSessionWhereInput
  }

  export type PlannedSessionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type WorkoutPlanCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    muscleGroup?: SortOrder
    durationWeeks?: SortOrder
    sessionsPerWeek?: SortOrder
    tier?: SortOrder
    equipmentId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutPlanAvgOrderByAggregateInput = {
    durationWeeks?: SortOrder
    sessionsPerWeek?: SortOrder
  }

  export type WorkoutPlanMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    muscleGroup?: SortOrder
    durationWeeks?: SortOrder
    sessionsPerWeek?: SortOrder
    tier?: SortOrder
    equipmentId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutPlanMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    muscleGroup?: SortOrder
    durationWeeks?: SortOrder
    sessionsPerWeek?: SortOrder
    tier?: SortOrder
    equipmentId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WorkoutPlanSumOrderByAggregateInput = {
    durationWeeks?: SortOrder
    sessionsPerWeek?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type EnumPlanTierWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PlanTier | EnumPlanTierFieldRefInput<$PrismaModel>
    in?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    notIn?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanTierWithAggregatesFilter<$PrismaModel> | $Enums.PlanTier
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPlanTierFilter<$PrismaModel>
    _max?: NestedEnumPlanTierFilter<$PrismaModel>
  }

  export type WorkoutPlanScalarRelationFilter = {
    is?: WorkoutPlanWhereInput
    isNot?: WorkoutPlanWhereInput
  }

  export type PlannedSessionPlanIdSessionNumberCompoundUniqueInput = {
    planId: string
    sessionNumber: number
  }

  export type PlannedSessionCountOrderByAggregateInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    focus?: SortOrder
    planId?: SortOrder
  }

  export type PlannedSessionAvgOrderByAggregateInput = {
    sessionNumber?: SortOrder
  }

  export type PlannedSessionMaxOrderByAggregateInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    focus?: SortOrder
    planId?: SortOrder
  }

  export type PlannedSessionMinOrderByAggregateInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    focus?: SortOrder
    planId?: SortOrder
  }

  export type PlannedSessionSumOrderByAggregateInput = {
    sessionNumber?: SortOrder
  }

  export type PlannedSessionScalarRelationFilter = {
    is?: PlannedSessionWhereInput
    isNot?: PlannedSessionWhereInput
  }

  export type ExerciseScalarRelationFilter = {
    is?: ExerciseWhereInput
    isNot?: ExerciseWhereInput
  }

  export type PlannedExerciseSessionIdOrderCompoundUniqueInput = {
    sessionId: string
    order: number
  }

  export type PlannedExerciseCountOrderByAggregateInput = {
    id?: SortOrder
    order?: SortOrder
    sessionId?: SortOrder
    exerciseId?: SortOrder
    beginnerSets?: SortOrder
    beginnerReps?: SortOrder
    intermediateSets?: SortOrder
    intermediateReps?: SortOrder
    advancedSets?: SortOrder
    advancedReps?: SortOrder
    restSeconds?: SortOrder
  }

  export type PlannedExerciseAvgOrderByAggregateInput = {
    order?: SortOrder
    beginnerSets?: SortOrder
    beginnerReps?: SortOrder
    intermediateSets?: SortOrder
    intermediateReps?: SortOrder
    advancedSets?: SortOrder
    advancedReps?: SortOrder
    restSeconds?: SortOrder
  }

  export type PlannedExerciseMaxOrderByAggregateInput = {
    id?: SortOrder
    order?: SortOrder
    sessionId?: SortOrder
    exerciseId?: SortOrder
    beginnerSets?: SortOrder
    beginnerReps?: SortOrder
    intermediateSets?: SortOrder
    intermediateReps?: SortOrder
    advancedSets?: SortOrder
    advancedReps?: SortOrder
    restSeconds?: SortOrder
  }

  export type PlannedExerciseMinOrderByAggregateInput = {
    id?: SortOrder
    order?: SortOrder
    sessionId?: SortOrder
    exerciseId?: SortOrder
    beginnerSets?: SortOrder
    beginnerReps?: SortOrder
    intermediateSets?: SortOrder
    intermediateReps?: SortOrder
    advancedSets?: SortOrder
    advancedReps?: SortOrder
    restSeconds?: SortOrder
  }

  export type PlannedExerciseSumOrderByAggregateInput = {
    order?: SortOrder
    beginnerSets?: SortOrder
    beginnerReps?: SortOrder
    intermediateSets?: SortOrder
    intermediateReps?: SortOrder
    advancedSets?: SortOrder
    advancedReps?: SortOrder
    restSeconds?: SortOrder
  }

  export type EnumUserLevelFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel>
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    not?: NestedEnumUserLevelFilter<$PrismaModel> | $Enums.UserLevel
  }

  export type EnumInstanceStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.InstanceStatus | EnumInstanceStatusFieldRefInput<$PrismaModel>
    in?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumInstanceStatusFilter<$PrismaModel> | $Enums.InstanceStatus
  }
  export type JsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type PlanInstanceCountOrderByAggregateInput = {
    id?: SortOrder
    level?: SortOrder
    status?: SortOrder
    currentSession?: SortOrder
    startedAt?: SortOrder
    completedAt?: SortOrder
    sessionDraft?: SortOrder
    userId?: SortOrder
    planId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PlanInstanceAvgOrderByAggregateInput = {
    currentSession?: SortOrder
  }

  export type PlanInstanceMaxOrderByAggregateInput = {
    id?: SortOrder
    level?: SortOrder
    status?: SortOrder
    currentSession?: SortOrder
    startedAt?: SortOrder
    completedAt?: SortOrder
    userId?: SortOrder
    planId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PlanInstanceMinOrderByAggregateInput = {
    id?: SortOrder
    level?: SortOrder
    status?: SortOrder
    currentSession?: SortOrder
    startedAt?: SortOrder
    completedAt?: SortOrder
    userId?: SortOrder
    planId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PlanInstanceSumOrderByAggregateInput = {
    currentSession?: SortOrder
  }

  export type EnumUserLevelWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel>
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    not?: NestedEnumUserLevelWithAggregatesFilter<$PrismaModel> | $Enums.UserLevel
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumUserLevelFilter<$PrismaModel>
    _max?: NestedEnumUserLevelFilter<$PrismaModel>
  }

  export type EnumInstanceStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.InstanceStatus | EnumInstanceStatusFieldRefInput<$PrismaModel>
    in?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumInstanceStatusWithAggregatesFilter<$PrismaModel> | $Enums.InstanceStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumInstanceStatusFilter<$PrismaModel>
    _max?: NestedEnumInstanceStatusFilter<$PrismaModel>
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type FloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type PlanInstanceScalarRelationFilter = {
    is?: PlanInstanceWhereInput
    isNot?: PlanInstanceWhereInput
  }

  export type PlannedExerciseScalarRelationFilter = {
    is?: PlannedExerciseWhereInput
    isNot?: PlannedExerciseWhereInput
  }

  export type WorkoutLogCountOrderByAggregateInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    completedAt?: SortOrder
    weightKg?: SortOrder
    actualReps?: SortOrder
    actualSets?: SortOrder
    userId?: SortOrder
    instanceId?: SortOrder
    plannedExerciseId?: SortOrder
    createdAt?: SortOrder
  }

  export type WorkoutLogAvgOrderByAggregateInput = {
    sessionNumber?: SortOrder
    weightKg?: SortOrder
    actualReps?: SortOrder
    actualSets?: SortOrder
  }

  export type WorkoutLogMaxOrderByAggregateInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    completedAt?: SortOrder
    weightKg?: SortOrder
    actualReps?: SortOrder
    actualSets?: SortOrder
    userId?: SortOrder
    instanceId?: SortOrder
    plannedExerciseId?: SortOrder
    createdAt?: SortOrder
  }

  export type WorkoutLogMinOrderByAggregateInput = {
    id?: SortOrder
    sessionNumber?: SortOrder
    completedAt?: SortOrder
    weightKg?: SortOrder
    actualReps?: SortOrder
    actualSets?: SortOrder
    userId?: SortOrder
    instanceId?: SortOrder
    plannedExerciseId?: SortOrder
    createdAt?: SortOrder
  }

  export type WorkoutLogSumOrderByAggregateInput = {
    sessionNumber?: SortOrder
    weightKg?: SortOrder
    actualReps?: SortOrder
    actualSets?: SortOrder
  }

  export type FloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type EnumPlanFilter<$PrismaModel = never> = {
    equals?: $Enums.Plan | EnumPlanFieldRefInput<$PrismaModel>
    in?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    notIn?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanFilter<$PrismaModel> | $Enums.Plan
  }

  export type SubscriptionCountOrderByAggregateInput = {
    id?: SortOrder
    plan?: SortOrder
    status?: SortOrder
    source?: SortOrder
    startedAt?: SortOrder
    expiresAt?: SortOrder
    userId?: SortOrder
  }

  export type SubscriptionMaxOrderByAggregateInput = {
    id?: SortOrder
    plan?: SortOrder
    status?: SortOrder
    source?: SortOrder
    startedAt?: SortOrder
    expiresAt?: SortOrder
    userId?: SortOrder
  }

  export type SubscriptionMinOrderByAggregateInput = {
    id?: SortOrder
    plan?: SortOrder
    status?: SortOrder
    source?: SortOrder
    startedAt?: SortOrder
    expiresAt?: SortOrder
    userId?: SortOrder
  }

  export type EnumPlanWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Plan | EnumPlanFieldRefInput<$PrismaModel>
    in?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    notIn?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanWithAggregatesFilter<$PrismaModel> | $Enums.Plan
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPlanFilter<$PrismaModel>
    _max?: NestedEnumPlanFilter<$PrismaModel>
  }

  export type EnumEquipmentSourceFilter<$PrismaModel = never> = {
    equals?: $Enums.EquipmentSource | EnumEquipmentSourceFieldRefInput<$PrismaModel>
    in?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    notIn?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    not?: NestedEnumEquipmentSourceFilter<$PrismaModel> | $Enums.EquipmentSource
  }

  export type EquipmentScalarRelationFilter = {
    is?: EquipmentWhereInput
    isNot?: EquipmentWhereInput
  }

  export type UserEquipmentCountOrderByAggregateInput = {
    id?: SortOrder
    source?: SortOrder
    addedAt?: SortOrder
    trialExpiresAt?: SortOrder
    userId?: SortOrder
    equipmentId?: SortOrder
  }

  export type UserEquipmentMaxOrderByAggregateInput = {
    id?: SortOrder
    source?: SortOrder
    addedAt?: SortOrder
    trialExpiresAt?: SortOrder
    userId?: SortOrder
    equipmentId?: SortOrder
  }

  export type UserEquipmentMinOrderByAggregateInput = {
    id?: SortOrder
    source?: SortOrder
    addedAt?: SortOrder
    trialExpiresAt?: SortOrder
    userId?: SortOrder
    equipmentId?: SortOrder
  }

  export type EnumEquipmentSourceWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EquipmentSource | EnumEquipmentSourceFieldRefInput<$PrismaModel>
    in?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    notIn?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    not?: NestedEnumEquipmentSourceWithAggregatesFilter<$PrismaModel> | $Enums.EquipmentSource
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEquipmentSourceFilter<$PrismaModel>
    _max?: NestedEnumEquipmentSourceFilter<$PrismaModel>
  }

  export type AccountCreateNestedManyWithoutUserInput = {
    create?: XOR<AccountCreateWithoutUserInput, AccountUncheckedCreateWithoutUserInput> | AccountCreateWithoutUserInput[] | AccountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: AccountCreateOrConnectWithoutUserInput | AccountCreateOrConnectWithoutUserInput[]
    createMany?: AccountCreateManyUserInputEnvelope
    connect?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
  }

  export type NextAuthSessionCreateNestedManyWithoutUserInput = {
    create?: XOR<NextAuthSessionCreateWithoutUserInput, NextAuthSessionUncheckedCreateWithoutUserInput> | NextAuthSessionCreateWithoutUserInput[] | NextAuthSessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NextAuthSessionCreateOrConnectWithoutUserInput | NextAuthSessionCreateOrConnectWithoutUserInput[]
    createMany?: NextAuthSessionCreateManyUserInputEnvelope
    connect?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
  }

  export type SubscriptionCreateNestedOneWithoutUserInput = {
    create?: XOR<SubscriptionCreateWithoutUserInput, SubscriptionUncheckedCreateWithoutUserInput>
    connectOrCreate?: SubscriptionCreateOrConnectWithoutUserInput
    connect?: SubscriptionWhereUniqueInput
  }

  export type UserEquipmentCreateNestedManyWithoutUserInput = {
    create?: XOR<UserEquipmentCreateWithoutUserInput, UserEquipmentUncheckedCreateWithoutUserInput> | UserEquipmentCreateWithoutUserInput[] | UserEquipmentUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutUserInput | UserEquipmentCreateOrConnectWithoutUserInput[]
    createMany?: UserEquipmentCreateManyUserInputEnvelope
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
  }

  export type PlanInstanceCreateNestedManyWithoutUserInput = {
    create?: XOR<PlanInstanceCreateWithoutUserInput, PlanInstanceUncheckedCreateWithoutUserInput> | PlanInstanceCreateWithoutUserInput[] | PlanInstanceUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutUserInput | PlanInstanceCreateOrConnectWithoutUserInput[]
    createMany?: PlanInstanceCreateManyUserInputEnvelope
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
  }

  export type WorkoutLogCreateNestedManyWithoutUserInput = {
    create?: XOR<WorkoutLogCreateWithoutUserInput, WorkoutLogUncheckedCreateWithoutUserInput> | WorkoutLogCreateWithoutUserInput[] | WorkoutLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutUserInput | WorkoutLogCreateOrConnectWithoutUserInput[]
    createMany?: WorkoutLogCreateManyUserInputEnvelope
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
  }

  export type AccountUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<AccountCreateWithoutUserInput, AccountUncheckedCreateWithoutUserInput> | AccountCreateWithoutUserInput[] | AccountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: AccountCreateOrConnectWithoutUserInput | AccountCreateOrConnectWithoutUserInput[]
    createMany?: AccountCreateManyUserInputEnvelope
    connect?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
  }

  export type NextAuthSessionUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<NextAuthSessionCreateWithoutUserInput, NextAuthSessionUncheckedCreateWithoutUserInput> | NextAuthSessionCreateWithoutUserInput[] | NextAuthSessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NextAuthSessionCreateOrConnectWithoutUserInput | NextAuthSessionCreateOrConnectWithoutUserInput[]
    createMany?: NextAuthSessionCreateManyUserInputEnvelope
    connect?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
  }

  export type SubscriptionUncheckedCreateNestedOneWithoutUserInput = {
    create?: XOR<SubscriptionCreateWithoutUserInput, SubscriptionUncheckedCreateWithoutUserInput>
    connectOrCreate?: SubscriptionCreateOrConnectWithoutUserInput
    connect?: SubscriptionWhereUniqueInput
  }

  export type UserEquipmentUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<UserEquipmentCreateWithoutUserInput, UserEquipmentUncheckedCreateWithoutUserInput> | UserEquipmentCreateWithoutUserInput[] | UserEquipmentUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutUserInput | UserEquipmentCreateOrConnectWithoutUserInput[]
    createMany?: UserEquipmentCreateManyUserInputEnvelope
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
  }

  export type PlanInstanceUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<PlanInstanceCreateWithoutUserInput, PlanInstanceUncheckedCreateWithoutUserInput> | PlanInstanceCreateWithoutUserInput[] | PlanInstanceUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutUserInput | PlanInstanceCreateOrConnectWithoutUserInput[]
    createMany?: PlanInstanceCreateManyUserInputEnvelope
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
  }

  export type WorkoutLogUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<WorkoutLogCreateWithoutUserInput, WorkoutLogUncheckedCreateWithoutUserInput> | WorkoutLogCreateWithoutUserInput[] | WorkoutLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutUserInput | WorkoutLogCreateOrConnectWithoutUserInput[]
    createMany?: WorkoutLogCreateManyUserInputEnvelope
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type NullableEnumPrimaryGoalFieldUpdateOperationsInput = {
    set?: $Enums.PrimaryGoal | null
  }

  export type NullableEnumTrainingLocationFieldUpdateOperationsInput = {
    set?: $Enums.TrainingLocation | null
  }

  export type NullableEnumBiologicalSexFieldUpdateOperationsInput = {
    set?: $Enums.BiologicalSex | null
  }

  export type NullableEnumUserLevelFieldUpdateOperationsInput = {
    set?: $Enums.UserLevel | null
  }

  export type AccountUpdateManyWithoutUserNestedInput = {
    create?: XOR<AccountCreateWithoutUserInput, AccountUncheckedCreateWithoutUserInput> | AccountCreateWithoutUserInput[] | AccountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: AccountCreateOrConnectWithoutUserInput | AccountCreateOrConnectWithoutUserInput[]
    upsert?: AccountUpsertWithWhereUniqueWithoutUserInput | AccountUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: AccountCreateManyUserInputEnvelope
    set?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    disconnect?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    delete?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    connect?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    update?: AccountUpdateWithWhereUniqueWithoutUserInput | AccountUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: AccountUpdateManyWithWhereWithoutUserInput | AccountUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: AccountScalarWhereInput | AccountScalarWhereInput[]
  }

  export type NextAuthSessionUpdateManyWithoutUserNestedInput = {
    create?: XOR<NextAuthSessionCreateWithoutUserInput, NextAuthSessionUncheckedCreateWithoutUserInput> | NextAuthSessionCreateWithoutUserInput[] | NextAuthSessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NextAuthSessionCreateOrConnectWithoutUserInput | NextAuthSessionCreateOrConnectWithoutUserInput[]
    upsert?: NextAuthSessionUpsertWithWhereUniqueWithoutUserInput | NextAuthSessionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: NextAuthSessionCreateManyUserInputEnvelope
    set?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    disconnect?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    delete?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    connect?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    update?: NextAuthSessionUpdateWithWhereUniqueWithoutUserInput | NextAuthSessionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: NextAuthSessionUpdateManyWithWhereWithoutUserInput | NextAuthSessionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: NextAuthSessionScalarWhereInput | NextAuthSessionScalarWhereInput[]
  }

  export type SubscriptionUpdateOneWithoutUserNestedInput = {
    create?: XOR<SubscriptionCreateWithoutUserInput, SubscriptionUncheckedCreateWithoutUserInput>
    connectOrCreate?: SubscriptionCreateOrConnectWithoutUserInput
    upsert?: SubscriptionUpsertWithoutUserInput
    disconnect?: SubscriptionWhereInput | boolean
    delete?: SubscriptionWhereInput | boolean
    connect?: SubscriptionWhereUniqueInput
    update?: XOR<XOR<SubscriptionUpdateToOneWithWhereWithoutUserInput, SubscriptionUpdateWithoutUserInput>, SubscriptionUncheckedUpdateWithoutUserInput>
  }

  export type UserEquipmentUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserEquipmentCreateWithoutUserInput, UserEquipmentUncheckedCreateWithoutUserInput> | UserEquipmentCreateWithoutUserInput[] | UserEquipmentUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutUserInput | UserEquipmentCreateOrConnectWithoutUserInput[]
    upsert?: UserEquipmentUpsertWithWhereUniqueWithoutUserInput | UserEquipmentUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserEquipmentCreateManyUserInputEnvelope
    set?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    disconnect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    delete?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    update?: UserEquipmentUpdateWithWhereUniqueWithoutUserInput | UserEquipmentUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserEquipmentUpdateManyWithWhereWithoutUserInput | UserEquipmentUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserEquipmentScalarWhereInput | UserEquipmentScalarWhereInput[]
  }

  export type PlanInstanceUpdateManyWithoutUserNestedInput = {
    create?: XOR<PlanInstanceCreateWithoutUserInput, PlanInstanceUncheckedCreateWithoutUserInput> | PlanInstanceCreateWithoutUserInput[] | PlanInstanceUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutUserInput | PlanInstanceCreateOrConnectWithoutUserInput[]
    upsert?: PlanInstanceUpsertWithWhereUniqueWithoutUserInput | PlanInstanceUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PlanInstanceCreateManyUserInputEnvelope
    set?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    disconnect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    delete?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    update?: PlanInstanceUpdateWithWhereUniqueWithoutUserInput | PlanInstanceUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PlanInstanceUpdateManyWithWhereWithoutUserInput | PlanInstanceUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PlanInstanceScalarWhereInput | PlanInstanceScalarWhereInput[]
  }

  export type WorkoutLogUpdateManyWithoutUserNestedInput = {
    create?: XOR<WorkoutLogCreateWithoutUserInput, WorkoutLogUncheckedCreateWithoutUserInput> | WorkoutLogCreateWithoutUserInput[] | WorkoutLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutUserInput | WorkoutLogCreateOrConnectWithoutUserInput[]
    upsert?: WorkoutLogUpsertWithWhereUniqueWithoutUserInput | WorkoutLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WorkoutLogCreateManyUserInputEnvelope
    set?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    disconnect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    delete?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    update?: WorkoutLogUpdateWithWhereUniqueWithoutUserInput | WorkoutLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WorkoutLogUpdateManyWithWhereWithoutUserInput | WorkoutLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
  }

  export type AccountUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<AccountCreateWithoutUserInput, AccountUncheckedCreateWithoutUserInput> | AccountCreateWithoutUserInput[] | AccountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: AccountCreateOrConnectWithoutUserInput | AccountCreateOrConnectWithoutUserInput[]
    upsert?: AccountUpsertWithWhereUniqueWithoutUserInput | AccountUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: AccountCreateManyUserInputEnvelope
    set?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    disconnect?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    delete?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    connect?: AccountWhereUniqueInput | AccountWhereUniqueInput[]
    update?: AccountUpdateWithWhereUniqueWithoutUserInput | AccountUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: AccountUpdateManyWithWhereWithoutUserInput | AccountUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: AccountScalarWhereInput | AccountScalarWhereInput[]
  }

  export type NextAuthSessionUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<NextAuthSessionCreateWithoutUserInput, NextAuthSessionUncheckedCreateWithoutUserInput> | NextAuthSessionCreateWithoutUserInput[] | NextAuthSessionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: NextAuthSessionCreateOrConnectWithoutUserInput | NextAuthSessionCreateOrConnectWithoutUserInput[]
    upsert?: NextAuthSessionUpsertWithWhereUniqueWithoutUserInput | NextAuthSessionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: NextAuthSessionCreateManyUserInputEnvelope
    set?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    disconnect?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    delete?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    connect?: NextAuthSessionWhereUniqueInput | NextAuthSessionWhereUniqueInput[]
    update?: NextAuthSessionUpdateWithWhereUniqueWithoutUserInput | NextAuthSessionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: NextAuthSessionUpdateManyWithWhereWithoutUserInput | NextAuthSessionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: NextAuthSessionScalarWhereInput | NextAuthSessionScalarWhereInput[]
  }

  export type SubscriptionUncheckedUpdateOneWithoutUserNestedInput = {
    create?: XOR<SubscriptionCreateWithoutUserInput, SubscriptionUncheckedCreateWithoutUserInput>
    connectOrCreate?: SubscriptionCreateOrConnectWithoutUserInput
    upsert?: SubscriptionUpsertWithoutUserInput
    disconnect?: SubscriptionWhereInput | boolean
    delete?: SubscriptionWhereInput | boolean
    connect?: SubscriptionWhereUniqueInput
    update?: XOR<XOR<SubscriptionUpdateToOneWithWhereWithoutUserInput, SubscriptionUpdateWithoutUserInput>, SubscriptionUncheckedUpdateWithoutUserInput>
  }

  export type UserEquipmentUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserEquipmentCreateWithoutUserInput, UserEquipmentUncheckedCreateWithoutUserInput> | UserEquipmentCreateWithoutUserInput[] | UserEquipmentUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutUserInput | UserEquipmentCreateOrConnectWithoutUserInput[]
    upsert?: UserEquipmentUpsertWithWhereUniqueWithoutUserInput | UserEquipmentUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserEquipmentCreateManyUserInputEnvelope
    set?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    disconnect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    delete?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    update?: UserEquipmentUpdateWithWhereUniqueWithoutUserInput | UserEquipmentUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserEquipmentUpdateManyWithWhereWithoutUserInput | UserEquipmentUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserEquipmentScalarWhereInput | UserEquipmentScalarWhereInput[]
  }

  export type PlanInstanceUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<PlanInstanceCreateWithoutUserInput, PlanInstanceUncheckedCreateWithoutUserInput> | PlanInstanceCreateWithoutUserInput[] | PlanInstanceUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutUserInput | PlanInstanceCreateOrConnectWithoutUserInput[]
    upsert?: PlanInstanceUpsertWithWhereUniqueWithoutUserInput | PlanInstanceUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PlanInstanceCreateManyUserInputEnvelope
    set?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    disconnect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    delete?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    update?: PlanInstanceUpdateWithWhereUniqueWithoutUserInput | PlanInstanceUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PlanInstanceUpdateManyWithWhereWithoutUserInput | PlanInstanceUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PlanInstanceScalarWhereInput | PlanInstanceScalarWhereInput[]
  }

  export type WorkoutLogUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<WorkoutLogCreateWithoutUserInput, WorkoutLogUncheckedCreateWithoutUserInput> | WorkoutLogCreateWithoutUserInput[] | WorkoutLogUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutUserInput | WorkoutLogCreateOrConnectWithoutUserInput[]
    upsert?: WorkoutLogUpsertWithWhereUniqueWithoutUserInput | WorkoutLogUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WorkoutLogCreateManyUserInputEnvelope
    set?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    disconnect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    delete?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    update?: WorkoutLogUpdateWithWhereUniqueWithoutUserInput | WorkoutLogUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WorkoutLogUpdateManyWithWhereWithoutUserInput | WorkoutLogUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutAccountsInput = {
    create?: XOR<UserCreateWithoutAccountsInput, UserUncheckedCreateWithoutAccountsInput>
    connectOrCreate?: UserCreateOrConnectWithoutAccountsInput
    connect?: UserWhereUniqueInput
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type UserUpdateOneRequiredWithoutAccountsNestedInput = {
    create?: XOR<UserCreateWithoutAccountsInput, UserUncheckedCreateWithoutAccountsInput>
    connectOrCreate?: UserCreateOrConnectWithoutAccountsInput
    upsert?: UserUpsertWithoutAccountsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutAccountsInput, UserUpdateWithoutAccountsInput>, UserUncheckedUpdateWithoutAccountsInput>
  }

  export type UserCreateNestedOneWithoutSessionsInput = {
    create?: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutSessionsInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutSessionsNestedInput = {
    create?: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutSessionsInput
    upsert?: UserUpsertWithoutSessionsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutSessionsInput, UserUpdateWithoutSessionsInput>, UserUncheckedUpdateWithoutSessionsInput>
  }

  export type UserEquipmentCreateNestedManyWithoutEquipmentInput = {
    create?: XOR<UserEquipmentCreateWithoutEquipmentInput, UserEquipmentUncheckedCreateWithoutEquipmentInput> | UserEquipmentCreateWithoutEquipmentInput[] | UserEquipmentUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutEquipmentInput | UserEquipmentCreateOrConnectWithoutEquipmentInput[]
    createMany?: UserEquipmentCreateManyEquipmentInputEnvelope
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
  }

  export type ExerciseCreateNestedManyWithoutEquipmentInput = {
    create?: XOR<ExerciseCreateWithoutEquipmentInput, ExerciseUncheckedCreateWithoutEquipmentInput> | ExerciseCreateWithoutEquipmentInput[] | ExerciseUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: ExerciseCreateOrConnectWithoutEquipmentInput | ExerciseCreateOrConnectWithoutEquipmentInput[]
    createMany?: ExerciseCreateManyEquipmentInputEnvelope
    connect?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
  }

  export type WorkoutPlanCreateNestedManyWithoutEquipmentInput = {
    create?: XOR<WorkoutPlanCreateWithoutEquipmentInput, WorkoutPlanUncheckedCreateWithoutEquipmentInput> | WorkoutPlanCreateWithoutEquipmentInput[] | WorkoutPlanUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutEquipmentInput | WorkoutPlanCreateOrConnectWithoutEquipmentInput[]
    createMany?: WorkoutPlanCreateManyEquipmentInputEnvelope
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
  }

  export type UserEquipmentUncheckedCreateNestedManyWithoutEquipmentInput = {
    create?: XOR<UserEquipmentCreateWithoutEquipmentInput, UserEquipmentUncheckedCreateWithoutEquipmentInput> | UserEquipmentCreateWithoutEquipmentInput[] | UserEquipmentUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutEquipmentInput | UserEquipmentCreateOrConnectWithoutEquipmentInput[]
    createMany?: UserEquipmentCreateManyEquipmentInputEnvelope
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
  }

  export type ExerciseUncheckedCreateNestedManyWithoutEquipmentInput = {
    create?: XOR<ExerciseCreateWithoutEquipmentInput, ExerciseUncheckedCreateWithoutEquipmentInput> | ExerciseCreateWithoutEquipmentInput[] | ExerciseUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: ExerciseCreateOrConnectWithoutEquipmentInput | ExerciseCreateOrConnectWithoutEquipmentInput[]
    createMany?: ExerciseCreateManyEquipmentInputEnvelope
    connect?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
  }

  export type WorkoutPlanUncheckedCreateNestedManyWithoutEquipmentInput = {
    create?: XOR<WorkoutPlanCreateWithoutEquipmentInput, WorkoutPlanUncheckedCreateWithoutEquipmentInput> | WorkoutPlanCreateWithoutEquipmentInput[] | WorkoutPlanUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutEquipmentInput | WorkoutPlanCreateOrConnectWithoutEquipmentInput[]
    createMany?: WorkoutPlanCreateManyEquipmentInputEnvelope
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
  }

  export type UserEquipmentUpdateManyWithoutEquipmentNestedInput = {
    create?: XOR<UserEquipmentCreateWithoutEquipmentInput, UserEquipmentUncheckedCreateWithoutEquipmentInput> | UserEquipmentCreateWithoutEquipmentInput[] | UserEquipmentUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutEquipmentInput | UserEquipmentCreateOrConnectWithoutEquipmentInput[]
    upsert?: UserEquipmentUpsertWithWhereUniqueWithoutEquipmentInput | UserEquipmentUpsertWithWhereUniqueWithoutEquipmentInput[]
    createMany?: UserEquipmentCreateManyEquipmentInputEnvelope
    set?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    disconnect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    delete?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    update?: UserEquipmentUpdateWithWhereUniqueWithoutEquipmentInput | UserEquipmentUpdateWithWhereUniqueWithoutEquipmentInput[]
    updateMany?: UserEquipmentUpdateManyWithWhereWithoutEquipmentInput | UserEquipmentUpdateManyWithWhereWithoutEquipmentInput[]
    deleteMany?: UserEquipmentScalarWhereInput | UserEquipmentScalarWhereInput[]
  }

  export type ExerciseUpdateManyWithoutEquipmentNestedInput = {
    create?: XOR<ExerciseCreateWithoutEquipmentInput, ExerciseUncheckedCreateWithoutEquipmentInput> | ExerciseCreateWithoutEquipmentInput[] | ExerciseUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: ExerciseCreateOrConnectWithoutEquipmentInput | ExerciseCreateOrConnectWithoutEquipmentInput[]
    upsert?: ExerciseUpsertWithWhereUniqueWithoutEquipmentInput | ExerciseUpsertWithWhereUniqueWithoutEquipmentInput[]
    createMany?: ExerciseCreateManyEquipmentInputEnvelope
    set?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    disconnect?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    delete?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    connect?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    update?: ExerciseUpdateWithWhereUniqueWithoutEquipmentInput | ExerciseUpdateWithWhereUniqueWithoutEquipmentInput[]
    updateMany?: ExerciseUpdateManyWithWhereWithoutEquipmentInput | ExerciseUpdateManyWithWhereWithoutEquipmentInput[]
    deleteMany?: ExerciseScalarWhereInput | ExerciseScalarWhereInput[]
  }

  export type WorkoutPlanUpdateManyWithoutEquipmentNestedInput = {
    create?: XOR<WorkoutPlanCreateWithoutEquipmentInput, WorkoutPlanUncheckedCreateWithoutEquipmentInput> | WorkoutPlanCreateWithoutEquipmentInput[] | WorkoutPlanUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutEquipmentInput | WorkoutPlanCreateOrConnectWithoutEquipmentInput[]
    upsert?: WorkoutPlanUpsertWithWhereUniqueWithoutEquipmentInput | WorkoutPlanUpsertWithWhereUniqueWithoutEquipmentInput[]
    createMany?: WorkoutPlanCreateManyEquipmentInputEnvelope
    set?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    disconnect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    delete?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    update?: WorkoutPlanUpdateWithWhereUniqueWithoutEquipmentInput | WorkoutPlanUpdateWithWhereUniqueWithoutEquipmentInput[]
    updateMany?: WorkoutPlanUpdateManyWithWhereWithoutEquipmentInput | WorkoutPlanUpdateManyWithWhereWithoutEquipmentInput[]
    deleteMany?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
  }

  export type UserEquipmentUncheckedUpdateManyWithoutEquipmentNestedInput = {
    create?: XOR<UserEquipmentCreateWithoutEquipmentInput, UserEquipmentUncheckedCreateWithoutEquipmentInput> | UserEquipmentCreateWithoutEquipmentInput[] | UserEquipmentUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: UserEquipmentCreateOrConnectWithoutEquipmentInput | UserEquipmentCreateOrConnectWithoutEquipmentInput[]
    upsert?: UserEquipmentUpsertWithWhereUniqueWithoutEquipmentInput | UserEquipmentUpsertWithWhereUniqueWithoutEquipmentInput[]
    createMany?: UserEquipmentCreateManyEquipmentInputEnvelope
    set?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    disconnect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    delete?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    connect?: UserEquipmentWhereUniqueInput | UserEquipmentWhereUniqueInput[]
    update?: UserEquipmentUpdateWithWhereUniqueWithoutEquipmentInput | UserEquipmentUpdateWithWhereUniqueWithoutEquipmentInput[]
    updateMany?: UserEquipmentUpdateManyWithWhereWithoutEquipmentInput | UserEquipmentUpdateManyWithWhereWithoutEquipmentInput[]
    deleteMany?: UserEquipmentScalarWhereInput | UserEquipmentScalarWhereInput[]
  }

  export type ExerciseUncheckedUpdateManyWithoutEquipmentNestedInput = {
    create?: XOR<ExerciseCreateWithoutEquipmentInput, ExerciseUncheckedCreateWithoutEquipmentInput> | ExerciseCreateWithoutEquipmentInput[] | ExerciseUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: ExerciseCreateOrConnectWithoutEquipmentInput | ExerciseCreateOrConnectWithoutEquipmentInput[]
    upsert?: ExerciseUpsertWithWhereUniqueWithoutEquipmentInput | ExerciseUpsertWithWhereUniqueWithoutEquipmentInput[]
    createMany?: ExerciseCreateManyEquipmentInputEnvelope
    set?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    disconnect?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    delete?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    connect?: ExerciseWhereUniqueInput | ExerciseWhereUniqueInput[]
    update?: ExerciseUpdateWithWhereUniqueWithoutEquipmentInput | ExerciseUpdateWithWhereUniqueWithoutEquipmentInput[]
    updateMany?: ExerciseUpdateManyWithWhereWithoutEquipmentInput | ExerciseUpdateManyWithWhereWithoutEquipmentInput[]
    deleteMany?: ExerciseScalarWhereInput | ExerciseScalarWhereInput[]
  }

  export type WorkoutPlanUncheckedUpdateManyWithoutEquipmentNestedInput = {
    create?: XOR<WorkoutPlanCreateWithoutEquipmentInput, WorkoutPlanUncheckedCreateWithoutEquipmentInput> | WorkoutPlanCreateWithoutEquipmentInput[] | WorkoutPlanUncheckedCreateWithoutEquipmentInput[]
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutEquipmentInput | WorkoutPlanCreateOrConnectWithoutEquipmentInput[]
    upsert?: WorkoutPlanUpsertWithWhereUniqueWithoutEquipmentInput | WorkoutPlanUpsertWithWhereUniqueWithoutEquipmentInput[]
    createMany?: WorkoutPlanCreateManyEquipmentInputEnvelope
    set?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    disconnect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    delete?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    connect?: WorkoutPlanWhereUniqueInput | WorkoutPlanWhereUniqueInput[]
    update?: WorkoutPlanUpdateWithWhereUniqueWithoutEquipmentInput | WorkoutPlanUpdateWithWhereUniqueWithoutEquipmentInput[]
    updateMany?: WorkoutPlanUpdateManyWithWhereWithoutEquipmentInput | WorkoutPlanUpdateManyWithWhereWithoutEquipmentInput[]
    deleteMany?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
  }

  export type ExerciseCreatemusclesWorkedInput = {
    set: string[]
  }

  export type EquipmentCreateNestedOneWithoutExercisesInput = {
    create?: XOR<EquipmentCreateWithoutExercisesInput, EquipmentUncheckedCreateWithoutExercisesInput>
    connectOrCreate?: EquipmentCreateOrConnectWithoutExercisesInput
    connect?: EquipmentWhereUniqueInput
  }

  export type PlannedExerciseCreateNestedManyWithoutExerciseInput = {
    create?: XOR<PlannedExerciseCreateWithoutExerciseInput, PlannedExerciseUncheckedCreateWithoutExerciseInput> | PlannedExerciseCreateWithoutExerciseInput[] | PlannedExerciseUncheckedCreateWithoutExerciseInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutExerciseInput | PlannedExerciseCreateOrConnectWithoutExerciseInput[]
    createMany?: PlannedExerciseCreateManyExerciseInputEnvelope
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
  }

  export type PlannedExerciseUncheckedCreateNestedManyWithoutExerciseInput = {
    create?: XOR<PlannedExerciseCreateWithoutExerciseInput, PlannedExerciseUncheckedCreateWithoutExerciseInput> | PlannedExerciseCreateWithoutExerciseInput[] | PlannedExerciseUncheckedCreateWithoutExerciseInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutExerciseInput | PlannedExerciseCreateOrConnectWithoutExerciseInput[]
    createMany?: PlannedExerciseCreateManyExerciseInputEnvelope
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
  }

  export type ExerciseUpdatemusclesWorkedInput = {
    set?: string[]
    push?: string | string[]
  }

  export type EnumMuscleGroupFieldUpdateOperationsInput = {
    set?: $Enums.MuscleGroup
  }

  export type EquipmentUpdateOneWithoutExercisesNestedInput = {
    create?: XOR<EquipmentCreateWithoutExercisesInput, EquipmentUncheckedCreateWithoutExercisesInput>
    connectOrCreate?: EquipmentCreateOrConnectWithoutExercisesInput
    upsert?: EquipmentUpsertWithoutExercisesInput
    disconnect?: EquipmentWhereInput | boolean
    delete?: EquipmentWhereInput | boolean
    connect?: EquipmentWhereUniqueInput
    update?: XOR<XOR<EquipmentUpdateToOneWithWhereWithoutExercisesInput, EquipmentUpdateWithoutExercisesInput>, EquipmentUncheckedUpdateWithoutExercisesInput>
  }

  export type PlannedExerciseUpdateManyWithoutExerciseNestedInput = {
    create?: XOR<PlannedExerciseCreateWithoutExerciseInput, PlannedExerciseUncheckedCreateWithoutExerciseInput> | PlannedExerciseCreateWithoutExerciseInput[] | PlannedExerciseUncheckedCreateWithoutExerciseInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutExerciseInput | PlannedExerciseCreateOrConnectWithoutExerciseInput[]
    upsert?: PlannedExerciseUpsertWithWhereUniqueWithoutExerciseInput | PlannedExerciseUpsertWithWhereUniqueWithoutExerciseInput[]
    createMany?: PlannedExerciseCreateManyExerciseInputEnvelope
    set?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    disconnect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    delete?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    update?: PlannedExerciseUpdateWithWhereUniqueWithoutExerciseInput | PlannedExerciseUpdateWithWhereUniqueWithoutExerciseInput[]
    updateMany?: PlannedExerciseUpdateManyWithWhereWithoutExerciseInput | PlannedExerciseUpdateManyWithWhereWithoutExerciseInput[]
    deleteMany?: PlannedExerciseScalarWhereInput | PlannedExerciseScalarWhereInput[]
  }

  export type PlannedExerciseUncheckedUpdateManyWithoutExerciseNestedInput = {
    create?: XOR<PlannedExerciseCreateWithoutExerciseInput, PlannedExerciseUncheckedCreateWithoutExerciseInput> | PlannedExerciseCreateWithoutExerciseInput[] | PlannedExerciseUncheckedCreateWithoutExerciseInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutExerciseInput | PlannedExerciseCreateOrConnectWithoutExerciseInput[]
    upsert?: PlannedExerciseUpsertWithWhereUniqueWithoutExerciseInput | PlannedExerciseUpsertWithWhereUniqueWithoutExerciseInput[]
    createMany?: PlannedExerciseCreateManyExerciseInputEnvelope
    set?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    disconnect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    delete?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    update?: PlannedExerciseUpdateWithWhereUniqueWithoutExerciseInput | PlannedExerciseUpdateWithWhereUniqueWithoutExerciseInput[]
    updateMany?: PlannedExerciseUpdateManyWithWhereWithoutExerciseInput | PlannedExerciseUpdateManyWithWhereWithoutExerciseInput[]
    deleteMany?: PlannedExerciseScalarWhereInput | PlannedExerciseScalarWhereInput[]
  }

  export type EquipmentCreateNestedOneWithoutWorkoutPlansInput = {
    create?: XOR<EquipmentCreateWithoutWorkoutPlansInput, EquipmentUncheckedCreateWithoutWorkoutPlansInput>
    connectOrCreate?: EquipmentCreateOrConnectWithoutWorkoutPlansInput
    connect?: EquipmentWhereUniqueInput
  }

  export type PlannedSessionCreateNestedManyWithoutPlanInput = {
    create?: XOR<PlannedSessionCreateWithoutPlanInput, PlannedSessionUncheckedCreateWithoutPlanInput> | PlannedSessionCreateWithoutPlanInput[] | PlannedSessionUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlannedSessionCreateOrConnectWithoutPlanInput | PlannedSessionCreateOrConnectWithoutPlanInput[]
    createMany?: PlannedSessionCreateManyPlanInputEnvelope
    connect?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
  }

  export type PlanInstanceCreateNestedManyWithoutPlanInput = {
    create?: XOR<PlanInstanceCreateWithoutPlanInput, PlanInstanceUncheckedCreateWithoutPlanInput> | PlanInstanceCreateWithoutPlanInput[] | PlanInstanceUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutPlanInput | PlanInstanceCreateOrConnectWithoutPlanInput[]
    createMany?: PlanInstanceCreateManyPlanInputEnvelope
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
  }

  export type PlannedSessionUncheckedCreateNestedManyWithoutPlanInput = {
    create?: XOR<PlannedSessionCreateWithoutPlanInput, PlannedSessionUncheckedCreateWithoutPlanInput> | PlannedSessionCreateWithoutPlanInput[] | PlannedSessionUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlannedSessionCreateOrConnectWithoutPlanInput | PlannedSessionCreateOrConnectWithoutPlanInput[]
    createMany?: PlannedSessionCreateManyPlanInputEnvelope
    connect?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
  }

  export type PlanInstanceUncheckedCreateNestedManyWithoutPlanInput = {
    create?: XOR<PlanInstanceCreateWithoutPlanInput, PlanInstanceUncheckedCreateWithoutPlanInput> | PlanInstanceCreateWithoutPlanInput[] | PlanInstanceUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutPlanInput | PlanInstanceCreateOrConnectWithoutPlanInput[]
    createMany?: PlanInstanceCreateManyPlanInputEnvelope
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EnumPlanTierFieldUpdateOperationsInput = {
    set?: $Enums.PlanTier
  }

  export type EquipmentUpdateOneWithoutWorkoutPlansNestedInput = {
    create?: XOR<EquipmentCreateWithoutWorkoutPlansInput, EquipmentUncheckedCreateWithoutWorkoutPlansInput>
    connectOrCreate?: EquipmentCreateOrConnectWithoutWorkoutPlansInput
    upsert?: EquipmentUpsertWithoutWorkoutPlansInput
    disconnect?: EquipmentWhereInput | boolean
    delete?: EquipmentWhereInput | boolean
    connect?: EquipmentWhereUniqueInput
    update?: XOR<XOR<EquipmentUpdateToOneWithWhereWithoutWorkoutPlansInput, EquipmentUpdateWithoutWorkoutPlansInput>, EquipmentUncheckedUpdateWithoutWorkoutPlansInput>
  }

  export type PlannedSessionUpdateManyWithoutPlanNestedInput = {
    create?: XOR<PlannedSessionCreateWithoutPlanInput, PlannedSessionUncheckedCreateWithoutPlanInput> | PlannedSessionCreateWithoutPlanInput[] | PlannedSessionUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlannedSessionCreateOrConnectWithoutPlanInput | PlannedSessionCreateOrConnectWithoutPlanInput[]
    upsert?: PlannedSessionUpsertWithWhereUniqueWithoutPlanInput | PlannedSessionUpsertWithWhereUniqueWithoutPlanInput[]
    createMany?: PlannedSessionCreateManyPlanInputEnvelope
    set?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    disconnect?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    delete?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    connect?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    update?: PlannedSessionUpdateWithWhereUniqueWithoutPlanInput | PlannedSessionUpdateWithWhereUniqueWithoutPlanInput[]
    updateMany?: PlannedSessionUpdateManyWithWhereWithoutPlanInput | PlannedSessionUpdateManyWithWhereWithoutPlanInput[]
    deleteMany?: PlannedSessionScalarWhereInput | PlannedSessionScalarWhereInput[]
  }

  export type PlanInstanceUpdateManyWithoutPlanNestedInput = {
    create?: XOR<PlanInstanceCreateWithoutPlanInput, PlanInstanceUncheckedCreateWithoutPlanInput> | PlanInstanceCreateWithoutPlanInput[] | PlanInstanceUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutPlanInput | PlanInstanceCreateOrConnectWithoutPlanInput[]
    upsert?: PlanInstanceUpsertWithWhereUniqueWithoutPlanInput | PlanInstanceUpsertWithWhereUniqueWithoutPlanInput[]
    createMany?: PlanInstanceCreateManyPlanInputEnvelope
    set?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    disconnect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    delete?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    update?: PlanInstanceUpdateWithWhereUniqueWithoutPlanInput | PlanInstanceUpdateWithWhereUniqueWithoutPlanInput[]
    updateMany?: PlanInstanceUpdateManyWithWhereWithoutPlanInput | PlanInstanceUpdateManyWithWhereWithoutPlanInput[]
    deleteMany?: PlanInstanceScalarWhereInput | PlanInstanceScalarWhereInput[]
  }

  export type PlannedSessionUncheckedUpdateManyWithoutPlanNestedInput = {
    create?: XOR<PlannedSessionCreateWithoutPlanInput, PlannedSessionUncheckedCreateWithoutPlanInput> | PlannedSessionCreateWithoutPlanInput[] | PlannedSessionUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlannedSessionCreateOrConnectWithoutPlanInput | PlannedSessionCreateOrConnectWithoutPlanInput[]
    upsert?: PlannedSessionUpsertWithWhereUniqueWithoutPlanInput | PlannedSessionUpsertWithWhereUniqueWithoutPlanInput[]
    createMany?: PlannedSessionCreateManyPlanInputEnvelope
    set?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    disconnect?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    delete?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    connect?: PlannedSessionWhereUniqueInput | PlannedSessionWhereUniqueInput[]
    update?: PlannedSessionUpdateWithWhereUniqueWithoutPlanInput | PlannedSessionUpdateWithWhereUniqueWithoutPlanInput[]
    updateMany?: PlannedSessionUpdateManyWithWhereWithoutPlanInput | PlannedSessionUpdateManyWithWhereWithoutPlanInput[]
    deleteMany?: PlannedSessionScalarWhereInput | PlannedSessionScalarWhereInput[]
  }

  export type PlanInstanceUncheckedUpdateManyWithoutPlanNestedInput = {
    create?: XOR<PlanInstanceCreateWithoutPlanInput, PlanInstanceUncheckedCreateWithoutPlanInput> | PlanInstanceCreateWithoutPlanInput[] | PlanInstanceUncheckedCreateWithoutPlanInput[]
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutPlanInput | PlanInstanceCreateOrConnectWithoutPlanInput[]
    upsert?: PlanInstanceUpsertWithWhereUniqueWithoutPlanInput | PlanInstanceUpsertWithWhereUniqueWithoutPlanInput[]
    createMany?: PlanInstanceCreateManyPlanInputEnvelope
    set?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    disconnect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    delete?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    connect?: PlanInstanceWhereUniqueInput | PlanInstanceWhereUniqueInput[]
    update?: PlanInstanceUpdateWithWhereUniqueWithoutPlanInput | PlanInstanceUpdateWithWhereUniqueWithoutPlanInput[]
    updateMany?: PlanInstanceUpdateManyWithWhereWithoutPlanInput | PlanInstanceUpdateManyWithWhereWithoutPlanInput[]
    deleteMany?: PlanInstanceScalarWhereInput | PlanInstanceScalarWhereInput[]
  }

  export type WorkoutPlanCreateNestedOneWithoutPlannedSessionsInput = {
    create?: XOR<WorkoutPlanCreateWithoutPlannedSessionsInput, WorkoutPlanUncheckedCreateWithoutPlannedSessionsInput>
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutPlannedSessionsInput
    connect?: WorkoutPlanWhereUniqueInput
  }

  export type PlannedExerciseCreateNestedManyWithoutSessionInput = {
    create?: XOR<PlannedExerciseCreateWithoutSessionInput, PlannedExerciseUncheckedCreateWithoutSessionInput> | PlannedExerciseCreateWithoutSessionInput[] | PlannedExerciseUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutSessionInput | PlannedExerciseCreateOrConnectWithoutSessionInput[]
    createMany?: PlannedExerciseCreateManySessionInputEnvelope
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
  }

  export type PlannedExerciseUncheckedCreateNestedManyWithoutSessionInput = {
    create?: XOR<PlannedExerciseCreateWithoutSessionInput, PlannedExerciseUncheckedCreateWithoutSessionInput> | PlannedExerciseCreateWithoutSessionInput[] | PlannedExerciseUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutSessionInput | PlannedExerciseCreateOrConnectWithoutSessionInput[]
    createMany?: PlannedExerciseCreateManySessionInputEnvelope
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
  }

  export type WorkoutPlanUpdateOneRequiredWithoutPlannedSessionsNestedInput = {
    create?: XOR<WorkoutPlanCreateWithoutPlannedSessionsInput, WorkoutPlanUncheckedCreateWithoutPlannedSessionsInput>
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutPlannedSessionsInput
    upsert?: WorkoutPlanUpsertWithoutPlannedSessionsInput
    connect?: WorkoutPlanWhereUniqueInput
    update?: XOR<XOR<WorkoutPlanUpdateToOneWithWhereWithoutPlannedSessionsInput, WorkoutPlanUpdateWithoutPlannedSessionsInput>, WorkoutPlanUncheckedUpdateWithoutPlannedSessionsInput>
  }

  export type PlannedExerciseUpdateManyWithoutSessionNestedInput = {
    create?: XOR<PlannedExerciseCreateWithoutSessionInput, PlannedExerciseUncheckedCreateWithoutSessionInput> | PlannedExerciseCreateWithoutSessionInput[] | PlannedExerciseUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutSessionInput | PlannedExerciseCreateOrConnectWithoutSessionInput[]
    upsert?: PlannedExerciseUpsertWithWhereUniqueWithoutSessionInput | PlannedExerciseUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: PlannedExerciseCreateManySessionInputEnvelope
    set?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    disconnect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    delete?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    update?: PlannedExerciseUpdateWithWhereUniqueWithoutSessionInput | PlannedExerciseUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: PlannedExerciseUpdateManyWithWhereWithoutSessionInput | PlannedExerciseUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: PlannedExerciseScalarWhereInput | PlannedExerciseScalarWhereInput[]
  }

  export type PlannedExerciseUncheckedUpdateManyWithoutSessionNestedInput = {
    create?: XOR<PlannedExerciseCreateWithoutSessionInput, PlannedExerciseUncheckedCreateWithoutSessionInput> | PlannedExerciseCreateWithoutSessionInput[] | PlannedExerciseUncheckedCreateWithoutSessionInput[]
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutSessionInput | PlannedExerciseCreateOrConnectWithoutSessionInput[]
    upsert?: PlannedExerciseUpsertWithWhereUniqueWithoutSessionInput | PlannedExerciseUpsertWithWhereUniqueWithoutSessionInput[]
    createMany?: PlannedExerciseCreateManySessionInputEnvelope
    set?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    disconnect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    delete?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    connect?: PlannedExerciseWhereUniqueInput | PlannedExerciseWhereUniqueInput[]
    update?: PlannedExerciseUpdateWithWhereUniqueWithoutSessionInput | PlannedExerciseUpdateWithWhereUniqueWithoutSessionInput[]
    updateMany?: PlannedExerciseUpdateManyWithWhereWithoutSessionInput | PlannedExerciseUpdateManyWithWhereWithoutSessionInput[]
    deleteMany?: PlannedExerciseScalarWhereInput | PlannedExerciseScalarWhereInput[]
  }

  export type PlannedSessionCreateNestedOneWithoutPlannedExercisesInput = {
    create?: XOR<PlannedSessionCreateWithoutPlannedExercisesInput, PlannedSessionUncheckedCreateWithoutPlannedExercisesInput>
    connectOrCreate?: PlannedSessionCreateOrConnectWithoutPlannedExercisesInput
    connect?: PlannedSessionWhereUniqueInput
  }

  export type ExerciseCreateNestedOneWithoutPlannedExercisesInput = {
    create?: XOR<ExerciseCreateWithoutPlannedExercisesInput, ExerciseUncheckedCreateWithoutPlannedExercisesInput>
    connectOrCreate?: ExerciseCreateOrConnectWithoutPlannedExercisesInput
    connect?: ExerciseWhereUniqueInput
  }

  export type WorkoutLogCreateNestedManyWithoutPlannedExerciseInput = {
    create?: XOR<WorkoutLogCreateWithoutPlannedExerciseInput, WorkoutLogUncheckedCreateWithoutPlannedExerciseInput> | WorkoutLogCreateWithoutPlannedExerciseInput[] | WorkoutLogUncheckedCreateWithoutPlannedExerciseInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutPlannedExerciseInput | WorkoutLogCreateOrConnectWithoutPlannedExerciseInput[]
    createMany?: WorkoutLogCreateManyPlannedExerciseInputEnvelope
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
  }

  export type WorkoutLogUncheckedCreateNestedManyWithoutPlannedExerciseInput = {
    create?: XOR<WorkoutLogCreateWithoutPlannedExerciseInput, WorkoutLogUncheckedCreateWithoutPlannedExerciseInput> | WorkoutLogCreateWithoutPlannedExerciseInput[] | WorkoutLogUncheckedCreateWithoutPlannedExerciseInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutPlannedExerciseInput | WorkoutLogCreateOrConnectWithoutPlannedExerciseInput[]
    createMany?: WorkoutLogCreateManyPlannedExerciseInputEnvelope
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
  }

  export type PlannedSessionUpdateOneRequiredWithoutPlannedExercisesNestedInput = {
    create?: XOR<PlannedSessionCreateWithoutPlannedExercisesInput, PlannedSessionUncheckedCreateWithoutPlannedExercisesInput>
    connectOrCreate?: PlannedSessionCreateOrConnectWithoutPlannedExercisesInput
    upsert?: PlannedSessionUpsertWithoutPlannedExercisesInput
    connect?: PlannedSessionWhereUniqueInput
    update?: XOR<XOR<PlannedSessionUpdateToOneWithWhereWithoutPlannedExercisesInput, PlannedSessionUpdateWithoutPlannedExercisesInput>, PlannedSessionUncheckedUpdateWithoutPlannedExercisesInput>
  }

  export type ExerciseUpdateOneRequiredWithoutPlannedExercisesNestedInput = {
    create?: XOR<ExerciseCreateWithoutPlannedExercisesInput, ExerciseUncheckedCreateWithoutPlannedExercisesInput>
    connectOrCreate?: ExerciseCreateOrConnectWithoutPlannedExercisesInput
    upsert?: ExerciseUpsertWithoutPlannedExercisesInput
    connect?: ExerciseWhereUniqueInput
    update?: XOR<XOR<ExerciseUpdateToOneWithWhereWithoutPlannedExercisesInput, ExerciseUpdateWithoutPlannedExercisesInput>, ExerciseUncheckedUpdateWithoutPlannedExercisesInput>
  }

  export type WorkoutLogUpdateManyWithoutPlannedExerciseNestedInput = {
    create?: XOR<WorkoutLogCreateWithoutPlannedExerciseInput, WorkoutLogUncheckedCreateWithoutPlannedExerciseInput> | WorkoutLogCreateWithoutPlannedExerciseInput[] | WorkoutLogUncheckedCreateWithoutPlannedExerciseInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutPlannedExerciseInput | WorkoutLogCreateOrConnectWithoutPlannedExerciseInput[]
    upsert?: WorkoutLogUpsertWithWhereUniqueWithoutPlannedExerciseInput | WorkoutLogUpsertWithWhereUniqueWithoutPlannedExerciseInput[]
    createMany?: WorkoutLogCreateManyPlannedExerciseInputEnvelope
    set?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    disconnect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    delete?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    update?: WorkoutLogUpdateWithWhereUniqueWithoutPlannedExerciseInput | WorkoutLogUpdateWithWhereUniqueWithoutPlannedExerciseInput[]
    updateMany?: WorkoutLogUpdateManyWithWhereWithoutPlannedExerciseInput | WorkoutLogUpdateManyWithWhereWithoutPlannedExerciseInput[]
    deleteMany?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
  }

  export type WorkoutLogUncheckedUpdateManyWithoutPlannedExerciseNestedInput = {
    create?: XOR<WorkoutLogCreateWithoutPlannedExerciseInput, WorkoutLogUncheckedCreateWithoutPlannedExerciseInput> | WorkoutLogCreateWithoutPlannedExerciseInput[] | WorkoutLogUncheckedCreateWithoutPlannedExerciseInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutPlannedExerciseInput | WorkoutLogCreateOrConnectWithoutPlannedExerciseInput[]
    upsert?: WorkoutLogUpsertWithWhereUniqueWithoutPlannedExerciseInput | WorkoutLogUpsertWithWhereUniqueWithoutPlannedExerciseInput[]
    createMany?: WorkoutLogCreateManyPlannedExerciseInputEnvelope
    set?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    disconnect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    delete?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    update?: WorkoutLogUpdateWithWhereUniqueWithoutPlannedExerciseInput | WorkoutLogUpdateWithWhereUniqueWithoutPlannedExerciseInput[]
    updateMany?: WorkoutLogUpdateManyWithWhereWithoutPlannedExerciseInput | WorkoutLogUpdateManyWithWhereWithoutPlannedExerciseInput[]
    deleteMany?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutInstancesInput = {
    create?: XOR<UserCreateWithoutInstancesInput, UserUncheckedCreateWithoutInstancesInput>
    connectOrCreate?: UserCreateOrConnectWithoutInstancesInput
    connect?: UserWhereUniqueInput
  }

  export type WorkoutPlanCreateNestedOneWithoutInstancesInput = {
    create?: XOR<WorkoutPlanCreateWithoutInstancesInput, WorkoutPlanUncheckedCreateWithoutInstancesInput>
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutInstancesInput
    connect?: WorkoutPlanWhereUniqueInput
  }

  export type WorkoutLogCreateNestedManyWithoutInstanceInput = {
    create?: XOR<WorkoutLogCreateWithoutInstanceInput, WorkoutLogUncheckedCreateWithoutInstanceInput> | WorkoutLogCreateWithoutInstanceInput[] | WorkoutLogUncheckedCreateWithoutInstanceInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutInstanceInput | WorkoutLogCreateOrConnectWithoutInstanceInput[]
    createMany?: WorkoutLogCreateManyInstanceInputEnvelope
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
  }

  export type WorkoutLogUncheckedCreateNestedManyWithoutInstanceInput = {
    create?: XOR<WorkoutLogCreateWithoutInstanceInput, WorkoutLogUncheckedCreateWithoutInstanceInput> | WorkoutLogCreateWithoutInstanceInput[] | WorkoutLogUncheckedCreateWithoutInstanceInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutInstanceInput | WorkoutLogCreateOrConnectWithoutInstanceInput[]
    createMany?: WorkoutLogCreateManyInstanceInputEnvelope
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
  }

  export type EnumUserLevelFieldUpdateOperationsInput = {
    set?: $Enums.UserLevel
  }

  export type EnumInstanceStatusFieldUpdateOperationsInput = {
    set?: $Enums.InstanceStatus
  }

  export type UserUpdateOneRequiredWithoutInstancesNestedInput = {
    create?: XOR<UserCreateWithoutInstancesInput, UserUncheckedCreateWithoutInstancesInput>
    connectOrCreate?: UserCreateOrConnectWithoutInstancesInput
    upsert?: UserUpsertWithoutInstancesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutInstancesInput, UserUpdateWithoutInstancesInput>, UserUncheckedUpdateWithoutInstancesInput>
  }

  export type WorkoutPlanUpdateOneRequiredWithoutInstancesNestedInput = {
    create?: XOR<WorkoutPlanCreateWithoutInstancesInput, WorkoutPlanUncheckedCreateWithoutInstancesInput>
    connectOrCreate?: WorkoutPlanCreateOrConnectWithoutInstancesInput
    upsert?: WorkoutPlanUpsertWithoutInstancesInput
    connect?: WorkoutPlanWhereUniqueInput
    update?: XOR<XOR<WorkoutPlanUpdateToOneWithWhereWithoutInstancesInput, WorkoutPlanUpdateWithoutInstancesInput>, WorkoutPlanUncheckedUpdateWithoutInstancesInput>
  }

  export type WorkoutLogUpdateManyWithoutInstanceNestedInput = {
    create?: XOR<WorkoutLogCreateWithoutInstanceInput, WorkoutLogUncheckedCreateWithoutInstanceInput> | WorkoutLogCreateWithoutInstanceInput[] | WorkoutLogUncheckedCreateWithoutInstanceInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutInstanceInput | WorkoutLogCreateOrConnectWithoutInstanceInput[]
    upsert?: WorkoutLogUpsertWithWhereUniqueWithoutInstanceInput | WorkoutLogUpsertWithWhereUniqueWithoutInstanceInput[]
    createMany?: WorkoutLogCreateManyInstanceInputEnvelope
    set?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    disconnect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    delete?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    update?: WorkoutLogUpdateWithWhereUniqueWithoutInstanceInput | WorkoutLogUpdateWithWhereUniqueWithoutInstanceInput[]
    updateMany?: WorkoutLogUpdateManyWithWhereWithoutInstanceInput | WorkoutLogUpdateManyWithWhereWithoutInstanceInput[]
    deleteMany?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
  }

  export type WorkoutLogUncheckedUpdateManyWithoutInstanceNestedInput = {
    create?: XOR<WorkoutLogCreateWithoutInstanceInput, WorkoutLogUncheckedCreateWithoutInstanceInput> | WorkoutLogCreateWithoutInstanceInput[] | WorkoutLogUncheckedCreateWithoutInstanceInput[]
    connectOrCreate?: WorkoutLogCreateOrConnectWithoutInstanceInput | WorkoutLogCreateOrConnectWithoutInstanceInput[]
    upsert?: WorkoutLogUpsertWithWhereUniqueWithoutInstanceInput | WorkoutLogUpsertWithWhereUniqueWithoutInstanceInput[]
    createMany?: WorkoutLogCreateManyInstanceInputEnvelope
    set?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    disconnect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    delete?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    connect?: WorkoutLogWhereUniqueInput | WorkoutLogWhereUniqueInput[]
    update?: WorkoutLogUpdateWithWhereUniqueWithoutInstanceInput | WorkoutLogUpdateWithWhereUniqueWithoutInstanceInput[]
    updateMany?: WorkoutLogUpdateManyWithWhereWithoutInstanceInput | WorkoutLogUpdateManyWithWhereWithoutInstanceInput[]
    deleteMany?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutWorkoutLogsInput = {
    create?: XOR<UserCreateWithoutWorkoutLogsInput, UserUncheckedCreateWithoutWorkoutLogsInput>
    connectOrCreate?: UserCreateOrConnectWithoutWorkoutLogsInput
    connect?: UserWhereUniqueInput
  }

  export type PlanInstanceCreateNestedOneWithoutWorkoutLogsInput = {
    create?: XOR<PlanInstanceCreateWithoutWorkoutLogsInput, PlanInstanceUncheckedCreateWithoutWorkoutLogsInput>
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutWorkoutLogsInput
    connect?: PlanInstanceWhereUniqueInput
  }

  export type PlannedExerciseCreateNestedOneWithoutLoggedSetsInput = {
    create?: XOR<PlannedExerciseCreateWithoutLoggedSetsInput, PlannedExerciseUncheckedCreateWithoutLoggedSetsInput>
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutLoggedSetsInput
    connect?: PlannedExerciseWhereUniqueInput
  }

  export type NullableFloatFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type UserUpdateOneRequiredWithoutWorkoutLogsNestedInput = {
    create?: XOR<UserCreateWithoutWorkoutLogsInput, UserUncheckedCreateWithoutWorkoutLogsInput>
    connectOrCreate?: UserCreateOrConnectWithoutWorkoutLogsInput
    upsert?: UserUpsertWithoutWorkoutLogsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutWorkoutLogsInput, UserUpdateWithoutWorkoutLogsInput>, UserUncheckedUpdateWithoutWorkoutLogsInput>
  }

  export type PlanInstanceUpdateOneRequiredWithoutWorkoutLogsNestedInput = {
    create?: XOR<PlanInstanceCreateWithoutWorkoutLogsInput, PlanInstanceUncheckedCreateWithoutWorkoutLogsInput>
    connectOrCreate?: PlanInstanceCreateOrConnectWithoutWorkoutLogsInput
    upsert?: PlanInstanceUpsertWithoutWorkoutLogsInput
    connect?: PlanInstanceWhereUniqueInput
    update?: XOR<XOR<PlanInstanceUpdateToOneWithWhereWithoutWorkoutLogsInput, PlanInstanceUpdateWithoutWorkoutLogsInput>, PlanInstanceUncheckedUpdateWithoutWorkoutLogsInput>
  }

  export type PlannedExerciseUpdateOneRequiredWithoutLoggedSetsNestedInput = {
    create?: XOR<PlannedExerciseCreateWithoutLoggedSetsInput, PlannedExerciseUncheckedCreateWithoutLoggedSetsInput>
    connectOrCreate?: PlannedExerciseCreateOrConnectWithoutLoggedSetsInput
    upsert?: PlannedExerciseUpsertWithoutLoggedSetsInput
    connect?: PlannedExerciseWhereUniqueInput
    update?: XOR<XOR<PlannedExerciseUpdateToOneWithWhereWithoutLoggedSetsInput, PlannedExerciseUpdateWithoutLoggedSetsInput>, PlannedExerciseUncheckedUpdateWithoutLoggedSetsInput>
  }

  export type UserCreateNestedOneWithoutSubscriptionInput = {
    create?: XOR<UserCreateWithoutSubscriptionInput, UserUncheckedCreateWithoutSubscriptionInput>
    connectOrCreate?: UserCreateOrConnectWithoutSubscriptionInput
    connect?: UserWhereUniqueInput
  }

  export type EnumPlanFieldUpdateOperationsInput = {
    set?: $Enums.Plan
  }

  export type UserUpdateOneRequiredWithoutSubscriptionNestedInput = {
    create?: XOR<UserCreateWithoutSubscriptionInput, UserUncheckedCreateWithoutSubscriptionInput>
    connectOrCreate?: UserCreateOrConnectWithoutSubscriptionInput
    upsert?: UserUpsertWithoutSubscriptionInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutSubscriptionInput, UserUpdateWithoutSubscriptionInput>, UserUncheckedUpdateWithoutSubscriptionInput>
  }

  export type UserCreateNestedOneWithoutUserEquipmentInput = {
    create?: XOR<UserCreateWithoutUserEquipmentInput, UserUncheckedCreateWithoutUserEquipmentInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserEquipmentInput
    connect?: UserWhereUniqueInput
  }

  export type EquipmentCreateNestedOneWithoutUserEquipmentInput = {
    create?: XOR<EquipmentCreateWithoutUserEquipmentInput, EquipmentUncheckedCreateWithoutUserEquipmentInput>
    connectOrCreate?: EquipmentCreateOrConnectWithoutUserEquipmentInput
    connect?: EquipmentWhereUniqueInput
  }

  export type EnumEquipmentSourceFieldUpdateOperationsInput = {
    set?: $Enums.EquipmentSource
  }

  export type UserUpdateOneRequiredWithoutUserEquipmentNestedInput = {
    create?: XOR<UserCreateWithoutUserEquipmentInput, UserUncheckedCreateWithoutUserEquipmentInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserEquipmentInput
    upsert?: UserUpsertWithoutUserEquipmentInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutUserEquipmentInput, UserUpdateWithoutUserEquipmentInput>, UserUncheckedUpdateWithoutUserEquipmentInput>
  }

  export type EquipmentUpdateOneRequiredWithoutUserEquipmentNestedInput = {
    create?: XOR<EquipmentCreateWithoutUserEquipmentInput, EquipmentUncheckedCreateWithoutUserEquipmentInput>
    connectOrCreate?: EquipmentCreateOrConnectWithoutUserEquipmentInput
    upsert?: EquipmentUpsertWithoutUserEquipmentInput
    connect?: EquipmentWhereUniqueInput
    update?: XOR<XOR<EquipmentUpdateToOneWithWhereWithoutUserEquipmentInput, EquipmentUpdateWithoutUserEquipmentInput>, EquipmentUncheckedUpdateWithoutUserEquipmentInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedEnumPrimaryGoalNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.PrimaryGoal | EnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    in?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPrimaryGoalNullableFilter<$PrismaModel> | $Enums.PrimaryGoal | null
  }

  export type NestedEnumTrainingLocationNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.TrainingLocation | EnumTrainingLocationFieldRefInput<$PrismaModel> | null
    in?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    not?: NestedEnumTrainingLocationNullableFilter<$PrismaModel> | $Enums.TrainingLocation | null
  }

  export type NestedEnumBiologicalSexNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.BiologicalSex | EnumBiologicalSexFieldRefInput<$PrismaModel> | null
    in?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    not?: NestedEnumBiologicalSexNullableFilter<$PrismaModel> | $Enums.BiologicalSex | null
  }

  export type NestedEnumUserLevelNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel> | null
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    not?: NestedEnumUserLevelNullableFilter<$PrismaModel> | $Enums.UserLevel | null
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedEnumPrimaryGoalNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PrimaryGoal | EnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    in?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PrimaryGoal[] | ListEnumPrimaryGoalFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPrimaryGoalNullableWithAggregatesFilter<$PrismaModel> | $Enums.PrimaryGoal | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumPrimaryGoalNullableFilter<$PrismaModel>
    _max?: NestedEnumPrimaryGoalNullableFilter<$PrismaModel>
  }

  export type NestedEnumTrainingLocationNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TrainingLocation | EnumTrainingLocationFieldRefInput<$PrismaModel> | null
    in?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.TrainingLocation[] | ListEnumTrainingLocationFieldRefInput<$PrismaModel> | null
    not?: NestedEnumTrainingLocationNullableWithAggregatesFilter<$PrismaModel> | $Enums.TrainingLocation | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumTrainingLocationNullableFilter<$PrismaModel>
    _max?: NestedEnumTrainingLocationNullableFilter<$PrismaModel>
  }

  export type NestedEnumBiologicalSexNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BiologicalSex | EnumBiologicalSexFieldRefInput<$PrismaModel> | null
    in?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.BiologicalSex[] | ListEnumBiologicalSexFieldRefInput<$PrismaModel> | null
    not?: NestedEnumBiologicalSexNullableWithAggregatesFilter<$PrismaModel> | $Enums.BiologicalSex | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumBiologicalSexNullableFilter<$PrismaModel>
    _max?: NestedEnumBiologicalSexNullableFilter<$PrismaModel>
  }

  export type NestedEnumUserLevelNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel> | null
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel> | null
    not?: NestedEnumUserLevelNullableWithAggregatesFilter<$PrismaModel> | $Enums.UserLevel | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumUserLevelNullableFilter<$PrismaModel>
    _max?: NestedEnumUserLevelNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumMuscleGroupFilter<$PrismaModel = never> = {
    equals?: $Enums.MuscleGroup | EnumMuscleGroupFieldRefInput<$PrismaModel>
    in?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    notIn?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    not?: NestedEnumMuscleGroupFilter<$PrismaModel> | $Enums.MuscleGroup
  }

  export type NestedEnumMuscleGroupWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MuscleGroup | EnumMuscleGroupFieldRefInput<$PrismaModel>
    in?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    notIn?: $Enums.MuscleGroup[] | ListEnumMuscleGroupFieldRefInput<$PrismaModel>
    not?: NestedEnumMuscleGroupWithAggregatesFilter<$PrismaModel> | $Enums.MuscleGroup
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMuscleGroupFilter<$PrismaModel>
    _max?: NestedEnumMuscleGroupFilter<$PrismaModel>
  }

  export type NestedEnumPlanTierFilter<$PrismaModel = never> = {
    equals?: $Enums.PlanTier | EnumPlanTierFieldRefInput<$PrismaModel>
    in?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    notIn?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanTierFilter<$PrismaModel> | $Enums.PlanTier
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedEnumPlanTierWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PlanTier | EnumPlanTierFieldRefInput<$PrismaModel>
    in?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    notIn?: $Enums.PlanTier[] | ListEnumPlanTierFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanTierWithAggregatesFilter<$PrismaModel> | $Enums.PlanTier
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPlanTierFilter<$PrismaModel>
    _max?: NestedEnumPlanTierFilter<$PrismaModel>
  }

  export type NestedEnumUserLevelFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel>
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    not?: NestedEnumUserLevelFilter<$PrismaModel> | $Enums.UserLevel
  }

  export type NestedEnumInstanceStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.InstanceStatus | EnumInstanceStatusFieldRefInput<$PrismaModel>
    in?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumInstanceStatusFilter<$PrismaModel> | $Enums.InstanceStatus
  }

  export type NestedEnumUserLevelWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.UserLevel | EnumUserLevelFieldRefInput<$PrismaModel>
    in?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    notIn?: $Enums.UserLevel[] | ListEnumUserLevelFieldRefInput<$PrismaModel>
    not?: NestedEnumUserLevelWithAggregatesFilter<$PrismaModel> | $Enums.UserLevel
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumUserLevelFilter<$PrismaModel>
    _max?: NestedEnumUserLevelFilter<$PrismaModel>
  }

  export type NestedEnumInstanceStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.InstanceStatus | EnumInstanceStatusFieldRefInput<$PrismaModel>
    in?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.InstanceStatus[] | ListEnumInstanceStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumInstanceStatusWithAggregatesFilter<$PrismaModel> | $Enums.InstanceStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumInstanceStatusFilter<$PrismaModel>
    _max?: NestedEnumInstanceStatusFilter<$PrismaModel>
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedFloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type NestedEnumPlanFilter<$PrismaModel = never> = {
    equals?: $Enums.Plan | EnumPlanFieldRefInput<$PrismaModel>
    in?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    notIn?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanFilter<$PrismaModel> | $Enums.Plan
  }

  export type NestedEnumPlanWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Plan | EnumPlanFieldRefInput<$PrismaModel>
    in?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    notIn?: $Enums.Plan[] | ListEnumPlanFieldRefInput<$PrismaModel>
    not?: NestedEnumPlanWithAggregatesFilter<$PrismaModel> | $Enums.Plan
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPlanFilter<$PrismaModel>
    _max?: NestedEnumPlanFilter<$PrismaModel>
  }

  export type NestedEnumEquipmentSourceFilter<$PrismaModel = never> = {
    equals?: $Enums.EquipmentSource | EnumEquipmentSourceFieldRefInput<$PrismaModel>
    in?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    notIn?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    not?: NestedEnumEquipmentSourceFilter<$PrismaModel> | $Enums.EquipmentSource
  }

  export type NestedEnumEquipmentSourceWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EquipmentSource | EnumEquipmentSourceFieldRefInput<$PrismaModel>
    in?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    notIn?: $Enums.EquipmentSource[] | ListEnumEquipmentSourceFieldRefInput<$PrismaModel>
    not?: NestedEnumEquipmentSourceWithAggregatesFilter<$PrismaModel> | $Enums.EquipmentSource
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEquipmentSourceFilter<$PrismaModel>
    _max?: NestedEnumEquipmentSourceFilter<$PrismaModel>
  }

  export type AccountCreateWithoutUserInput = {
    id?: string
    type: string
    provider: string
    providerAccountId: string
    refresh_token?: string | null
    access_token?: string | null
    expires_at?: number | null
    token_type?: string | null
    scope?: string | null
    id_token?: string | null
    session_state?: string | null
  }

  export type AccountUncheckedCreateWithoutUserInput = {
    id?: string
    type: string
    provider: string
    providerAccountId: string
    refresh_token?: string | null
    access_token?: string | null
    expires_at?: number | null
    token_type?: string | null
    scope?: string | null
    id_token?: string | null
    session_state?: string | null
  }

  export type AccountCreateOrConnectWithoutUserInput = {
    where: AccountWhereUniqueInput
    create: XOR<AccountCreateWithoutUserInput, AccountUncheckedCreateWithoutUserInput>
  }

  export type AccountCreateManyUserInputEnvelope = {
    data: AccountCreateManyUserInput | AccountCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type NextAuthSessionCreateWithoutUserInput = {
    id?: string
    sessionToken: string
    expires: Date | string
  }

  export type NextAuthSessionUncheckedCreateWithoutUserInput = {
    id?: string
    sessionToken: string
    expires: Date | string
  }

  export type NextAuthSessionCreateOrConnectWithoutUserInput = {
    where: NextAuthSessionWhereUniqueInput
    create: XOR<NextAuthSessionCreateWithoutUserInput, NextAuthSessionUncheckedCreateWithoutUserInput>
  }

  export type NextAuthSessionCreateManyUserInputEnvelope = {
    data: NextAuthSessionCreateManyUserInput | NextAuthSessionCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type SubscriptionCreateWithoutUserInput = {
    id?: string
    plan?: $Enums.Plan
    status: string
    source?: string | null
    startedAt?: Date | string
    expiresAt?: Date | string | null
  }

  export type SubscriptionUncheckedCreateWithoutUserInput = {
    id?: string
    plan?: $Enums.Plan
    status: string
    source?: string | null
    startedAt?: Date | string
    expiresAt?: Date | string | null
  }

  export type SubscriptionCreateOrConnectWithoutUserInput = {
    where: SubscriptionWhereUniqueInput
    create: XOR<SubscriptionCreateWithoutUserInput, SubscriptionUncheckedCreateWithoutUserInput>
  }

  export type UserEquipmentCreateWithoutUserInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    equipment: EquipmentCreateNestedOneWithoutUserEquipmentInput
  }

  export type UserEquipmentUncheckedCreateWithoutUserInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    equipmentId: string
  }

  export type UserEquipmentCreateOrConnectWithoutUserInput = {
    where: UserEquipmentWhereUniqueInput
    create: XOR<UserEquipmentCreateWithoutUserInput, UserEquipmentUncheckedCreateWithoutUserInput>
  }

  export type UserEquipmentCreateManyUserInputEnvelope = {
    data: UserEquipmentCreateManyUserInput | UserEquipmentCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type PlanInstanceCreateWithoutUserInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
    plan: WorkoutPlanCreateNestedOneWithoutInstancesInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutInstanceInput
  }

  export type PlanInstanceUncheckedCreateWithoutUserInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    planId: string
    createdAt?: Date | string
    updatedAt?: Date | string
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutInstanceInput
  }

  export type PlanInstanceCreateOrConnectWithoutUserInput = {
    where: PlanInstanceWhereUniqueInput
    create: XOR<PlanInstanceCreateWithoutUserInput, PlanInstanceUncheckedCreateWithoutUserInput>
  }

  export type PlanInstanceCreateManyUserInputEnvelope = {
    data: PlanInstanceCreateManyUserInput | PlanInstanceCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type WorkoutLogCreateWithoutUserInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    createdAt?: Date | string
    instance: PlanInstanceCreateNestedOneWithoutWorkoutLogsInput
    plannedExercise: PlannedExerciseCreateNestedOneWithoutLoggedSetsInput
  }

  export type WorkoutLogUncheckedCreateWithoutUserInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    instanceId: string
    plannedExerciseId: string
    createdAt?: Date | string
  }

  export type WorkoutLogCreateOrConnectWithoutUserInput = {
    where: WorkoutLogWhereUniqueInput
    create: XOR<WorkoutLogCreateWithoutUserInput, WorkoutLogUncheckedCreateWithoutUserInput>
  }

  export type WorkoutLogCreateManyUserInputEnvelope = {
    data: WorkoutLogCreateManyUserInput | WorkoutLogCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type AccountUpsertWithWhereUniqueWithoutUserInput = {
    where: AccountWhereUniqueInput
    update: XOR<AccountUpdateWithoutUserInput, AccountUncheckedUpdateWithoutUserInput>
    create: XOR<AccountCreateWithoutUserInput, AccountUncheckedCreateWithoutUserInput>
  }

  export type AccountUpdateWithWhereUniqueWithoutUserInput = {
    where: AccountWhereUniqueInput
    data: XOR<AccountUpdateWithoutUserInput, AccountUncheckedUpdateWithoutUserInput>
  }

  export type AccountUpdateManyWithWhereWithoutUserInput = {
    where: AccountScalarWhereInput
    data: XOR<AccountUpdateManyMutationInput, AccountUncheckedUpdateManyWithoutUserInput>
  }

  export type AccountScalarWhereInput = {
    AND?: AccountScalarWhereInput | AccountScalarWhereInput[]
    OR?: AccountScalarWhereInput[]
    NOT?: AccountScalarWhereInput | AccountScalarWhereInput[]
    id?: StringFilter<"Account"> | string
    userId?: StringFilter<"Account"> | string
    type?: StringFilter<"Account"> | string
    provider?: StringFilter<"Account"> | string
    providerAccountId?: StringFilter<"Account"> | string
    refresh_token?: StringNullableFilter<"Account"> | string | null
    access_token?: StringNullableFilter<"Account"> | string | null
    expires_at?: IntNullableFilter<"Account"> | number | null
    token_type?: StringNullableFilter<"Account"> | string | null
    scope?: StringNullableFilter<"Account"> | string | null
    id_token?: StringNullableFilter<"Account"> | string | null
    session_state?: StringNullableFilter<"Account"> | string | null
  }

  export type NextAuthSessionUpsertWithWhereUniqueWithoutUserInput = {
    where: NextAuthSessionWhereUniqueInput
    update: XOR<NextAuthSessionUpdateWithoutUserInput, NextAuthSessionUncheckedUpdateWithoutUserInput>
    create: XOR<NextAuthSessionCreateWithoutUserInput, NextAuthSessionUncheckedCreateWithoutUserInput>
  }

  export type NextAuthSessionUpdateWithWhereUniqueWithoutUserInput = {
    where: NextAuthSessionWhereUniqueInput
    data: XOR<NextAuthSessionUpdateWithoutUserInput, NextAuthSessionUncheckedUpdateWithoutUserInput>
  }

  export type NextAuthSessionUpdateManyWithWhereWithoutUserInput = {
    where: NextAuthSessionScalarWhereInput
    data: XOR<NextAuthSessionUpdateManyMutationInput, NextAuthSessionUncheckedUpdateManyWithoutUserInput>
  }

  export type NextAuthSessionScalarWhereInput = {
    AND?: NextAuthSessionScalarWhereInput | NextAuthSessionScalarWhereInput[]
    OR?: NextAuthSessionScalarWhereInput[]
    NOT?: NextAuthSessionScalarWhereInput | NextAuthSessionScalarWhereInput[]
    id?: StringFilter<"NextAuthSession"> | string
    sessionToken?: StringFilter<"NextAuthSession"> | string
    userId?: StringFilter<"NextAuthSession"> | string
    expires?: DateTimeFilter<"NextAuthSession"> | Date | string
  }

  export type SubscriptionUpsertWithoutUserInput = {
    update: XOR<SubscriptionUpdateWithoutUserInput, SubscriptionUncheckedUpdateWithoutUserInput>
    create: XOR<SubscriptionCreateWithoutUserInput, SubscriptionUncheckedCreateWithoutUserInput>
    where?: SubscriptionWhereInput
  }

  export type SubscriptionUpdateToOneWithWhereWithoutUserInput = {
    where?: SubscriptionWhereInput
    data: XOR<SubscriptionUpdateWithoutUserInput, SubscriptionUncheckedUpdateWithoutUserInput>
  }

  export type SubscriptionUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    plan?: EnumPlanFieldUpdateOperationsInput | $Enums.Plan
    status?: StringFieldUpdateOperationsInput | string
    source?: NullableStringFieldUpdateOperationsInput | string | null
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SubscriptionUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    plan?: EnumPlanFieldUpdateOperationsInput | $Enums.Plan
    status?: StringFieldUpdateOperationsInput | string
    source?: NullableStringFieldUpdateOperationsInput | string | null
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type UserEquipmentUpsertWithWhereUniqueWithoutUserInput = {
    where: UserEquipmentWhereUniqueInput
    update: XOR<UserEquipmentUpdateWithoutUserInput, UserEquipmentUncheckedUpdateWithoutUserInput>
    create: XOR<UserEquipmentCreateWithoutUserInput, UserEquipmentUncheckedCreateWithoutUserInput>
  }

  export type UserEquipmentUpdateWithWhereUniqueWithoutUserInput = {
    where: UserEquipmentWhereUniqueInput
    data: XOR<UserEquipmentUpdateWithoutUserInput, UserEquipmentUncheckedUpdateWithoutUserInput>
  }

  export type UserEquipmentUpdateManyWithWhereWithoutUserInput = {
    where: UserEquipmentScalarWhereInput
    data: XOR<UserEquipmentUpdateManyMutationInput, UserEquipmentUncheckedUpdateManyWithoutUserInput>
  }

  export type UserEquipmentScalarWhereInput = {
    AND?: UserEquipmentScalarWhereInput | UserEquipmentScalarWhereInput[]
    OR?: UserEquipmentScalarWhereInput[]
    NOT?: UserEquipmentScalarWhereInput | UserEquipmentScalarWhereInput[]
    id?: StringFilter<"UserEquipment"> | string
    source?: EnumEquipmentSourceFilter<"UserEquipment"> | $Enums.EquipmentSource
    addedAt?: DateTimeFilter<"UserEquipment"> | Date | string
    trialExpiresAt?: DateTimeNullableFilter<"UserEquipment"> | Date | string | null
    userId?: StringFilter<"UserEquipment"> | string
    equipmentId?: StringFilter<"UserEquipment"> | string
  }

  export type PlanInstanceUpsertWithWhereUniqueWithoutUserInput = {
    where: PlanInstanceWhereUniqueInput
    update: XOR<PlanInstanceUpdateWithoutUserInput, PlanInstanceUncheckedUpdateWithoutUserInput>
    create: XOR<PlanInstanceCreateWithoutUserInput, PlanInstanceUncheckedCreateWithoutUserInput>
  }

  export type PlanInstanceUpdateWithWhereUniqueWithoutUserInput = {
    where: PlanInstanceWhereUniqueInput
    data: XOR<PlanInstanceUpdateWithoutUserInput, PlanInstanceUncheckedUpdateWithoutUserInput>
  }

  export type PlanInstanceUpdateManyWithWhereWithoutUserInput = {
    where: PlanInstanceScalarWhereInput
    data: XOR<PlanInstanceUpdateManyMutationInput, PlanInstanceUncheckedUpdateManyWithoutUserInput>
  }

  export type PlanInstanceScalarWhereInput = {
    AND?: PlanInstanceScalarWhereInput | PlanInstanceScalarWhereInput[]
    OR?: PlanInstanceScalarWhereInput[]
    NOT?: PlanInstanceScalarWhereInput | PlanInstanceScalarWhereInput[]
    id?: StringFilter<"PlanInstance"> | string
    level?: EnumUserLevelFilter<"PlanInstance"> | $Enums.UserLevel
    status?: EnumInstanceStatusFilter<"PlanInstance"> | $Enums.InstanceStatus
    currentSession?: IntFilter<"PlanInstance"> | number
    startedAt?: DateTimeFilter<"PlanInstance"> | Date | string
    completedAt?: DateTimeNullableFilter<"PlanInstance"> | Date | string | null
    sessionDraft?: JsonNullableFilter<"PlanInstance">
    userId?: StringFilter<"PlanInstance"> | string
    planId?: StringFilter<"PlanInstance"> | string
    createdAt?: DateTimeFilter<"PlanInstance"> | Date | string
    updatedAt?: DateTimeFilter<"PlanInstance"> | Date | string
  }

  export type WorkoutLogUpsertWithWhereUniqueWithoutUserInput = {
    where: WorkoutLogWhereUniqueInput
    update: XOR<WorkoutLogUpdateWithoutUserInput, WorkoutLogUncheckedUpdateWithoutUserInput>
    create: XOR<WorkoutLogCreateWithoutUserInput, WorkoutLogUncheckedCreateWithoutUserInput>
  }

  export type WorkoutLogUpdateWithWhereUniqueWithoutUserInput = {
    where: WorkoutLogWhereUniqueInput
    data: XOR<WorkoutLogUpdateWithoutUserInput, WorkoutLogUncheckedUpdateWithoutUserInput>
  }

  export type WorkoutLogUpdateManyWithWhereWithoutUserInput = {
    where: WorkoutLogScalarWhereInput
    data: XOR<WorkoutLogUpdateManyMutationInput, WorkoutLogUncheckedUpdateManyWithoutUserInput>
  }

  export type WorkoutLogScalarWhereInput = {
    AND?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
    OR?: WorkoutLogScalarWhereInput[]
    NOT?: WorkoutLogScalarWhereInput | WorkoutLogScalarWhereInput[]
    id?: StringFilter<"WorkoutLog"> | string
    sessionNumber?: IntFilter<"WorkoutLog"> | number
    completedAt?: DateTimeFilter<"WorkoutLog"> | Date | string
    weightKg?: FloatNullableFilter<"WorkoutLog"> | number | null
    actualReps?: IntNullableFilter<"WorkoutLog"> | number | null
    actualSets?: IntNullableFilter<"WorkoutLog"> | number | null
    userId?: StringFilter<"WorkoutLog"> | string
    instanceId?: StringFilter<"WorkoutLog"> | string
    plannedExerciseId?: StringFilter<"WorkoutLog"> | string
    createdAt?: DateTimeFilter<"WorkoutLog"> | Date | string
  }

  export type UserCreateWithoutAccountsInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    sessions?: NextAuthSessionCreateNestedManyWithoutUserInput
    subscription?: SubscriptionCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentCreateNestedManyWithoutUserInput
    instances?: PlanInstanceCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutAccountsInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    sessions?: NextAuthSessionUncheckedCreateNestedManyWithoutUserInput
    subscription?: SubscriptionUncheckedCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutUserInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutAccountsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutAccountsInput, UserUncheckedCreateWithoutAccountsInput>
  }

  export type UserUpsertWithoutAccountsInput = {
    update: XOR<UserUpdateWithoutAccountsInput, UserUncheckedUpdateWithoutAccountsInput>
    create: XOR<UserCreateWithoutAccountsInput, UserUncheckedCreateWithoutAccountsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutAccountsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutAccountsInput, UserUncheckedUpdateWithoutAccountsInput>
  }

  export type UserUpdateWithoutAccountsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessions?: NextAuthSessionUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutAccountsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessions?: NextAuthSessionUncheckedUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUncheckedUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutSessionsInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountCreateNestedManyWithoutUserInput
    subscription?: SubscriptionCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentCreateNestedManyWithoutUserInput
    instances?: PlanInstanceCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutSessionsInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountUncheckedCreateNestedManyWithoutUserInput
    subscription?: SubscriptionUncheckedCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutUserInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutSessionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
  }

  export type UserUpsertWithoutSessionsInput = {
    update: XOR<UserUpdateWithoutSessionsInput, UserUncheckedUpdateWithoutSessionsInput>
    create: XOR<UserCreateWithoutSessionsInput, UserUncheckedCreateWithoutSessionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutSessionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutSessionsInput, UserUncheckedUpdateWithoutSessionsInput>
  }

  export type UserUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUncheckedUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUncheckedUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserEquipmentCreateWithoutEquipmentInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    user: UserCreateNestedOneWithoutUserEquipmentInput
  }

  export type UserEquipmentUncheckedCreateWithoutEquipmentInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    userId: string
  }

  export type UserEquipmentCreateOrConnectWithoutEquipmentInput = {
    where: UserEquipmentWhereUniqueInput
    create: XOR<UserEquipmentCreateWithoutEquipmentInput, UserEquipmentUncheckedCreateWithoutEquipmentInput>
  }

  export type UserEquipmentCreateManyEquipmentInputEnvelope = {
    data: UserEquipmentCreateManyEquipmentInput | UserEquipmentCreateManyEquipmentInput[]
    skipDuplicates?: boolean
  }

  export type ExerciseCreateWithoutEquipmentInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    createdAt?: Date | string
    updatedAt?: Date | string
    plannedExercises?: PlannedExerciseCreateNestedManyWithoutExerciseInput
  }

  export type ExerciseUncheckedCreateWithoutEquipmentInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    createdAt?: Date | string
    updatedAt?: Date | string
    plannedExercises?: PlannedExerciseUncheckedCreateNestedManyWithoutExerciseInput
  }

  export type ExerciseCreateOrConnectWithoutEquipmentInput = {
    where: ExerciseWhereUniqueInput
    create: XOR<ExerciseCreateWithoutEquipmentInput, ExerciseUncheckedCreateWithoutEquipmentInput>
  }

  export type ExerciseCreateManyEquipmentInputEnvelope = {
    data: ExerciseCreateManyEquipmentInput | ExerciseCreateManyEquipmentInput[]
    skipDuplicates?: boolean
  }

  export type WorkoutPlanCreateWithoutEquipmentInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    createdAt?: Date | string
    updatedAt?: Date | string
    plannedSessions?: PlannedSessionCreateNestedManyWithoutPlanInput
    instances?: PlanInstanceCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUncheckedCreateWithoutEquipmentInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    createdAt?: Date | string
    updatedAt?: Date | string
    plannedSessions?: PlannedSessionUncheckedCreateNestedManyWithoutPlanInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanCreateOrConnectWithoutEquipmentInput = {
    where: WorkoutPlanWhereUniqueInput
    create: XOR<WorkoutPlanCreateWithoutEquipmentInput, WorkoutPlanUncheckedCreateWithoutEquipmentInput>
  }

  export type WorkoutPlanCreateManyEquipmentInputEnvelope = {
    data: WorkoutPlanCreateManyEquipmentInput | WorkoutPlanCreateManyEquipmentInput[]
    skipDuplicates?: boolean
  }

  export type UserEquipmentUpsertWithWhereUniqueWithoutEquipmentInput = {
    where: UserEquipmentWhereUniqueInput
    update: XOR<UserEquipmentUpdateWithoutEquipmentInput, UserEquipmentUncheckedUpdateWithoutEquipmentInput>
    create: XOR<UserEquipmentCreateWithoutEquipmentInput, UserEquipmentUncheckedCreateWithoutEquipmentInput>
  }

  export type UserEquipmentUpdateWithWhereUniqueWithoutEquipmentInput = {
    where: UserEquipmentWhereUniqueInput
    data: XOR<UserEquipmentUpdateWithoutEquipmentInput, UserEquipmentUncheckedUpdateWithoutEquipmentInput>
  }

  export type UserEquipmentUpdateManyWithWhereWithoutEquipmentInput = {
    where: UserEquipmentScalarWhereInput
    data: XOR<UserEquipmentUpdateManyMutationInput, UserEquipmentUncheckedUpdateManyWithoutEquipmentInput>
  }

  export type ExerciseUpsertWithWhereUniqueWithoutEquipmentInput = {
    where: ExerciseWhereUniqueInput
    update: XOR<ExerciseUpdateWithoutEquipmentInput, ExerciseUncheckedUpdateWithoutEquipmentInput>
    create: XOR<ExerciseCreateWithoutEquipmentInput, ExerciseUncheckedCreateWithoutEquipmentInput>
  }

  export type ExerciseUpdateWithWhereUniqueWithoutEquipmentInput = {
    where: ExerciseWhereUniqueInput
    data: XOR<ExerciseUpdateWithoutEquipmentInput, ExerciseUncheckedUpdateWithoutEquipmentInput>
  }

  export type ExerciseUpdateManyWithWhereWithoutEquipmentInput = {
    where: ExerciseScalarWhereInput
    data: XOR<ExerciseUpdateManyMutationInput, ExerciseUncheckedUpdateManyWithoutEquipmentInput>
  }

  export type ExerciseScalarWhereInput = {
    AND?: ExerciseScalarWhereInput | ExerciseScalarWhereInput[]
    OR?: ExerciseScalarWhereInput[]
    NOT?: ExerciseScalarWhereInput | ExerciseScalarWhereInput[]
    id?: StringFilter<"Exercise"> | string
    name?: StringFilter<"Exercise"> | string
    description?: StringNullableFilter<"Exercise"> | string | null
    youtubeUrl?: StringNullableFilter<"Exercise"> | string | null
    musclesWorked?: StringNullableListFilter<"Exercise">
    muscleGroup?: EnumMuscleGroupFilter<"Exercise"> | $Enums.MuscleGroup
    equipmentId?: StringNullableFilter<"Exercise"> | string | null
    createdAt?: DateTimeFilter<"Exercise"> | Date | string
    updatedAt?: DateTimeFilter<"Exercise"> | Date | string
  }

  export type WorkoutPlanUpsertWithWhereUniqueWithoutEquipmentInput = {
    where: WorkoutPlanWhereUniqueInput
    update: XOR<WorkoutPlanUpdateWithoutEquipmentInput, WorkoutPlanUncheckedUpdateWithoutEquipmentInput>
    create: XOR<WorkoutPlanCreateWithoutEquipmentInput, WorkoutPlanUncheckedCreateWithoutEquipmentInput>
  }

  export type WorkoutPlanUpdateWithWhereUniqueWithoutEquipmentInput = {
    where: WorkoutPlanWhereUniqueInput
    data: XOR<WorkoutPlanUpdateWithoutEquipmentInput, WorkoutPlanUncheckedUpdateWithoutEquipmentInput>
  }

  export type WorkoutPlanUpdateManyWithWhereWithoutEquipmentInput = {
    where: WorkoutPlanScalarWhereInput
    data: XOR<WorkoutPlanUpdateManyMutationInput, WorkoutPlanUncheckedUpdateManyWithoutEquipmentInput>
  }

  export type WorkoutPlanScalarWhereInput = {
    AND?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
    OR?: WorkoutPlanScalarWhereInput[]
    NOT?: WorkoutPlanScalarWhereInput | WorkoutPlanScalarWhereInput[]
    id?: StringFilter<"WorkoutPlan"> | string
    name?: StringFilter<"WorkoutPlan"> | string
    description?: StringFilter<"WorkoutPlan"> | string
    muscleGroup?: EnumMuscleGroupFilter<"WorkoutPlan"> | $Enums.MuscleGroup
    durationWeeks?: IntFilter<"WorkoutPlan"> | number
    sessionsPerWeek?: IntFilter<"WorkoutPlan"> | number
    tier?: EnumPlanTierFilter<"WorkoutPlan"> | $Enums.PlanTier
    equipmentId?: StringNullableFilter<"WorkoutPlan"> | string | null
    createdAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
    updatedAt?: DateTimeFilter<"WorkoutPlan"> | Date | string
  }

  export type EquipmentCreateWithoutExercisesInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userEquipment?: UserEquipmentCreateNestedManyWithoutEquipmentInput
    workoutPlans?: WorkoutPlanCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentUncheckedCreateWithoutExercisesInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutEquipmentInput
    workoutPlans?: WorkoutPlanUncheckedCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentCreateOrConnectWithoutExercisesInput = {
    where: EquipmentWhereUniqueInput
    create: XOR<EquipmentCreateWithoutExercisesInput, EquipmentUncheckedCreateWithoutExercisesInput>
  }

  export type PlannedExerciseCreateWithoutExerciseInput = {
    id?: string
    order: number
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    session: PlannedSessionCreateNestedOneWithoutPlannedExercisesInput
    loggedSets?: WorkoutLogCreateNestedManyWithoutPlannedExerciseInput
  }

  export type PlannedExerciseUncheckedCreateWithoutExerciseInput = {
    id?: string
    order: number
    sessionId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    loggedSets?: WorkoutLogUncheckedCreateNestedManyWithoutPlannedExerciseInput
  }

  export type PlannedExerciseCreateOrConnectWithoutExerciseInput = {
    where: PlannedExerciseWhereUniqueInput
    create: XOR<PlannedExerciseCreateWithoutExerciseInput, PlannedExerciseUncheckedCreateWithoutExerciseInput>
  }

  export type PlannedExerciseCreateManyExerciseInputEnvelope = {
    data: PlannedExerciseCreateManyExerciseInput | PlannedExerciseCreateManyExerciseInput[]
    skipDuplicates?: boolean
  }

  export type EquipmentUpsertWithoutExercisesInput = {
    update: XOR<EquipmentUpdateWithoutExercisesInput, EquipmentUncheckedUpdateWithoutExercisesInput>
    create: XOR<EquipmentCreateWithoutExercisesInput, EquipmentUncheckedCreateWithoutExercisesInput>
    where?: EquipmentWhereInput
  }

  export type EquipmentUpdateToOneWithWhereWithoutExercisesInput = {
    where?: EquipmentWhereInput
    data: XOR<EquipmentUpdateWithoutExercisesInput, EquipmentUncheckedUpdateWithoutExercisesInput>
  }

  export type EquipmentUpdateWithoutExercisesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userEquipment?: UserEquipmentUpdateManyWithoutEquipmentNestedInput
    workoutPlans?: WorkoutPlanUpdateManyWithoutEquipmentNestedInput
  }

  export type EquipmentUncheckedUpdateWithoutExercisesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutEquipmentNestedInput
    workoutPlans?: WorkoutPlanUncheckedUpdateManyWithoutEquipmentNestedInput
  }

  export type PlannedExerciseUpsertWithWhereUniqueWithoutExerciseInput = {
    where: PlannedExerciseWhereUniqueInput
    update: XOR<PlannedExerciseUpdateWithoutExerciseInput, PlannedExerciseUncheckedUpdateWithoutExerciseInput>
    create: XOR<PlannedExerciseCreateWithoutExerciseInput, PlannedExerciseUncheckedCreateWithoutExerciseInput>
  }

  export type PlannedExerciseUpdateWithWhereUniqueWithoutExerciseInput = {
    where: PlannedExerciseWhereUniqueInput
    data: XOR<PlannedExerciseUpdateWithoutExerciseInput, PlannedExerciseUncheckedUpdateWithoutExerciseInput>
  }

  export type PlannedExerciseUpdateManyWithWhereWithoutExerciseInput = {
    where: PlannedExerciseScalarWhereInput
    data: XOR<PlannedExerciseUpdateManyMutationInput, PlannedExerciseUncheckedUpdateManyWithoutExerciseInput>
  }

  export type PlannedExerciseScalarWhereInput = {
    AND?: PlannedExerciseScalarWhereInput | PlannedExerciseScalarWhereInput[]
    OR?: PlannedExerciseScalarWhereInput[]
    NOT?: PlannedExerciseScalarWhereInput | PlannedExerciseScalarWhereInput[]
    id?: StringFilter<"PlannedExercise"> | string
    order?: IntFilter<"PlannedExercise"> | number
    sessionId?: StringFilter<"PlannedExercise"> | string
    exerciseId?: StringFilter<"PlannedExercise"> | string
    beginnerSets?: IntFilter<"PlannedExercise"> | number
    beginnerReps?: IntFilter<"PlannedExercise"> | number
    intermediateSets?: IntFilter<"PlannedExercise"> | number
    intermediateReps?: IntFilter<"PlannedExercise"> | number
    advancedSets?: IntFilter<"PlannedExercise"> | number
    advancedReps?: IntFilter<"PlannedExercise"> | number
    restSeconds?: IntFilter<"PlannedExercise"> | number
  }

  export type EquipmentCreateWithoutWorkoutPlansInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userEquipment?: UserEquipmentCreateNestedManyWithoutEquipmentInput
    exercises?: ExerciseCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentUncheckedCreateWithoutWorkoutPlansInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutEquipmentInput
    exercises?: ExerciseUncheckedCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentCreateOrConnectWithoutWorkoutPlansInput = {
    where: EquipmentWhereUniqueInput
    create: XOR<EquipmentCreateWithoutWorkoutPlansInput, EquipmentUncheckedCreateWithoutWorkoutPlansInput>
  }

  export type PlannedSessionCreateWithoutPlanInput = {
    id?: string
    sessionNumber: number
    focus: string
    plannedExercises?: PlannedExerciseCreateNestedManyWithoutSessionInput
  }

  export type PlannedSessionUncheckedCreateWithoutPlanInput = {
    id?: string
    sessionNumber: number
    focus: string
    plannedExercises?: PlannedExerciseUncheckedCreateNestedManyWithoutSessionInput
  }

  export type PlannedSessionCreateOrConnectWithoutPlanInput = {
    where: PlannedSessionWhereUniqueInput
    create: XOR<PlannedSessionCreateWithoutPlanInput, PlannedSessionUncheckedCreateWithoutPlanInput>
  }

  export type PlannedSessionCreateManyPlanInputEnvelope = {
    data: PlannedSessionCreateManyPlanInput | PlannedSessionCreateManyPlanInput[]
    skipDuplicates?: boolean
  }

  export type PlanInstanceCreateWithoutPlanInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutInstancesInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutInstanceInput
  }

  export type PlanInstanceUncheckedCreateWithoutPlanInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId: string
    createdAt?: Date | string
    updatedAt?: Date | string
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutInstanceInput
  }

  export type PlanInstanceCreateOrConnectWithoutPlanInput = {
    where: PlanInstanceWhereUniqueInput
    create: XOR<PlanInstanceCreateWithoutPlanInput, PlanInstanceUncheckedCreateWithoutPlanInput>
  }

  export type PlanInstanceCreateManyPlanInputEnvelope = {
    data: PlanInstanceCreateManyPlanInput | PlanInstanceCreateManyPlanInput[]
    skipDuplicates?: boolean
  }

  export type EquipmentUpsertWithoutWorkoutPlansInput = {
    update: XOR<EquipmentUpdateWithoutWorkoutPlansInput, EquipmentUncheckedUpdateWithoutWorkoutPlansInput>
    create: XOR<EquipmentCreateWithoutWorkoutPlansInput, EquipmentUncheckedCreateWithoutWorkoutPlansInput>
    where?: EquipmentWhereInput
  }

  export type EquipmentUpdateToOneWithWhereWithoutWorkoutPlansInput = {
    where?: EquipmentWhereInput
    data: XOR<EquipmentUpdateWithoutWorkoutPlansInput, EquipmentUncheckedUpdateWithoutWorkoutPlansInput>
  }

  export type EquipmentUpdateWithoutWorkoutPlansInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userEquipment?: UserEquipmentUpdateManyWithoutEquipmentNestedInput
    exercises?: ExerciseUpdateManyWithoutEquipmentNestedInput
  }

  export type EquipmentUncheckedUpdateWithoutWorkoutPlansInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutEquipmentNestedInput
    exercises?: ExerciseUncheckedUpdateManyWithoutEquipmentNestedInput
  }

  export type PlannedSessionUpsertWithWhereUniqueWithoutPlanInput = {
    where: PlannedSessionWhereUniqueInput
    update: XOR<PlannedSessionUpdateWithoutPlanInput, PlannedSessionUncheckedUpdateWithoutPlanInput>
    create: XOR<PlannedSessionCreateWithoutPlanInput, PlannedSessionUncheckedCreateWithoutPlanInput>
  }

  export type PlannedSessionUpdateWithWhereUniqueWithoutPlanInput = {
    where: PlannedSessionWhereUniqueInput
    data: XOR<PlannedSessionUpdateWithoutPlanInput, PlannedSessionUncheckedUpdateWithoutPlanInput>
  }

  export type PlannedSessionUpdateManyWithWhereWithoutPlanInput = {
    where: PlannedSessionScalarWhereInput
    data: XOR<PlannedSessionUpdateManyMutationInput, PlannedSessionUncheckedUpdateManyWithoutPlanInput>
  }

  export type PlannedSessionScalarWhereInput = {
    AND?: PlannedSessionScalarWhereInput | PlannedSessionScalarWhereInput[]
    OR?: PlannedSessionScalarWhereInput[]
    NOT?: PlannedSessionScalarWhereInput | PlannedSessionScalarWhereInput[]
    id?: StringFilter<"PlannedSession"> | string
    sessionNumber?: IntFilter<"PlannedSession"> | number
    focus?: StringFilter<"PlannedSession"> | string
    planId?: StringFilter<"PlannedSession"> | string
  }

  export type PlanInstanceUpsertWithWhereUniqueWithoutPlanInput = {
    where: PlanInstanceWhereUniqueInput
    update: XOR<PlanInstanceUpdateWithoutPlanInput, PlanInstanceUncheckedUpdateWithoutPlanInput>
    create: XOR<PlanInstanceCreateWithoutPlanInput, PlanInstanceUncheckedCreateWithoutPlanInput>
  }

  export type PlanInstanceUpdateWithWhereUniqueWithoutPlanInput = {
    where: PlanInstanceWhereUniqueInput
    data: XOR<PlanInstanceUpdateWithoutPlanInput, PlanInstanceUncheckedUpdateWithoutPlanInput>
  }

  export type PlanInstanceUpdateManyWithWhereWithoutPlanInput = {
    where: PlanInstanceScalarWhereInput
    data: XOR<PlanInstanceUpdateManyMutationInput, PlanInstanceUncheckedUpdateManyWithoutPlanInput>
  }

  export type WorkoutPlanCreateWithoutPlannedSessionsInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    createdAt?: Date | string
    updatedAt?: Date | string
    equipment?: EquipmentCreateNestedOneWithoutWorkoutPlansInput
    instances?: PlanInstanceCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUncheckedCreateWithoutPlannedSessionsInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    equipmentId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanCreateOrConnectWithoutPlannedSessionsInput = {
    where: WorkoutPlanWhereUniqueInput
    create: XOR<WorkoutPlanCreateWithoutPlannedSessionsInput, WorkoutPlanUncheckedCreateWithoutPlannedSessionsInput>
  }

  export type PlannedExerciseCreateWithoutSessionInput = {
    id?: string
    order: number
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    exercise: ExerciseCreateNestedOneWithoutPlannedExercisesInput
    loggedSets?: WorkoutLogCreateNestedManyWithoutPlannedExerciseInput
  }

  export type PlannedExerciseUncheckedCreateWithoutSessionInput = {
    id?: string
    order: number
    exerciseId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    loggedSets?: WorkoutLogUncheckedCreateNestedManyWithoutPlannedExerciseInput
  }

  export type PlannedExerciseCreateOrConnectWithoutSessionInput = {
    where: PlannedExerciseWhereUniqueInput
    create: XOR<PlannedExerciseCreateWithoutSessionInput, PlannedExerciseUncheckedCreateWithoutSessionInput>
  }

  export type PlannedExerciseCreateManySessionInputEnvelope = {
    data: PlannedExerciseCreateManySessionInput | PlannedExerciseCreateManySessionInput[]
    skipDuplicates?: boolean
  }

  export type WorkoutPlanUpsertWithoutPlannedSessionsInput = {
    update: XOR<WorkoutPlanUpdateWithoutPlannedSessionsInput, WorkoutPlanUncheckedUpdateWithoutPlannedSessionsInput>
    create: XOR<WorkoutPlanCreateWithoutPlannedSessionsInput, WorkoutPlanUncheckedCreateWithoutPlannedSessionsInput>
    where?: WorkoutPlanWhereInput
  }

  export type WorkoutPlanUpdateToOneWithWhereWithoutPlannedSessionsInput = {
    where?: WorkoutPlanWhereInput
    data: XOR<WorkoutPlanUpdateWithoutPlannedSessionsInput, WorkoutPlanUncheckedUpdateWithoutPlannedSessionsInput>
  }

  export type WorkoutPlanUpdateWithoutPlannedSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    equipment?: EquipmentUpdateOneWithoutWorkoutPlansNestedInput
    instances?: PlanInstanceUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateWithoutPlannedSessionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    equipmentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    instances?: PlanInstanceUncheckedUpdateManyWithoutPlanNestedInput
  }

  export type PlannedExerciseUpsertWithWhereUniqueWithoutSessionInput = {
    where: PlannedExerciseWhereUniqueInput
    update: XOR<PlannedExerciseUpdateWithoutSessionInput, PlannedExerciseUncheckedUpdateWithoutSessionInput>
    create: XOR<PlannedExerciseCreateWithoutSessionInput, PlannedExerciseUncheckedCreateWithoutSessionInput>
  }

  export type PlannedExerciseUpdateWithWhereUniqueWithoutSessionInput = {
    where: PlannedExerciseWhereUniqueInput
    data: XOR<PlannedExerciseUpdateWithoutSessionInput, PlannedExerciseUncheckedUpdateWithoutSessionInput>
  }

  export type PlannedExerciseUpdateManyWithWhereWithoutSessionInput = {
    where: PlannedExerciseScalarWhereInput
    data: XOR<PlannedExerciseUpdateManyMutationInput, PlannedExerciseUncheckedUpdateManyWithoutSessionInput>
  }

  export type PlannedSessionCreateWithoutPlannedExercisesInput = {
    id?: string
    sessionNumber: number
    focus: string
    plan: WorkoutPlanCreateNestedOneWithoutPlannedSessionsInput
  }

  export type PlannedSessionUncheckedCreateWithoutPlannedExercisesInput = {
    id?: string
    sessionNumber: number
    focus: string
    planId: string
  }

  export type PlannedSessionCreateOrConnectWithoutPlannedExercisesInput = {
    where: PlannedSessionWhereUniqueInput
    create: XOR<PlannedSessionCreateWithoutPlannedExercisesInput, PlannedSessionUncheckedCreateWithoutPlannedExercisesInput>
  }

  export type ExerciseCreateWithoutPlannedExercisesInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    createdAt?: Date | string
    updatedAt?: Date | string
    equipment?: EquipmentCreateNestedOneWithoutExercisesInput
  }

  export type ExerciseUncheckedCreateWithoutPlannedExercisesInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    equipmentId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ExerciseCreateOrConnectWithoutPlannedExercisesInput = {
    where: ExerciseWhereUniqueInput
    create: XOR<ExerciseCreateWithoutPlannedExercisesInput, ExerciseUncheckedCreateWithoutPlannedExercisesInput>
  }

  export type WorkoutLogCreateWithoutPlannedExerciseInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutWorkoutLogsInput
    instance: PlanInstanceCreateNestedOneWithoutWorkoutLogsInput
  }

  export type WorkoutLogUncheckedCreateWithoutPlannedExerciseInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    userId: string
    instanceId: string
    createdAt?: Date | string
  }

  export type WorkoutLogCreateOrConnectWithoutPlannedExerciseInput = {
    where: WorkoutLogWhereUniqueInput
    create: XOR<WorkoutLogCreateWithoutPlannedExerciseInput, WorkoutLogUncheckedCreateWithoutPlannedExerciseInput>
  }

  export type WorkoutLogCreateManyPlannedExerciseInputEnvelope = {
    data: WorkoutLogCreateManyPlannedExerciseInput | WorkoutLogCreateManyPlannedExerciseInput[]
    skipDuplicates?: boolean
  }

  export type PlannedSessionUpsertWithoutPlannedExercisesInput = {
    update: XOR<PlannedSessionUpdateWithoutPlannedExercisesInput, PlannedSessionUncheckedUpdateWithoutPlannedExercisesInput>
    create: XOR<PlannedSessionCreateWithoutPlannedExercisesInput, PlannedSessionUncheckedCreateWithoutPlannedExercisesInput>
    where?: PlannedSessionWhereInput
  }

  export type PlannedSessionUpdateToOneWithWhereWithoutPlannedExercisesInput = {
    where?: PlannedSessionWhereInput
    data: XOR<PlannedSessionUpdateWithoutPlannedExercisesInput, PlannedSessionUncheckedUpdateWithoutPlannedExercisesInput>
  }

  export type PlannedSessionUpdateWithoutPlannedExercisesInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
    plan?: WorkoutPlanUpdateOneRequiredWithoutPlannedSessionsNestedInput
  }

  export type PlannedSessionUncheckedUpdateWithoutPlannedExercisesInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
    planId?: StringFieldUpdateOperationsInput | string
  }

  export type ExerciseUpsertWithoutPlannedExercisesInput = {
    update: XOR<ExerciseUpdateWithoutPlannedExercisesInput, ExerciseUncheckedUpdateWithoutPlannedExercisesInput>
    create: XOR<ExerciseCreateWithoutPlannedExercisesInput, ExerciseUncheckedCreateWithoutPlannedExercisesInput>
    where?: ExerciseWhereInput
  }

  export type ExerciseUpdateToOneWithWhereWithoutPlannedExercisesInput = {
    where?: ExerciseWhereInput
    data: XOR<ExerciseUpdateWithoutPlannedExercisesInput, ExerciseUncheckedUpdateWithoutPlannedExercisesInput>
  }

  export type ExerciseUpdateWithoutPlannedExercisesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    equipment?: EquipmentUpdateOneWithoutExercisesNestedInput
  }

  export type ExerciseUncheckedUpdateWithoutPlannedExercisesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    equipmentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogUpsertWithWhereUniqueWithoutPlannedExerciseInput = {
    where: WorkoutLogWhereUniqueInput
    update: XOR<WorkoutLogUpdateWithoutPlannedExerciseInput, WorkoutLogUncheckedUpdateWithoutPlannedExerciseInput>
    create: XOR<WorkoutLogCreateWithoutPlannedExerciseInput, WorkoutLogUncheckedCreateWithoutPlannedExerciseInput>
  }

  export type WorkoutLogUpdateWithWhereUniqueWithoutPlannedExerciseInput = {
    where: WorkoutLogWhereUniqueInput
    data: XOR<WorkoutLogUpdateWithoutPlannedExerciseInput, WorkoutLogUncheckedUpdateWithoutPlannedExerciseInput>
  }

  export type WorkoutLogUpdateManyWithWhereWithoutPlannedExerciseInput = {
    where: WorkoutLogScalarWhereInput
    data: XOR<WorkoutLogUpdateManyMutationInput, WorkoutLogUncheckedUpdateManyWithoutPlannedExerciseInput>
  }

  export type UserCreateWithoutInstancesInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionCreateNestedManyWithoutUserInput
    subscription?: SubscriptionCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutInstancesInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountUncheckedCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionUncheckedCreateNestedManyWithoutUserInput
    subscription?: SubscriptionUncheckedCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutInstancesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutInstancesInput, UserUncheckedCreateWithoutInstancesInput>
  }

  export type WorkoutPlanCreateWithoutInstancesInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    createdAt?: Date | string
    updatedAt?: Date | string
    equipment?: EquipmentCreateNestedOneWithoutWorkoutPlansInput
    plannedSessions?: PlannedSessionCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanUncheckedCreateWithoutInstancesInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    equipmentId?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    plannedSessions?: PlannedSessionUncheckedCreateNestedManyWithoutPlanInput
  }

  export type WorkoutPlanCreateOrConnectWithoutInstancesInput = {
    where: WorkoutPlanWhereUniqueInput
    create: XOR<WorkoutPlanCreateWithoutInstancesInput, WorkoutPlanUncheckedCreateWithoutInstancesInput>
  }

  export type WorkoutLogCreateWithoutInstanceInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutWorkoutLogsInput
    plannedExercise: PlannedExerciseCreateNestedOneWithoutLoggedSetsInput
  }

  export type WorkoutLogUncheckedCreateWithoutInstanceInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    userId: string
    plannedExerciseId: string
    createdAt?: Date | string
  }

  export type WorkoutLogCreateOrConnectWithoutInstanceInput = {
    where: WorkoutLogWhereUniqueInput
    create: XOR<WorkoutLogCreateWithoutInstanceInput, WorkoutLogUncheckedCreateWithoutInstanceInput>
  }

  export type WorkoutLogCreateManyInstanceInputEnvelope = {
    data: WorkoutLogCreateManyInstanceInput | WorkoutLogCreateManyInstanceInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutInstancesInput = {
    update: XOR<UserUpdateWithoutInstancesInput, UserUncheckedUpdateWithoutInstancesInput>
    create: XOR<UserCreateWithoutInstancesInput, UserUncheckedCreateWithoutInstancesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutInstancesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutInstancesInput, UserUncheckedUpdateWithoutInstancesInput>
  }

  export type UserUpdateWithoutInstancesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutInstancesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUncheckedUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUncheckedUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUncheckedUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutUserNestedInput
  }

  export type WorkoutPlanUpsertWithoutInstancesInput = {
    update: XOR<WorkoutPlanUpdateWithoutInstancesInput, WorkoutPlanUncheckedUpdateWithoutInstancesInput>
    create: XOR<WorkoutPlanCreateWithoutInstancesInput, WorkoutPlanUncheckedCreateWithoutInstancesInput>
    where?: WorkoutPlanWhereInput
  }

  export type WorkoutPlanUpdateToOneWithWhereWithoutInstancesInput = {
    where?: WorkoutPlanWhereInput
    data: XOR<WorkoutPlanUpdateWithoutInstancesInput, WorkoutPlanUncheckedUpdateWithoutInstancesInput>
  }

  export type WorkoutPlanUpdateWithoutInstancesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    equipment?: EquipmentUpdateOneWithoutWorkoutPlansNestedInput
    plannedSessions?: PlannedSessionUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateWithoutInstancesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    equipmentId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plannedSessions?: PlannedSessionUncheckedUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutLogUpsertWithWhereUniqueWithoutInstanceInput = {
    where: WorkoutLogWhereUniqueInput
    update: XOR<WorkoutLogUpdateWithoutInstanceInput, WorkoutLogUncheckedUpdateWithoutInstanceInput>
    create: XOR<WorkoutLogCreateWithoutInstanceInput, WorkoutLogUncheckedCreateWithoutInstanceInput>
  }

  export type WorkoutLogUpdateWithWhereUniqueWithoutInstanceInput = {
    where: WorkoutLogWhereUniqueInput
    data: XOR<WorkoutLogUpdateWithoutInstanceInput, WorkoutLogUncheckedUpdateWithoutInstanceInput>
  }

  export type WorkoutLogUpdateManyWithWhereWithoutInstanceInput = {
    where: WorkoutLogScalarWhereInput
    data: XOR<WorkoutLogUpdateManyMutationInput, WorkoutLogUncheckedUpdateManyWithoutInstanceInput>
  }

  export type UserCreateWithoutWorkoutLogsInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionCreateNestedManyWithoutUserInput
    subscription?: SubscriptionCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentCreateNestedManyWithoutUserInput
    instances?: PlanInstanceCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutWorkoutLogsInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountUncheckedCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionUncheckedCreateNestedManyWithoutUserInput
    subscription?: SubscriptionUncheckedCreateNestedOneWithoutUserInput
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutUserInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutWorkoutLogsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutWorkoutLogsInput, UserUncheckedCreateWithoutWorkoutLogsInput>
  }

  export type PlanInstanceCreateWithoutWorkoutLogsInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutInstancesInput
    plan: WorkoutPlanCreateNestedOneWithoutInstancesInput
  }

  export type PlanInstanceUncheckedCreateWithoutWorkoutLogsInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId: string
    planId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PlanInstanceCreateOrConnectWithoutWorkoutLogsInput = {
    where: PlanInstanceWhereUniqueInput
    create: XOR<PlanInstanceCreateWithoutWorkoutLogsInput, PlanInstanceUncheckedCreateWithoutWorkoutLogsInput>
  }

  export type PlannedExerciseCreateWithoutLoggedSetsInput = {
    id?: string
    order: number
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
    session: PlannedSessionCreateNestedOneWithoutPlannedExercisesInput
    exercise: ExerciseCreateNestedOneWithoutPlannedExercisesInput
  }

  export type PlannedExerciseUncheckedCreateWithoutLoggedSetsInput = {
    id?: string
    order: number
    sessionId: string
    exerciseId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
  }

  export type PlannedExerciseCreateOrConnectWithoutLoggedSetsInput = {
    where: PlannedExerciseWhereUniqueInput
    create: XOR<PlannedExerciseCreateWithoutLoggedSetsInput, PlannedExerciseUncheckedCreateWithoutLoggedSetsInput>
  }

  export type UserUpsertWithoutWorkoutLogsInput = {
    update: XOR<UserUpdateWithoutWorkoutLogsInput, UserUncheckedUpdateWithoutWorkoutLogsInput>
    create: XOR<UserCreateWithoutWorkoutLogsInput, UserUncheckedCreateWithoutWorkoutLogsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutWorkoutLogsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutWorkoutLogsInput, UserUncheckedUpdateWithoutWorkoutLogsInput>
  }

  export type UserUpdateWithoutWorkoutLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutWorkoutLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUncheckedUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUncheckedUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUncheckedUpdateOneWithoutUserNestedInput
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutUserNestedInput
  }

  export type PlanInstanceUpsertWithoutWorkoutLogsInput = {
    update: XOR<PlanInstanceUpdateWithoutWorkoutLogsInput, PlanInstanceUncheckedUpdateWithoutWorkoutLogsInput>
    create: XOR<PlanInstanceCreateWithoutWorkoutLogsInput, PlanInstanceUncheckedCreateWithoutWorkoutLogsInput>
    where?: PlanInstanceWhereInput
  }

  export type PlanInstanceUpdateToOneWithWhereWithoutWorkoutLogsInput = {
    where?: PlanInstanceWhereInput
    data: XOR<PlanInstanceUpdateWithoutWorkoutLogsInput, PlanInstanceUncheckedUpdateWithoutWorkoutLogsInput>
  }

  export type PlanInstanceUpdateWithoutWorkoutLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutInstancesNestedInput
    plan?: WorkoutPlanUpdateOneRequiredWithoutInstancesNestedInput
  }

  export type PlanInstanceUncheckedUpdateWithoutWorkoutLogsInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId?: StringFieldUpdateOperationsInput | string
    planId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlannedExerciseUpsertWithoutLoggedSetsInput = {
    update: XOR<PlannedExerciseUpdateWithoutLoggedSetsInput, PlannedExerciseUncheckedUpdateWithoutLoggedSetsInput>
    create: XOR<PlannedExerciseCreateWithoutLoggedSetsInput, PlannedExerciseUncheckedCreateWithoutLoggedSetsInput>
    where?: PlannedExerciseWhereInput
  }

  export type PlannedExerciseUpdateToOneWithWhereWithoutLoggedSetsInput = {
    where?: PlannedExerciseWhereInput
    data: XOR<PlannedExerciseUpdateWithoutLoggedSetsInput, PlannedExerciseUncheckedUpdateWithoutLoggedSetsInput>
  }

  export type PlannedExerciseUpdateWithoutLoggedSetsInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
    session?: PlannedSessionUpdateOneRequiredWithoutPlannedExercisesNestedInput
    exercise?: ExerciseUpdateOneRequiredWithoutPlannedExercisesNestedInput
  }

  export type PlannedExerciseUncheckedUpdateWithoutLoggedSetsInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    sessionId?: StringFieldUpdateOperationsInput | string
    exerciseId?: StringFieldUpdateOperationsInput | string
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
  }

  export type UserCreateWithoutSubscriptionInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionCreateNestedManyWithoutUserInput
    userEquipment?: UserEquipmentCreateNestedManyWithoutUserInput
    instances?: PlanInstanceCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutSubscriptionInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountUncheckedCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionUncheckedCreateNestedManyWithoutUserInput
    userEquipment?: UserEquipmentUncheckedCreateNestedManyWithoutUserInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutSubscriptionInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutSubscriptionInput, UserUncheckedCreateWithoutSubscriptionInput>
  }

  export type UserUpsertWithoutSubscriptionInput = {
    update: XOR<UserUpdateWithoutSubscriptionInput, UserUncheckedUpdateWithoutSubscriptionInput>
    create: XOR<UserCreateWithoutSubscriptionInput, UserUncheckedCreateWithoutSubscriptionInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutSubscriptionInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutSubscriptionInput, UserUncheckedUpdateWithoutSubscriptionInput>
  }

  export type UserUpdateWithoutSubscriptionInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUpdateManyWithoutUserNestedInput
    userEquipment?: UserEquipmentUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutSubscriptionInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUncheckedUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUncheckedUpdateManyWithoutUserNestedInput
    userEquipment?: UserEquipmentUncheckedUpdateManyWithoutUserNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutUserEquipmentInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionCreateNestedManyWithoutUserInput
    subscription?: SubscriptionCreateNestedOneWithoutUserInput
    instances?: PlanInstanceCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutUserEquipmentInput = {
    id?: string
    email: string
    name?: string | null
    password?: string | null
    emailVerified?: Date | string | null
    image?: string | null
    role?: $Enums.Role
    lastLoginAt?: Date | string | null
    onboardingComplete?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    isNewUser?: boolean
    primaryGoal?: $Enums.PrimaryGoal | null
    trainingLocation?: $Enums.TrainingLocation | null
    biologicalSex?: $Enums.BiologicalSex | null
    experienceLevel?: $Enums.UserLevel | null
    onboardingCompletedAt?: Date | string | null
    accounts?: AccountUncheckedCreateNestedManyWithoutUserInput
    sessions?: NextAuthSessionUncheckedCreateNestedManyWithoutUserInput
    subscription?: SubscriptionUncheckedCreateNestedOneWithoutUserInput
    instances?: PlanInstanceUncheckedCreateNestedManyWithoutUserInput
    workoutLogs?: WorkoutLogUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutUserEquipmentInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutUserEquipmentInput, UserUncheckedCreateWithoutUserEquipmentInput>
  }

  export type EquipmentCreateWithoutUserEquipmentInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    exercises?: ExerciseCreateNestedManyWithoutEquipmentInput
    workoutPlans?: WorkoutPlanCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentUncheckedCreateWithoutUserEquipmentInput = {
    id?: string
    name: string
    category: string
    createdAt?: Date | string
    updatedAt?: Date | string
    exercises?: ExerciseUncheckedCreateNestedManyWithoutEquipmentInput
    workoutPlans?: WorkoutPlanUncheckedCreateNestedManyWithoutEquipmentInput
  }

  export type EquipmentCreateOrConnectWithoutUserEquipmentInput = {
    where: EquipmentWhereUniqueInput
    create: XOR<EquipmentCreateWithoutUserEquipmentInput, EquipmentUncheckedCreateWithoutUserEquipmentInput>
  }

  export type UserUpsertWithoutUserEquipmentInput = {
    update: XOR<UserUpdateWithoutUserEquipmentInput, UserUncheckedUpdateWithoutUserEquipmentInput>
    create: XOR<UserCreateWithoutUserEquipmentInput, UserUncheckedCreateWithoutUserEquipmentInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutUserEquipmentInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutUserEquipmentInput, UserUncheckedUpdateWithoutUserEquipmentInput>
  }

  export type UserUpdateWithoutUserEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUpdateOneWithoutUserNestedInput
    instances?: PlanInstanceUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutUserEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    password?: NullableStringFieldUpdateOperationsInput | string | null
    emailVerified?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    image?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    lastLoginAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    onboardingComplete?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    isNewUser?: BoolFieldUpdateOperationsInput | boolean
    primaryGoal?: NullableEnumPrimaryGoalFieldUpdateOperationsInput | $Enums.PrimaryGoal | null
    trainingLocation?: NullableEnumTrainingLocationFieldUpdateOperationsInput | $Enums.TrainingLocation | null
    biologicalSex?: NullableEnumBiologicalSexFieldUpdateOperationsInput | $Enums.BiologicalSex | null
    experienceLevel?: NullableEnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel | null
    onboardingCompletedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    accounts?: AccountUncheckedUpdateManyWithoutUserNestedInput
    sessions?: NextAuthSessionUncheckedUpdateManyWithoutUserNestedInput
    subscription?: SubscriptionUncheckedUpdateOneWithoutUserNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutUserNestedInput
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutUserNestedInput
  }

  export type EquipmentUpsertWithoutUserEquipmentInput = {
    update: XOR<EquipmentUpdateWithoutUserEquipmentInput, EquipmentUncheckedUpdateWithoutUserEquipmentInput>
    create: XOR<EquipmentCreateWithoutUserEquipmentInput, EquipmentUncheckedCreateWithoutUserEquipmentInput>
    where?: EquipmentWhereInput
  }

  export type EquipmentUpdateToOneWithWhereWithoutUserEquipmentInput = {
    where?: EquipmentWhereInput
    data: XOR<EquipmentUpdateWithoutUserEquipmentInput, EquipmentUncheckedUpdateWithoutUserEquipmentInput>
  }

  export type EquipmentUpdateWithoutUserEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    exercises?: ExerciseUpdateManyWithoutEquipmentNestedInput
    workoutPlans?: WorkoutPlanUpdateManyWithoutEquipmentNestedInput
  }

  export type EquipmentUncheckedUpdateWithoutUserEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    exercises?: ExerciseUncheckedUpdateManyWithoutEquipmentNestedInput
    workoutPlans?: WorkoutPlanUncheckedUpdateManyWithoutEquipmentNestedInput
  }

  export type AccountCreateManyUserInput = {
    id?: string
    type: string
    provider: string
    providerAccountId: string
    refresh_token?: string | null
    access_token?: string | null
    expires_at?: number | null
    token_type?: string | null
    scope?: string | null
    id_token?: string | null
    session_state?: string | null
  }

  export type NextAuthSessionCreateManyUserInput = {
    id?: string
    sessionToken: string
    expires: Date | string
  }

  export type UserEquipmentCreateManyUserInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    equipmentId: string
  }

  export type PlanInstanceCreateManyUserInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    planId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WorkoutLogCreateManyUserInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    instanceId: string
    plannedExerciseId: string
    createdAt?: Date | string
  }

  export type AccountUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    providerAccountId?: StringFieldUpdateOperationsInput | string
    refresh_token?: NullableStringFieldUpdateOperationsInput | string | null
    access_token?: NullableStringFieldUpdateOperationsInput | string | null
    expires_at?: NullableIntFieldUpdateOperationsInput | number | null
    token_type?: NullableStringFieldUpdateOperationsInput | string | null
    scope?: NullableStringFieldUpdateOperationsInput | string | null
    id_token?: NullableStringFieldUpdateOperationsInput | string | null
    session_state?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type AccountUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    providerAccountId?: StringFieldUpdateOperationsInput | string
    refresh_token?: NullableStringFieldUpdateOperationsInput | string | null
    access_token?: NullableStringFieldUpdateOperationsInput | string | null
    expires_at?: NullableIntFieldUpdateOperationsInput | number | null
    token_type?: NullableStringFieldUpdateOperationsInput | string | null
    scope?: NullableStringFieldUpdateOperationsInput | string | null
    id_token?: NullableStringFieldUpdateOperationsInput | string | null
    session_state?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type AccountUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    provider?: StringFieldUpdateOperationsInput | string
    providerAccountId?: StringFieldUpdateOperationsInput | string
    refresh_token?: NullableStringFieldUpdateOperationsInput | string | null
    access_token?: NullableStringFieldUpdateOperationsInput | string | null
    expires_at?: NullableIntFieldUpdateOperationsInput | number | null
    token_type?: NullableStringFieldUpdateOperationsInput | string | null
    scope?: NullableStringFieldUpdateOperationsInput | string | null
    id_token?: NullableStringFieldUpdateOperationsInput | string | null
    session_state?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type NextAuthSessionUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NextAuthSessionUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type NextAuthSessionUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionToken?: StringFieldUpdateOperationsInput | string
    expires?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserEquipmentUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    equipment?: EquipmentUpdateOneRequiredWithoutUserEquipmentNestedInput
  }

  export type UserEquipmentUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    equipmentId?: StringFieldUpdateOperationsInput | string
  }

  export type UserEquipmentUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    equipmentId?: StringFieldUpdateOperationsInput | string
  }

  export type PlanInstanceUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plan?: WorkoutPlanUpdateOneRequiredWithoutInstancesNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutInstanceNestedInput
  }

  export type PlanInstanceUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    planId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutInstanceNestedInput
  }

  export type PlanInstanceUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    planId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    instance?: PlanInstanceUpdateOneRequiredWithoutWorkoutLogsNestedInput
    plannedExercise?: PlannedExerciseUpdateOneRequiredWithoutLoggedSetsNestedInput
  }

  export type WorkoutLogUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    instanceId?: StringFieldUpdateOperationsInput | string
    plannedExerciseId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    instanceId?: StringFieldUpdateOperationsInput | string
    plannedExerciseId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserEquipmentCreateManyEquipmentInput = {
    id?: string
    source: $Enums.EquipmentSource
    addedAt?: Date | string
    trialExpiresAt?: Date | string | null
    userId: string
  }

  export type ExerciseCreateManyEquipmentInput = {
    id?: string
    name: string
    description?: string | null
    youtubeUrl?: string | null
    musclesWorked?: ExerciseCreatemusclesWorkedInput | string[]
    muscleGroup: $Enums.MuscleGroup
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WorkoutPlanCreateManyEquipmentInput = {
    id?: string
    name: string
    description: string
    muscleGroup: $Enums.MuscleGroup
    durationWeeks: number
    sessionsPerWeek: number
    tier?: $Enums.PlanTier
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserEquipmentUpdateWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: UserUpdateOneRequiredWithoutUserEquipmentNestedInput
  }

  export type UserEquipmentUncheckedUpdateWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    userId?: StringFieldUpdateOperationsInput | string
  }

  export type UserEquipmentUncheckedUpdateManyWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    source?: EnumEquipmentSourceFieldUpdateOperationsInput | $Enums.EquipmentSource
    addedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    trialExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    userId?: StringFieldUpdateOperationsInput | string
  }

  export type ExerciseUpdateWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plannedExercises?: PlannedExerciseUpdateManyWithoutExerciseNestedInput
  }

  export type ExerciseUncheckedUpdateWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plannedExercises?: PlannedExerciseUncheckedUpdateManyWithoutExerciseNestedInput
  }

  export type ExerciseUncheckedUpdateManyWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    youtubeUrl?: NullableStringFieldUpdateOperationsInput | string | null
    musclesWorked?: ExerciseUpdatemusclesWorkedInput | string[]
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutPlanUpdateWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plannedSessions?: PlannedSessionUpdateManyWithoutPlanNestedInput
    instances?: PlanInstanceUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    plannedSessions?: PlannedSessionUncheckedUpdateManyWithoutPlanNestedInput
    instances?: PlanInstanceUncheckedUpdateManyWithoutPlanNestedInput
  }

  export type WorkoutPlanUncheckedUpdateManyWithoutEquipmentInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    description?: StringFieldUpdateOperationsInput | string
    muscleGroup?: EnumMuscleGroupFieldUpdateOperationsInput | $Enums.MuscleGroup
    durationWeeks?: IntFieldUpdateOperationsInput | number
    sessionsPerWeek?: IntFieldUpdateOperationsInput | number
    tier?: EnumPlanTierFieldUpdateOperationsInput | $Enums.PlanTier
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlannedExerciseCreateManyExerciseInput = {
    id?: string
    order: number
    sessionId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
  }

  export type PlannedExerciseUpdateWithoutExerciseInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
    session?: PlannedSessionUpdateOneRequiredWithoutPlannedExercisesNestedInput
    loggedSets?: WorkoutLogUpdateManyWithoutPlannedExerciseNestedInput
  }

  export type PlannedExerciseUncheckedUpdateWithoutExerciseInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    sessionId?: StringFieldUpdateOperationsInput | string
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
    loggedSets?: WorkoutLogUncheckedUpdateManyWithoutPlannedExerciseNestedInput
  }

  export type PlannedExerciseUncheckedUpdateManyWithoutExerciseInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    sessionId?: StringFieldUpdateOperationsInput | string
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
  }

  export type PlannedSessionCreateManyPlanInput = {
    id?: string
    sessionNumber: number
    focus: string
  }

  export type PlanInstanceCreateManyPlanInput = {
    id?: string
    level: $Enums.UserLevel
    status?: $Enums.InstanceStatus
    currentSession?: number
    startedAt?: Date | string
    completedAt?: Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PlannedSessionUpdateWithoutPlanInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
    plannedExercises?: PlannedExerciseUpdateManyWithoutSessionNestedInput
  }

  export type PlannedSessionUncheckedUpdateWithoutPlanInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
    plannedExercises?: PlannedExerciseUncheckedUpdateManyWithoutSessionNestedInput
  }

  export type PlannedSessionUncheckedUpdateManyWithoutPlanInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    focus?: StringFieldUpdateOperationsInput | string
  }

  export type PlanInstanceUpdateWithoutPlanInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutInstancesNestedInput
    workoutLogs?: WorkoutLogUpdateManyWithoutInstanceNestedInput
  }

  export type PlanInstanceUncheckedUpdateWithoutPlanInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    workoutLogs?: WorkoutLogUncheckedUpdateManyWithoutInstanceNestedInput
  }

  export type PlanInstanceUncheckedUpdateManyWithoutPlanInput = {
    id?: StringFieldUpdateOperationsInput | string
    level?: EnumUserLevelFieldUpdateOperationsInput | $Enums.UserLevel
    status?: EnumInstanceStatusFieldUpdateOperationsInput | $Enums.InstanceStatus
    currentSession?: IntFieldUpdateOperationsInput | number
    startedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    completedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sessionDraft?: NullableJsonNullValueInput | InputJsonValue
    userId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PlannedExerciseCreateManySessionInput = {
    id?: string
    order: number
    exerciseId: string
    beginnerSets: number
    beginnerReps: number
    intermediateSets: number
    intermediateReps: number
    advancedSets: number
    advancedReps: number
    restSeconds: number
  }

  export type PlannedExerciseUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
    exercise?: ExerciseUpdateOneRequiredWithoutPlannedExercisesNestedInput
    loggedSets?: WorkoutLogUpdateManyWithoutPlannedExerciseNestedInput
  }

  export type PlannedExerciseUncheckedUpdateWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    exerciseId?: StringFieldUpdateOperationsInput | string
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
    loggedSets?: WorkoutLogUncheckedUpdateManyWithoutPlannedExerciseNestedInput
  }

  export type PlannedExerciseUncheckedUpdateManyWithoutSessionInput = {
    id?: StringFieldUpdateOperationsInput | string
    order?: IntFieldUpdateOperationsInput | number
    exerciseId?: StringFieldUpdateOperationsInput | string
    beginnerSets?: IntFieldUpdateOperationsInput | number
    beginnerReps?: IntFieldUpdateOperationsInput | number
    intermediateSets?: IntFieldUpdateOperationsInput | number
    intermediateReps?: IntFieldUpdateOperationsInput | number
    advancedSets?: IntFieldUpdateOperationsInput | number
    advancedReps?: IntFieldUpdateOperationsInput | number
    restSeconds?: IntFieldUpdateOperationsInput | number
  }

  export type WorkoutLogCreateManyPlannedExerciseInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    userId: string
    instanceId: string
    createdAt?: Date | string
  }

  export type WorkoutLogUpdateWithoutPlannedExerciseInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutWorkoutLogsNestedInput
    instance?: PlanInstanceUpdateOneRequiredWithoutWorkoutLogsNestedInput
  }

  export type WorkoutLogUncheckedUpdateWithoutPlannedExerciseInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    userId?: StringFieldUpdateOperationsInput | string
    instanceId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogUncheckedUpdateManyWithoutPlannedExerciseInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    userId?: StringFieldUpdateOperationsInput | string
    instanceId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogCreateManyInstanceInput = {
    id?: string
    sessionNumber: number
    completedAt?: Date | string
    weightKg?: number | null
    actualReps?: number | null
    actualSets?: number | null
    userId: string
    plannedExerciseId: string
    createdAt?: Date | string
  }

  export type WorkoutLogUpdateWithoutInstanceInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutWorkoutLogsNestedInput
    plannedExercise?: PlannedExerciseUpdateOneRequiredWithoutLoggedSetsNestedInput
  }

  export type WorkoutLogUncheckedUpdateWithoutInstanceInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    userId?: StringFieldUpdateOperationsInput | string
    plannedExerciseId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WorkoutLogUncheckedUpdateManyWithoutInstanceInput = {
    id?: StringFieldUpdateOperationsInput | string
    sessionNumber?: IntFieldUpdateOperationsInput | number
    completedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    weightKg?: NullableFloatFieldUpdateOperationsInput | number | null
    actualReps?: NullableIntFieldUpdateOperationsInput | number | null
    actualSets?: NullableIntFieldUpdateOperationsInput | number | null
    userId?: StringFieldUpdateOperationsInput | string
    plannedExerciseId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}